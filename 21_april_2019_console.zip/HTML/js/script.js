$(window).on("load", function(){
      $("header").load('includes/header.html');



      // ========== Sidemenu Functions ============ //
      $("#sidemenu").load('includes/sidemenu.html', function(responseTxt, statusTxt, xhr){
            if(statusTxt == "success")
            // Sidemenu Open & Close
            $("body").on("click", ".sidemenu-opener", function(){
                  $(".console-sidemenu").toggleClass('active');
            });

            // Sidemenu Dropdown
            $(".console-sidemenu ul ul").parent().addClass("menu-item-has-children");
            $(".console-sidemenu ul li.menu-item-has-children > a").on("click", function() {
                  $(this).parent().toggleClass("active").siblings().removeClass("active");
                  $(this).next("ul").slideToggle();
                  $(this).parent().siblings().find("ul").slideUp();
                  return false;
            });
      });
      // ========== Sidemenu Functions ============ //





      // ========== More Option Panel Functions ============ //
      // Open & Close
      $("body").on("click", ".more-opt-open", function(){
            $(".more-opt-panel").toggleClass('active');
      });


      // ========== Grid Stack Initialization ============ //
      var options = {
            float: false,
            cellHeight: 10,
            animate:true,
            width:12,
            verticalMargin: 20,
            handle: '.console-panel-header, .console-no-header'

      };
      $('.grid-stack').gridstack(options);


      // ========== Panel Header Background Color ============ //
      var colorpick = $('.cp');
      colorpick.colorpickerplus()
      colorpick.on("click", function(){
            return false;
      });
      $("body").on("click",".colorpickerplus",function(){
            return false;
      })
      colorpick.on('changeColor', function(e,color){
            if(color==null) {
                  //when select transparent color
                  $('.color-fill-icon', $(this)).addClass('colorpicker-color');
            } else {
                  $('.color-fill-icon', $(this)).removeClass('colorpicker-color');
                  $('.color-fill-icon', $(this)).css('background-color', color);
                  $(this).parents('.console-panel-header').css('background-color', color);
            }
            return false;
      });

      // ========== Panel Header Font Color ============ //
      $(".header-fontcolor").on("click",function(){
            $(this).parents('.console-panel-header').toggleClass('light');
            $(this).find('span').toggleClass('active');
            return false;
      });


      // ========== Panel Switch Full Screen ============ //
      $("body").on("click",".switch-full", function(){
            let parent = $(this).parents('.console-panel');
            parent.toggleClass('fullscreen');
            parent.hasClass('fullscreen') ? $(this).find("i").attr('class','icon dripicons-contract-2') : $(this).find("i").attr('class','icon dripicons-expand-2');
            return false;
      });


      // ========== Collapse Panel ============ //
      $("body").on("click",".collapse-panel", function(){
            $(this).attr('class','expand-panel').find('i').attr('class','icon dripicons-chevron-down');
            let parent = $(this).parents('.grid-stack-item');
            let currentHeight = $(parent).attr('data-gs-height');
            parent.attr('data-heighthistory',currentHeight);

            let minHeight = $(parent).attr('data-gs-min-height');
            if(parent.attr('data-gs-min-height')){
                  parent.attr('data-minheighthistory',minHeight);
            }

            var grid = $('.grid-stack').data('gridstack');
            grid.minHeight(parent , '', 3);
            grid.resize(parent , '', 3);
            grid.resizable(parent,false);
            parent.find('.console-panel-body').slideUp();
            parent.find('.console-footer').slideUp();
            return false;
      });

      // ========== Uncollapse Panel ============ //
      $("body").on("click",".expand-panel", function(){
            $(this).attr('class','collapse-panel').find('i').attr('class','icon dripicons-chevron-up');
            let parent = $(this).parents('.grid-stack-item');
            var grid = $('.grid-stack').data('gridstack');
            if (parent.attr('data-heighthistory')){
                  let heightHistory = parseInt(parent.attr('data-heighthistory'));
                  grid.resize(parent , '', heightHistory);
            }else{
                  grid.resize(parent , '', 20);
            }

            if(parent.attr('data-minheighthistory')){
                  let minHeight = parseInt(parent.attr('data-minheighthistory'));
                  grid.minHeight(parent, minHeight)
            }

            grid.resizable(parent,true);
            parent.find('.console-panel-body').slideDown();
            parent.find('.console-footer').slideDown();
            return false;
      });


      // ========== Remove Panel ============ //
      $("body").on("click",".removeWidget", function(){
            let _this = this;
            let parent = $(this).parents('.grid-stack-item');
            $.confirm({
                  theme: 'bootstrap',
                  title: 'Are You Sure?',
                  content: 'You will not be able to see this panel back on this page.',
                  buttons: {
                        confirm:{
                              text: 'Confirm',
                              btnClass: 'btn-blue',
                              keys: ['enter', 'shift'],
                              action: function(){
                                    var grid = $('.grid-stack').data('gridstack');
                                    $(_this).parents('.console-panel').slideUp("complete", (function(){
                                          grid.removeWidget(parent, true)
                                    }));
                                    $.alert('Widget Removed!');
                              }
                        },
                        cancel: function () {
                        }
                  }
            });
            return false;
      });



      /*=== Tooltip ===*/
      $('[rel="tooltip"]').tooltip({
            container: 'body'
      });



})
