$("#calendar").fullCalendar({
      header: {
            right: 'next',
            center: 'title',
            left:'prev'
      },
      defaultDate: '2017-11-12',
      navLinks: true, // can click day/week names to navigate views
      selectable: false,
      selectHelper: false,
      height:530,
      select: function(start, end) {
            var title = prompt('Event Title:');
            var eventData;
            if (title) {
                  eventData = {
                        title: title,
                        start: start,
                        end: end
                  };
                  $(element).fullCalendar('renderEvent', eventData, true); // stick? = true
            }
            $(element).fullCalendar('unselect');
      },
      editable: false,
      eventLimit: true, // for all non-agenda views
      views: {
            agenda: {
                  eventLimit: 1// adjust to 6 only for agendaWeek/agendaDay
            }
      },
      events: [
            {
                  title: 'All Day Event',
                  start: '2017-11-01'
            },
            {
                  id: 999,
                  title: 'Repeating Event',
                  start: '2017-11-09T16:00:00'
            },
            {
                  id: 999,
                  title: 'Repeating Event',
                  start: '2017-11-09T16:00:00'
            },
            {
                  title: 'Conference',
                  start: '2017-11-11',
                  end: '2017-11-13'
            },

            {
                  title: 'Click for Google',
                  url: 'http://google.com/',
                  start: '2017-11-28'
            }
      ]
});
