$(window).on("load", function() {
    "use strict";


    /*================== Custom Dropdown List =====================*/
    $(".has-ddl > a").on("click",function(){
        $(this).next('.ddl').toggleClass('active');
        return false;
    });


    /*================== Dropdown Button =====================*/
    $("body").on("click",function(event){
        if($(event.target).parents().hasClass('has-ddl')){
            return;
        }
        else{
            $('.ddl').removeClass('active');
        }
    });


    /*================== Sidemenu Button =====================*/
    $(".sidemenu-btn").on('click',function(){
    	$(this).parent('.sidemenu').toggleClass('active');
    	return false;
    });

    /*================== Sidemenu Dropdown =====================*/
    $(".sidemenu nav ul ul").parent().addClass("menu-item-has-children");
    $(".sidemenu nav ul li.menu-item-has-children > a").on("click", function() {
        $(this).parent().toggleClass("active").siblings().removeClass("active");
        $(this).next("ul").slideToggle();
        $(this).parent().siblings().find("ul").slideUp();
        return false;
    });



    /*================== Open Settings =====================*/
    $("body").on("click",".open-settings",function(){
        $(this).toggleClass('active').next('.widget-settings-inner').slideToggle();
        return false;
    });


    /*================== By Default Sidemenu Collapse on Small Screen =====================*/
    if($(window).width() < 1025){
        $(".sidemenu").addClass('active');
    }


    $("body").on("click",".table-action > a",function(){
      $(this).parents('tr').siblings().find('.action-drop').removeClass('active');
      $(this).parents('td').css({'overflow':'visible'});
      $(this).siblings('.action-drop').toggleClass('active');
      return false;
    });





    /*=== Render DATA from JSON on Top Icons ===*/
    var jobs;
    var vehicles;
    $.get("Scripts/JS/icons.json", function( data ) {
      jobs = data.jobsStatus;
      vehicles = data.vehicleStatus;
      $.each(jobs, function(idx,val){
        $(".icon-set.jobsStatus").append(`<a data-toggle="tooltip" data-placement="bottom" class="icon-btn style2" href="#" title=" ${jobs[idx].title} "><span class="${jobs[idx].icon}"></span><i>${jobs[idx].count}</i></a>`);
      });
      $.each(vehicles, function(idx,val){
        $(".icon-set.vehicleStatus").append(`<a data-toggle="tooltip" data-placement="bottom" class="icon-btn style2" href="#" title=" ${vehicles[idx].title} "><span class="${vehicles[idx].icon}"></span><i>${vehicles[idx].count}</i></a>`);
      });
      $('[data-toggle="tooltip"]').tooltip()
    });


    setInterval(function cf(){
      $.get("Scripts/JS/icons.json", function( data ) {
        jobs = data.jobsStatus;
        vehicles = data.vehicleStatus;
        var i = 1;
        $.each(jobs, function(idx,val){
          $(".icon-set.jobsStatus a:nth-child(" + i + "n) i").html(jobs[idx].count);
          $(".icon-set.vehicleStatus a:nth-child(" + i + "n) i").html(vehicles[idx].count);
          i++;
        });
      });
    },5000);


    /*================== Plugins Initializations =====================*/

    /*=== Select2 ===*/
    $('.select,.bottom select').select2({
        placeholder: 'Select an option'
    });



    /*=== Font Awesome ===*/
    window.FontAwesomeConfig = {
    searchPseudoElements: true
    }


    /*=== Tooltip ===*/
     $('[data-toggle="tooltip"]').tooltip()



    /*------------- preloader js --------------*/
    $('.loader-container').delay(500).fadeOut('slow');// will first fade out the loading animation
    $('.page-loader').delay(500).fadeOut('slow');// will fade out the white DIV that covers the website.


    /*------------- Toggle Button --------------*/
    $('.cb-value').click(function() {
      var mainParent = $(this).parent('.toggle-btn');
      if($(mainParent).find('input.cb-value').is(':checked')) {
        $(mainParent).addClass('active');
      } else {
        $(mainParent).removeClass('active');
      }

    });




 });



