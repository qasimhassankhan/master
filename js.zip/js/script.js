$(window).on("load", function() {
    "use strict";



    /*=================== Sticky Header ===================*/
    $(window).on("scroll",function(){
        var scroll = $(window).scrollTop();
        var hstick = $("header");
        if (scroll > 20){
            hstick.addClass("sticky");
        } else{
            hstick.removeClass("sticky");
        }

    });


    /*=================== Custom Tabs Functionality ===================*/
    $(".tab-detail").fadeOut();
    $(".tab-detail.active").fadeIn();

    $(".custom-tabs li a").on("click", function() {
        $(this).parent().parent().find("li").removeClass("active");
        $(this).parent().addClass("active");
        $(".tab-detail").slideUp('slow').removeClass("active");
        var tab_name = $(this).data("name");
        $(".custom-content .tab-detail").each(function() {
            if ($(this).data("id") == tab_name) {
                $(this).slideDown('slow').addClass("active");
            }
        });
        return false;
    });



    /*=================== Full Height ===================*/
    function fullHeight(){
        var full_height = $(window).height();
        $(".full-height").css({"height":full_height});
        $(".bg-slide").css({"height":full_height});
    }
    fullHeight();
    $(window).resize(function(){fullHeight()});


    $(".quick-info,.bio-services").closest('.col').addClass('unset');



    /*=================== Sidemenu Functions ===================*/
    $(".menu-btn.open, .fullmenu-btn").on('click',function(){
        $('body').addClass('menu-opened');
        return false;
    });
    $("html, .menu-btn.close").on('click',function(){
        $('body').removeClass('menu-opened');
    });
    $('.menu-btn.open, .sideheader, .fullmenu-btn').on('click',function(e){
        e.stopPropagation();
    })

    $(".responsive-btn").on("click",function(){
        $(this).next("ul").toggleClass("active");
        return false;
    });


});

