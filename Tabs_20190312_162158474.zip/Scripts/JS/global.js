﻿function trim(text) {
    return rTrim(lTrim(text));
}
function lTrim(text) {
    var i = 0;
    var theValue = new String(text);
    while (theValue.charAt(i) == ' ') { i = i + 1; }
    return theValue.substring(i, theValue.length);
}
function rTrim(text) {
    var theValue = new String(text);
    var i = theValue.length - 1;
    while (theValue.charAt(i) == ' ') { i = i - 1; }
    return theValue.substring(0, i + 1);
}
function RemoveSpaces(ctrl) {
    $('#' + ctrl).val(trim($('#' + ctrl).val()));
}

function checkEmailAddress(email) {
    var filter = "^[\\w-_\.]*[\\w-_\.]\@[\\w]\.+[\\w]+[a-zA-Z]$";
    //var filter="^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$";

    //var filter = "\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
    //var filter = "\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
    //var filter = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var regex = new RegExp(filter);
    var res = regex.test(email);
    // ToDo : Incorporate all the follwoing checks in reg exp
    if (res) {

        var signs = email.split("@");
        // can not contain two signs..
        if (signs.length > 2) {
            return false;
        }
        //Notes : This check is to cope with follwoing bug of regular expression
        // doesnt give error if 4 or more characters are given after "@" and no dot is 
        //				given
        if (email.indexOf(".") == -1) {
            return false;
        }
        if (!isValidCharsForEmail(email)) {
            return false;
        }
        var domain = email.substring(email.indexOf("@") + 1)
        // As Domain Name And Server CAn NOT CONTAIN _
        // SO, lets test it...
        if (domain.indexOf("_") > 0) {
            return false;
        }
    }
    else {
        return false;
    }
    //HideMessage();
    return true;


}
function isValidCharsForEmail(theValue) {
    var chr;
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= 'A' && chr <= 'Z') || (chr >= 'a' && chr <= 'z') || (chr >= '0' && chr <= '9') || (chr == '-') || (chr == '_') || chr == '@' || chr == '.')) {

            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}
function isValidAlphaNumericWithoutDashes(theValue) {
    var chr;
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= 'A' && chr <= 'Z') || (chr >= 'a' && chr <= 'z') || (chr >= '0' && chr <= '9') || chr == ' ')) {
            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}

function isValidAlphaNumericWithDot(theValue) {
    var chr;
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= 'A' && chr <= 'Z') || (chr >= 'a' && chr <= 'z') || (chr >= '0' && chr <= '9') || chr == ' ' || chr == '.')) {
            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}
function isValidAlphaNumericWithDotComma(theValue) {
    var chr;
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= 'A' && chr <= 'Z') || (chr >= 'a' && chr <= 'z') || (chr >= '0' && chr <= '9') || chr == ' ' || chr == '.' || chr == ',')) {
            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}

function isValidTime(theValue) {
    var chr;
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= '0' && chr <= '9') || chr == ':')) {
            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}

function isValidAmount(theValue) {
    var chr;
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= '0' && chr <= '9') || chr == '.')) {
            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}

function ShowMessage(message) {
    $('#divmessage').html(message);
    $('#divmessage').show();
    scrollToElement("");
    window.setTimeout(function () { $('#divmessage').fadeOut(); }, 10000);

    return false;
}
//=================================HideMessage()
function HideMessage() {
    $('#divmessage').hide();
    return false;
}

function ShowMessage1(message) {
    $('#divmessage').html(message);
    $('#divmessage').show();
    //scrollToElement("");
    window.setTimeout(function () { $('#divmessage').fadeOut(); }, 10000);

    return false;
}
//=================================HideMessage()
function HideMessage1() {
    $('#divmessage').hide();
    return false;
}

function scrollToElement(id) {
    $('html, body').animate({ scrollTop: 0 }, 500);
}

function scrollToElementTop(vtop) {
    $('html, body').animate({ scrollTop: vtop }, 500);
}
//=========================================================
function IsNumeric(sText) {
    var ValidChars = "0123456789";
    var IsNumber = true;
    var Char;
    if (sText != "") {
        for (i = 0; i < sText.length && IsNumber == true; i++) {
            Char = sText.charAt(i);
            if (ValidChars.indexOf(Char) == -1) {
                IsNumber = false;
            }
        }
    }
    return IsNumber;
}

function IsNumericWithDot(theValue) {
    var chr;
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= '0' && chr <= '9') || chr == '.')) {
            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}

function IsDate(sText) {
    if (sText != "") {
        var pattern = /^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
        if (!pattern.test(sText)) {
            return false;
        }
    }
    return true;
    //alert(pattern.test(input));
}
function IsAlphaNumeric(sText) {
    if (sText != "") {
        var pattern = /^[a-z0-9]+$/i;
        if (!pattern.test(sText)) {
            return false;
        }
    }
    return true;
    //alert(pattern.test(input));
}

//------------------------------
function stripCharsInBag(s, bag) {
    var i;
    var returnString = "";

    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (bag.indexOf(c) == -1) returnString += c;
    }
    return returnString;
}
//==========================
function isInteger(s) {
    var i;
    for (i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (((c < "0") || (c > "9"))) return false;
    }
    return true;
}
//-----------------------------------
function checkPhoneNumber(strPhone) {
    var digits = "0123456789";
    var phoneNumberDelimiters = "()- ";
    var validWorldPhoneChars = phoneNumberDelimiters + "+";
    var minDigitsInIPhoneNumber = 10;

    s = stripCharsInBag(strPhone, validWorldPhoneChars);
    if ((isInteger(s) && s.length >= minDigitsInIPhoneNumber) == false) {
        return false;
    }
    return true;
}
//------------------------------------
function isValidAlphaNumericWithSpecialCharacter(theValue) {
    var chr;
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (chr == '\"' || chr == '\'') {
            return false;
        }
        //        if (!((chr >= 'A' && chr <= 'Z') || (chr >= 'a' && chr <= 'z') || (chr >= '0' && chr <= '9') || chr == ' ' || chr == '.' || chr == '?' || chr == '-' || chr == '_' || chr == ',' || chr == '(' || chr == ')' || chr == ':'
        //             || chr == '//' || chr == '/' || chr == '\'' || chr == '~' || chr == '&' || chr == '<' || chr == '>' || chr == '[' || chr == ']' || chr == '{' || chr == '}' || chr == '@' || chr == '!' || chr == '%' || chr == '$')) {
        //            return false;
        //        } // end of if
    } // end of for

    return true;
}


//==========================================
//==================================
function isValidCreditCardNo(cardNumber) {
    var flage = true;
    if (cardNumber != "") {
        var re = /^4\d{3}-?\d{4}-?\d{4}-?\d{4}$/;
        if (!re.test(cardNumber)) {
            flage = false;
        }
        else {
            flage = true;
            //cardtype = "VS"; //visa 2
        }
        if (flage == false) {
            var re = /^5[1-5]\d{2}-?\d{4}-?\d{4}-?\d{4}$/;
            if (!re.test(cardNumber)) {
                flage = false;
            }
            else {
                flage = true;
                //cardtype = "MC"; //master card 1
            }
        }
        if (flage == false) {
            var re = /^6011-?\d{4}-?\d{4}-?\d{4}$/;
            if (!re.test(cardNumber)) {
                flage = false;
            }
            else {
                flage = true;
                //cardtype = "DC"; //discover 5
            }
        }
        if (flage == false) {
            var re = /^3[4,7]\d{13}$/;
            if (!re.test(cardNumber)) {
                flage = false;
            }
            else {
                flage = true;
                //cardtype = "AX"; //american express 0
            }
        }
        if (flage == false) {
            var re = /^3[0,6,8]\d{12}$/;
            if (!re.test(cardNumber)) {
                flage = false;
            }
            else {
                flage = true;
                //cardtype = "DN"; //diners 3
            }
        }

        if (flage == false) {
            //$(CCType).val("");
            //ShowMessage("Invalid Card Number.");
            window.setTimeout(function () { $(Cardno).focus(); }, 0);
            return false;
        }
        // Checksum ("Mod 10")
        // Add even digits in even length strings or odd digits in odd length strings.
        var checksum = 0;
        for (var i = (2 - (cardNumber.length % 2)); i <= cardNumber.length; i += 2) {
            checksum += parseInt(cardNumber.charAt(i - 1));
        }
        // Analyze odd digits in even length strings or even digits in odd length strings.
        for (var i = (cardNumber.length % 2) + 1; i < cardNumber.length; i += 2) {
            var digit = parseInt(cardNumber.charAt(i - 1)) * 2;
            if (digit < 10) {
                checksum += digit;
            }
            else {
                checksum += (digit - 9);
            }
        }

        if ((checksum % 10) == 0) {
            HideMessage();
            //$(CCType).val(cardtype);
            return true;

        }
        else {
            //$(CCType).val("");
            //ShowMessage("Invalid Card Number.");
            //window.setTimeout(function () { $(Cardno).focus(); }, 0);
            return false;
        }
    }
    return true;
}
$(window).on("load",function(){"use strict";$("body").on("click",".has-ddl > a",function(){return $(".ddl").removeClass("active"),$(this).next(".ddl").toggleClass("active"),!1}),$("body").on("click",function(e){$(e.target).parents().hasClass("has-ddl")||$(".ddl").removeClass("active")}),$("body").on("click",".sidemenu-btn",function(){return $(this).parent(".sidemenu").toggleClass("active"),!1}),$("body").on("click",".sidemenu nav ul li.menu-item-has-children > a",function(){return $(this).parent().toggleClass("active").siblings().removeClass("active"),$(this).next("ul").slideToggle(),$(this).parent().siblings().find("ul").slideUp(),!1}),$(".select,.bottom select").select2({placeholder:"Select an option"}),window.FontAwesomeConfig={searchPseudoElements:!0},$(".loader-container").delay(500).fadeOut("slow"),$(".page-loader").delay(500).fadeOut("slow")});
////==================================
//function isValidCreditCardNo(Cardno, CCType) {
//    var flage = true;
//    var cardNumber = $(Cardno).val();
//    var cardtype = "";
//    if (cardNumber != "") {
//        var re = /^4\d{3}-?\d{4}-?\d{4}-?\d{4}$/;
//        if (!re.test(cardNumber)) {
//            flage = false;
//        }
//        else {
//            flage = true;
//            cardtype = 2; //visa
//        }
//        if (flage == false) {
//            var re = /^5[1-5]\d{2}-?\d{4}-?\d{4}-?\d{4}$/;
//            if (!re.test(cardNumber)) {
//                flage = false;
//            }
//            else {
//                flage = true;
//                cardtype = 1; //master card
//            }
//        }
//        if (flage == false) {
//            var re = /^6011-?\d{4}-?\d{4}-?\d{4}$/;
//            if (!re.test(cardNumber)) {
//                flage = false;
//            }
//            else {
//                flage = true;
//                cardtype = 4; //discover
//            }
//        }
//        if (flage == false) {
//            var re = /^3[4,7]\d{13}$/;
//            if (!re.test(cardNumber)) {
//                flage = false;
//            }
//            else {
//                flage = true;
//                cardtype = 0; //american express
//            }
//        }
//        if (flage == false) {
//            var re = /^3[0,6,8]\d{12}$/;
//            if (!re.test(cardNumber)) {
//                flage = false;
//            }
//            else {
//                flage = true;
//                cardtype = 3; //diners
//            }
//        }

//        if (flage == false) {
//            $(CCType).val("");
//            ShowMessage("Invalid Card Number.");
//            window.setTimeout(function () { $(Cardno).focus(); }, 0);
//            return false;
//        }
//        // Checksum ("Mod 10")
//        // Add even digits in even length strings or odd digits in odd length strings.
//        var checksum = 0;
//        for (var i = (2 - (cardNumber.length % 2)); i <= cardNumber.length; i += 2) {
//            checksum += parseInt(cardNumber.charAt(i - 1));
//        }
//        // Analyze odd digits in even length strings or even digits in odd length strings.
//        for (var i = (cardNumber.length % 2) + 1; i < cardNumber.length; i += 2) {
//            var digit = parseInt(cardNumber.charAt(i - 1)) * 2;
//            if (digit < 10) {
//                checksum += digit;
//            }
//            else {
//                checksum += (digit - 9);
//            }
//        }

//        if ((checksum % 10) == 0) {
//            HideMessage();
//            $(CCType).val(cardtype);
//            return true;

//        }
//        else {
//            $(CCType).val("");
//            ShowMessage("Invalid Card Number.");
//            window.setTimeout(function () { $(Cardno).focus(); }, 0);
//            return false;
//        }
//    }
//    return true;
//}

function GetFormattedCardNo(cardNo) {

    if (cardNo.length < 6) {
        return cardNo;
    }
    hiddenChars = "************";
    visibleChars = cardNo.substring(cardNo.length - 4, cardNo.length);
    formattedCardNo = hiddenChars + visibleChars;
    return formattedCardNo;

}

function ShowLoading() {
    $(document).ready(function () {
        $("#divloading").dialog({
            modal: true,
            width: "210px",
            height: "auto",
            title: "",
            closeOnEscape: false,
            resizable: false,
            dialogClass: 'noTitleStuff',
            open: function (event, ui) {
                $(this).parent().children('.ui-dialog-titlebar').hide();
                $(this).parent().children().children('.ui-dialog-titlebar-close').hide();
                $(this).dialog("option", "height", 58);
            }
        });
    });
}
function HideLoading() {
    $(document).ready(function () {
        $("#divloading").dialog("close");
    });
}

function isValidPhone(theValue, fieldName) {
    var chr;
    if (theValue.length < 10) {
        ShowMessage("Invalid " + fieldName + ". Please enter your " + fieldName + " with area code first and without any dashes.");
        return false;
    }

    if (theValue.charAt(i) == '0' || theValue.charAt(0) == '1') {
        ShowMessage("Invalid " + fieldName + ". Please enter your " + fieldName + " with area code first and without any dashes.");
        return false;
    }
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= '0' && chr <= '9') || (chr == ' '))) {
            ShowMessage(fieldName + " contains invalid character(s). Please enter your " + fieldName + " with area code first and without any dashes.");
            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}
function isValidPhoneInternational(theValue, theValue1, fieldName) {
    var chr;

    if (theValue != "") {
        if (theValue.length < 4) {
            ShowMessage("Invalid International Phone number.");
            return false;
        }
        theValue = theValue + theValue1;
        if (theValue.length < 7) {
            ShowMessage("Invalid " + fieldName + ". Please enter your " + fieldName + " with area code first and without any dashes.");
            return false;
        }
    }
    else if (theValue1.length < 3) {
        ShowMessage("Invalid Country+City Code.");
        return false;
    }
    //    else {
    //        if (theValue.length < 4) {
    //            ShowMessage("Invalid International Phone number.");
    //            return false;
    //        }
    //    }
    HideMessage();
    return true;
}
function isValidNumeric(theValue, fieldName) {
    var chr;
    theValue = trim(theValue);
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!(chr >= '0' && chr <= '9')) {
            ShowMessage(fieldName + " contains invalid character(s). Please provide numeric value.");
            return false;
        } // end of if
    } // end of for
    HideMessage();
    return true;
}

function isValidAlphaNumeric(theValue, fieldName) {
    var chr;
    theValue = trim(theValue);
    for (var i = 0; i < theValue.length; i++) {
        chr = theValue.charAt(i)
        if (!((chr >= '0' && chr <= '9') || (chr >= 'A' && chr <= 'Z') || (chr >= 'a' && chr <= 'z'))) {

            return false;
        } // end of if
    } // end of for
    return true;
}

function ShowLookupMessage() {
    $("#messagecontainer").show();
    $(".trhide").hide();
}

function commaSeparateNumber(val) {
    //alert(val);
    val = parseFloat(val).toFixed(2);
    while (/(\d+)(\d{3})/.test(val.toString())) {
        val = val.toString().replace(/(\d+)(\d{3})/, '$1' + ',' + '$2');
    }
    //return parseFloat(val).toFixed(2);
    return val;
    //var retVal = 0;
    //return $(val).each(function () {
    //    $(this).text($(this).text().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,"));
    //});
    //alert(val.toLocaleString("en"));
    //retVal = val.toLocaleString("en");
    //retVal = parseFloat(retVal).toFixed(2);
    //return retVal;
}

function formatDate(val) {
    var dateString = val.substr(6);
    var currentTime = new Date(parseInt(dateString));
    var month = currentTime.getMonth() + 1;
    var day = currentTime.getDate();
    var year = currentTime.getFullYear();
    var date = ('0' + month).slice(-2) + "/" + ('0' + day).slice(-2) + "/" + year;
    return date;
}

function formatDateDash(val) {
    var dateString = val.substr(6);
    var currentTime = new Date(parseInt(dateString));
    var month = currentTime.getMonth() + 1;
    var day = currentTime.getDate();
    var year = currentTime.getFullYear();
    var date = ('0' + month).slice(-2) + "-" + ('0' + day).slice(-2) + "-" + year;
    return date;
}

$(function () {
    $("[id*=MainGrid] td").hover(function () {
        $("td", $(this).closest("tr")).addClass("webGrid_hover_row");
    }, function () {
        $("td", $(this).closest("tr")).removeClass("webGrid_hover_row");
    });

    //====================================================================================

});

function ValidateDate(dtValue) {
    var dtRegex = new RegExp(/\b\d{1,2}[\/-]\d{1,2}[\/-]\d{4}\b/);
    return dtRegex.test(dtValue);
}

function _renderMenu(ul, items) {
    var self = this;
    ul.append("<table class='clsactable' width='100%'><thead><tr class='clsachead'><th class='clsachead1'>Invoice #</th><th class='clsachead2'>Date</th><th class='clsachead3'>Amount</th></tr></thead><tbody></tbody></table>");
    $.each(items, function (index, item) {
        self._renderItemData(ul, ul.find("table tbody"), item, index);
    });
}

function _renderItemData(ul, table, item, index) {
    return this._renderItem(table, item, index).data("ui-autocomplete-item", item);
}

//function _renderItem(table, item, index) {
//    return $("<tr class='ui-menu-item clsacrow' role='presentation'></tr>")
//        .append("<td class='clsaccol1'>" + String(item.oInvoiceNum).replace(
//            new RegExp(this.term, "gi"),
//            "<span class='clshighlight'>$&</span>") + "</td>" + "<td class='clsaccol2'>" + formatDateDash(item.oInvoiceDate) + "</td>" + "<td class='clsaccol3'>$" + commaSeparateNumber(item.oInvoiceNetAmount) + "</td>")
//        .appendTo(table);
//}

function _renderItem(table, item, index) {
    return $("<tr class='ui-menu-item clsacrow' role='presentation'></tr>")
        .append("<td class='clsaccol1'>" + String(item.INVOICE_NUM).replace(
            new RegExp(this.term, "gi"),
            "<span class='clshighlight'>$&</span>") + "</td>" + "<td class='clsaccol2'>" + formatDateDash(item.INVOICE_DATE) + "</td>" + "<td class='clsaccol3'>$" + commaSeparateNumber(item.NetTotal) + "</td>")
        .appendTo(table);
}
//==================================================================================
function _renderMenuDash(ul, items) {
    var self = this;
    //ul.append("<table class='clsactable' width='100%'><thead><tr class='clsachead'><th class='clsachead1'>Account Number</th><th style='text-align:center' class='clsachead2'>Account Name</th></tr></thead><tbody></tbody></table>");
    //ul.append("<table class='clsactable' width='100%'><thead><tr class='clsachead'><th class='clsachead11'>Account Number / Account Name</th></tr></thead><tbody></tbody></table>");
    ul.append("<table class='clsactable' width='100%'><tbody></tbody></table>");
    $.each(items, function (index, item) {
        self._renderItemData(ul, ul.find("table tbody"), item, index);
    });
}

function _renderItemDataDash(ul, table, item, index) {
    return this._renderItem(table, item, index).data("ui-autocomplete-item", item);
    //return this._renderItem(table, item, index).data("ui-autocomplete", item);
    //return this._renderItem(table, item, index).data("item.autocomplete", item);
}
//.append("<td class='clsaccol1'>" + item.AccountNumber + "</td>" + "<td class='clsaccol2'>" + item.AccountName + "</td>")
function _renderItemDash(table, item, index) {
    if ($.trim(item.AccountNumber) == "") {
        return $("<tr class='ui-menu-item clsacrow clsnoclick' role='presentation'></tr>")
            .append("<td class='clsaccol11' style='height:10px !important;padding-right:10px !important;'><hr style='padding-right:10px;' class='clsacbdr' /></td>")
            .appendTo(table);
        //return $("<tr class='ui-menu-item clsacrow' role='presentation'></tr>")
        //    .append("<td class='clsaccol11'>" + item.AccountNumber + item.AccountName + "</td>")
        //    .appendTo(table);
        //return $("").appendTo(table);
    }
    else {
        return $("<tr class='ui-menu-item clsacrow' role='presentation'></tr>")
            .append("<td class='clsaccol11'>" + item.AccountNumber + "<br />" + item.AccountName + "</td>")
            .appendTo(table);
    }
}
function ConvertToObject(e){return null!=e&&"object"==typeof e||(e=JSON.parse(e)),e}function RowValue(e,t){return TableValue(0,e,t)}function TableValue(e,a,t){var n=t.JMetaData.Headings,r=t.JData,o=-1;return $.each(n,function(e,t){var r=n[0].constructor===Array?n[e][0].toUpperCase():n[e].toUpperCase();if(trim(r)==trim(a).toUpperCase())return o=e,!1}),r[e][o]}
//======================================================================================
//function _renderMenu(ul, items) {
//    var self = this;
//    ul.append("<table class='clsactable' width='100%'><thead><tr class='clsachead'><th class='clsachead1'>Invoice #</th><th class='clsachead2'>Date</th><th class='clsachead3'>Amount</th></tr></thead><tbody></tbody></table>");
//    if (items.length > 5) {
//        ul.append("<div class='clsacmorediv'>Show More</div>");
//    }
//    $.each(items, function (index, item) {
//        self._renderItemData(ul, ul.find("table tbody"), item, index);
//    });
//}

//function _renderItemData(ul, table, item, index) {
//    return this._renderItem(table, item, index).data("ui-autocomplete-item", item);
//}

//function _renderItem(table, item, index) {
//    if (index > 4) {
//        return $("<tr class='ui-menu-item clsacrow clshidden' role='presentation'></tr>")
//            .append("<td class='clsaccol1'>" + String(item.INVOICE_NUM).replace(
//                new RegExp(this.term, "gi"),
//                "<span class='clshighlight'>$&</span>") + "</td>" + "<td class='clsaccol2'>" + formatDateDash(item.INVOICE_DATE) + "</td>" + "<td class='clsaccol3'>$" + commaSeparateNumber(item.NetTotal) + "</td>")
//            .appendTo(table);
//    }
//    else {
//        return $("<tr class='ui-menu-item clsacrow' role='presentation'></tr>")
//            .append("<td class='clsaccol1'>" + String(item.INVOICE_NUM).replace(
//                new RegExp(this.term, "gi"),
//                "<span class='clshighlight'>$&</span>") + "</td>" + "<td class='clsaccol2'>" + formatDateDash(item.INVOICE_DATE) + "</td>" + "<td class='clsaccol3'>$" + commaSeparateNumber(item.NetTotal) + "</td>")
//            .appendTo(table);
//    }
//}

//$(function () {
//    $('.clsacmorediv').on("click", function () {
//        alert('ok');
//        if ($(this).text() == "Show More") {
//            $(this).text("Show Less");
//            $(".clshidden").show();
//        }
//        else {
//            $(this).text("Show More");
//            $(".clshidden").hide();
//        }
//        return false;
//    });
//});
////$('.clsacmorediv').click(function () {
//    //    if ($(this).text() == "Show More") {
//    //        $(this).text("Show Less");
//    //        $(".clshidden").show();
//    //    }
//    //    else {
//    //        $(this).text("Show More");
//    //        $(".clshidden").hide();
//    //    }
//    //    return false;
//    //});
// //});