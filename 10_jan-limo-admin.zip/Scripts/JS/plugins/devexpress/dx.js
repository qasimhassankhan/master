

$(document).ready(function(){

	$.get("Scripts/JS/JSON/users.json", function( data ) {
		var Columndata = data.jData;
		var headings = data.Headings;
		console.log(data);


		//=================================================
		var dataGrid = $("#gridContainer").dxDataGrid({
				dataSource: Columndata,
				columnMinWidth: 100,
				columns: headings,
				allowColumnReordering: true,
				allowColumnResizing: true,
				columnResizingMode: "widget", // "nextColumn" or "widget"
				showRowLines: true,
				rowAlternationEnabled: true,
				scrolling: {
						columnRenderingMode: "virtual"
				},
				showBorders: true,
				paging: {
						pageSize:7
				},
				filterRow: {
						visible: false,
						applyFilter: "auto"
				},
				searchPanel: {
						visible: false,
						width: 240,
						placeholder: "Search..."
				},
				headerFilter: {
						visible: false
				},
				sorting: {
						mode:"none"
				}
		}).dxDataGrid('instance');
	});



});
