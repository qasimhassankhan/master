var HostName = 'https://eliteny.com/';
var proxy = 'https://cors-anywhere.herokuapp.com/';


var autocomplete = new google.maps.places.Autocomplete($("#addressField")[0], {});

google.maps.event.addListener(autocomplete, 'place_changed', function () {
    var place = autocomplete.getPlace();
    $('#AirportForm').removeClass('hidden');
    console.log(place.address_components);
});

function ShowPickUpStreetView(latitue, longitude, address) {
    //var geocodermap = new google.maps.Geocoder();
    //console.log(latitue);
    ////var paddress = address;
    //geocodermap.geocode({ 'address': address }, function (results, status) {
    //    //   debugger;
    //    // alert(results);
    //    if (status == google.maps.GeocoderStatus.OK) {
    //        var lat = results[0].geometry.location.lat();
    //        var lng = results[0].geometry.location.lng();
    //        latitue = lat;
    //        longitude = lng;


    //    }
    //});
    //console.log(latitue);
    latitue = eval(latitue);
    longitude = eval(longitude);
    //====================================================
    var lookTo = new google.maps.LatLng(latitue, longitude);
    var panoOptions = {
        position: lookTo,
        fullscreenControl: false,
        addressControl: false

    };

    var pano = new google.maps.StreetViewPanorama(document.getElementById('divPUMap'), panoOptions);
    // initialize a new streetviewService object
    var service = new google.maps.StreetViewService;
    service.getPanoramaByLocation(pano.getPosition(), 50, function (panoData) {
        // if the function returned a result
        if (panoData != null) {
            var panoCenter = panoData.location.latLng;
            var heading = google.maps.geometry.spherical.computeHeading(panoCenter, lookTo);
            var pov = pano.getPov();
            pov.heading = heading;
            pano.setPov(pov);
            pano.setZoom(0);
        }
    });
    pano.addListener('position_changed', function () {
        var positionCell = document.getElementById('divPUMap');
        // positionCell.firstChild.nodeValue = pano.getPosition() + '';
        console.log(pano.location.description);
        $('#PickupAddress').val(pano.location.description);
        console.log(+"your Pick Up location is now " + pano.getPosition());
    });
}

function ShowDOStreetView(latitue, longitude, address) {

    //var geocodermap = new google.maps.Geocoder();
    ////var paddress = address;
    //geocodermap.geocode({ 'address': address }, function (results, status) {
    //    //   debugger;
    //    // alert(results);
    //    if (status == google.maps.GeocoderStatus.OK) {
    //        var lat = results[0].geometry.location.lat();
    //        var lng = results[0].geometry.location.lng();
    //        latitue = lat;
    //        longitude = lng;


    //    }
    //});

    latitue = eval(latitue);
    longitude = eval(longitude);
    //====================================================
    var lookTo = new google.maps.LatLng(latitue, longitude);
    var panoOptions = {
        position: lookTo,
        fullscreenControl: false,
        addressControl: false

    };

    var pano = new google.maps.StreetViewPanorama(document.getElementById('divDOMap'), panoOptions);
    // initialize a new streetviewService object
    var service = new google.maps.StreetViewService;
    service.getPanoramaByLocation(pano.getPosition(), 50, function (panoData) {
        // if the function returned a result
        if (panoData != null) {
            var panoCenter = panoData.location.latLng;
            var heading = google.maps.geometry.spherical.computeHeading(panoCenter, lookTo);
            var pov = pano.getPov();
            pov.heading = heading;
            pano.setPov(pov);
            pano.setZoom(0);
        }
    });
    pano.addListener('position_changed', function () {
        var positionCell = document.getElementById('divPUMap');
        //  positionCell.firstChild.nodeValue = pano.getPosition() + '';
        console.log(pano.location.description);
        $('#DropOffAddress').val(pano.location.description);
        console.log(+"your DropOff  location is now " + pano.getPosition());
    });
}
//
function ShowPickupMap(pLocation) {
    //pLocation = "LaGuardia Airport, New York";
    //pLatitude = "";
    // var pLocation = $('.address-field.pickup-add').val();
    //  debugger;
    if (pLocation != "") {
        var geocodermap = new google.maps.Geocoder();
        var address = pLocation;
        geocodermap.geocode({ 'address': address }, function (results, status) {
            //   debugger;
            // alert(results);
            if (status == google.maps.GeocoderStatus.OK) {
                var lat = results[0].geometry.location.lat();
                var lng = results[0].geometry.location.lng();
                lat = parseFloat(lat).toFixed(4);
                lng = parseFloat(lng).toFixed(4);
                //alert(lat + "::" + lng);
                //ShowMapPopup(lng, lat, "", "", "");
                //return false;
                var map = new google.maps.Map(document.getElementById('divPUMap'), {
                    zoom: 16,
                    center: new google.maps.LatLng(lat, lng),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var infowindow = new google.maps.InfoWindow();

                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(lat, lng),
                    map: map,
                    icon: "images/car_pointer.png"
                });
                if (results[0]) {
                    //var strContent = pLocation + "<br />" + "Lat:" + lat + ", Lng:" + lng;
                    var strContent = pLocation;
                    infowindow.setContent(strContent);
                    infowindow.open(map, marker);
                    google.maps.event.addListener(marker, 'click', function () {
                        infowindow.open(map, marker);
                    });

                } else {
                    //  window.alert('No results found');
                }
            }
            else {
                //   alert('Geocode was not successful for the following reason: ' + status);

            }
            $(".divPUMap").css("position", "absolute !important");
            $(".divPUMap").css("overflow", "visible !important");
        });
    }

}

function ShowDropOffMap(pLocation) {
    //pLocation = "LaGuardia Airport, New York";
    //pLatitude = "";
    // var pLocation = $('.address-field.pickup-add').val();
    debugger;
    if (pLocation != "") {
        var geocodermap = new google.maps.Geocoder();
        var address = pLocation;
        geocodermap.geocode({ 'address': address }, function (results, status) {

            if (status == google.maps.GeocoderStatus.OK) {
                var lat = results[0].geometry.location.lat();
                var lng = results[0].geometry.location.lng();
                lat = parseFloat(lat).toFixed(4);
                lng = parseFloat(lng).toFixed(4);
                //alert(lat + "::" + lng);
                //ShowMapPopup(lng, lat, "", "", "");
                //return false;
                var map = new google.maps.Map(document.getElementById('divDOMap'), {
                    zoom: 16,
                    center: new google.maps.LatLng(lat, lng),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                var infowindow = new google.maps.InfoWindow();

                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(lat, lng),
                    map: map,
                    icon: "images/car_pointer.png"
                });
                if (results[0]) {
                    //var strContent = pLocation + "<br />" + "Lat:" + lat + ", Lng:" + lng;
                    var strContent = pLocation;
                    infowindow.setContent(strContent);
                    infowindow.open(map, marker);
                    google.maps.event.addListener(marker, 'click', function () {
                        infowindow.open(map, marker);
                    });

                } else {
                    //   window.alert('No results found');
                }
            }
            else {
                // alert('Geocode was not successful for the following reason: ' + status);

            }
            $(".divDOMap").css("position", "absolute !important");
            $(".divDOMap").css("overflow", "visible !important");
        });
    }

}




var MyclassName = "jfk-terminals";

$(document).ready(function () {
    $('#liSignOut').click(function (e) {
        bootbox.confirm("Do you want to Sign out ?", function (result) {
            if (result == true) {
                loginPage();
            }
        });
    });
});
$(document).ready(function () {
    $('#liSignOut2').click(function (e) {
        bootbox.confirm("Do you want to Sign out ?", function (result) {
            if (result == true) {
                loginPage();
            }
        });
    });
});

function GetCustomerPicture(results) {
    bootbox.alert(results);
}

function loginPage() {
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: proxy + HostName + "/EliteService.asmx/LogOut",
            success: succeeded_previous,
            error: failed_previous
        });
}

function succeeded_previous(result) {
    if (result.d == "true") {
        window.location.href = "Default.aspx";
    }
}

function failed_previous(parameters) {

}

function NewBooking() {
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: proxy + HostName + "/EliteService.asmx/CancelBookACar",
            success: succeeded_prev,
            error: failed_prev
        });
}

function succeeded_prev(result) {
    if (result.d == "true") {
        window.location.href = "Book-a-car.aspx";
    }
}

function failed_prev(parameters) {

}


function SelectSingleCheckbox(rdbtnid) {
    if (rdbtnid == "c1") {
        document.getElementById('ContentPlaceHolder1_chkbxPickInside').checked = true;
        document.getElementById('ContentPlaceHolder1_chkbxPickOutside').checked = false;
        $('#c2').attr('checked', false);
    }
    else {
        document.getElementById('ContentPlaceHolder1_chkbxPickInside').checked = false;
        document.getElementById('ContentPlaceHolder1_chkbxPickOutside').checked = true;
        $('#c1').attr('checked', false);
    }
}

function chkbxNoSuv_OnClick() {
    if ($('#chkbxNoSuv').is(':checked')) {
        $('#chkNosuv').prop('checked', true);
    } else {
        $('#chkNosuv').prop('checked', false);
    }



}
function chkbxPet_OnClick() {
    if ($('#chkbxPetAccept').is(':checked')) {
        $('#chkbxPet').prop('checked', true);
        $('#chkbxPetTmp').prop('checked', true);
    } else {
        $('#chkbxPet').prop('checked', false);
        $('#chkbxPetTmp').prop('checked', false);
    }



}
function chkbxWheelChair_OnClick() {
    if ($('#chkbxWheelChairAccept').is(':checked')) {
        $('#chkbxWheelChair').prop('checked', true);
        $('#chkbxWheelChairTmp').prop('checked', true);
    } else {
        $('#chkbxWheelChair').prop('checked', false);
        $('#chkbxWheelChairTmp').prop('checked', false);
    }



}
function chkBxPackge_OnClick() {
    if ($('#chkBxPackgeAccept').is(':checked')) {
        $('#chkBxPackge').prop('checked', true);
    } else {
        $('#chkBxPackge').prop('checked', false);
    }



}
//chkbxGuaranteedWaitingTime
function chkBxGwt_OnClick() {
    if ($('#chkbxGuaranteedWaitingTime').is(':checked')) {
        $('#chkBxGwt').prop('checked', true);
    } else {
        $('#chkBxGwt').prop('checked', false);
    }



}

var checkPackage = true;
function setValue2(obj) {
    if (checkPackage == obj) {
        document.getElementById("chkBxPackge").checked = true;
        document.getElementById("chkBxPackage").checked = true;
        checkPackage = false;
    } else {
        document.getElementById("chkBxPackge").checked = false;
        document.getElementById("chkBxPackage").checked = false;
        checkPackage = true;
    }
}

var chkAirportPu = false;
var chkAirportDo = false;

function GetPostalWithAddress(placeid) {
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: proxy + HostName + "/EliteService.asmx/GetAddresswithPostalCode",
            data: "{ placeId: '" + placeid + "'}",
            success: succeeded_previous1,
            error: failed_previous1
        });
    return false;
}

var latlongPu = '';

function succeeded_previous1(result) {
    // $("#AirportForm").removeClass('hidden');

    //$("#PickupAddress").val();

    
    if (result.d != "") {
        var myJsonString = JSON.parse(result.d);
        var typeArray;
        var checkStreet = false;
        if (myJsonString.status == "OK") {
            for (var k = 0; k < myJsonString.result.types.length; k++) {
                typeArray = myJsonString.result.types[k];
                if (typeArray == "establishment" || typeArray == "street_address" || typeArray == "premise" || typeArray == "airport") {
                    checkStreet = true;
                    document.getElementById('ContentPlaceHolder1_hdnPULatitude').value = myJsonString.result.geometry.location.lat;
                    document.getElementById('ContentPlaceHolder1_hdnPULongitude').value = myJsonString.result.geometry.location.lng;


                    if (typeArray == "airport") {
                        chkAirportPu = true;
                        document.getElementById('ContentPlaceHolder1_hdnPuAirportFullName').value = myJsonString.result.name;
                        for (var j = 0; j < myJsonString.result.address_components.length; j++) {
                            for (var m = 0; m < myJsonString.result.address_components[j].types.length; m++) {
                                var typeCountry = myJsonString.result.address_components[j].types[m];
                                if (typeCountry == "country") {
                                    document.getElementById('ContentPlaceHolder1_hdnPUAirportName').value = myJsonString.result.address_components[j].long_name;
                                }
                            }
                        }
                    }

                    if (typeArray == "establishment") {
                        if (myJsonString.result.hasOwnProperty('name')) {
                            document.getElementById('ContentPlaceHolder1_hdnPUAddress').value = myJsonString.result.name + " ," + myJsonString.result.formatted_address;
                        }
                    }
                    else {
                        document.getElementById('ContentPlaceHolder1_hdnPUAddress').value = myJsonString.result.formatted_address;
                    }

                    for (var n = 0; n < myJsonString.result.address_components.length; n++) {
                        for (var x = 0; x < myJsonString.result.address_components[n].types.length; x++) {
                            var tcnt = myJsonString.result.address_components[n].types[x];
                            var cntShort;
                            if (tcnt == "country") {
                                cntShort = myJsonString.result.address_components[n].short_name;
                            }
                            if (myJsonString.result.address_components[n].types == "postal_code") {
                                document.getElementById('ContentPlaceHolder1_hdnPUPostalCode').value = cntShort + " " + myJsonString.result.address_components[n].long_name;
                            }
                        }
                    }
                    var lt = myJsonString.result.geometry.location.lat;
                    var lng = myJsonString.result.geometry.location.lng;
                    latlongPu = new google.maps.LatLng(lt, lng);

                    //if (checkRetTrip == true) {
                    //    checkRetTrip = false;
                    //} else {
                    //    calcRoute("PickupAddress", latlongPu);
                    //}

                }
            }
        }

        if (chkAirportPu == true) {
            document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value = "Y";
            $("#divPickUpAirport").show();
        } else {
            document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value = "N";
            $("#divPickUpAirport").hide();
        }

        if (checkStreet == false) {
            bootbox.alert("<h4>Selected address is not street address</h4>");
            $('#dvLoading').hide();
            $("#PickupAddress").val('');
            $("#AirportForm").addClass('hidden');
        } else {
            if (checkRetTrip == true) {
                checkRetTrip = false;
            } else {
                calcRoute("PickupAddress", latlongPu);
            }
        }
    }
}

function failed_previous1(result) {
    var err = result.status + ' ' + result.statusText;
    return false;
}

function GetDOPostalWithAddress(placeid) {
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: proxy + HostName + "/EliteService.asmx/GetAddresswithPostalCode",
            data: "{ placeId: '" + placeid + "'}",
            success: succeeded_previousDO,
            error: failed_previousDO
        });
    return false;
}

var latlongDo = '';

function succeeded_previousDO(result) {

    if (result.d != "") {
        var myJsonString = JSON.parse(result.d);
        var typeArray;
        if (myJsonString.status == "OK") {
            for (var k = 0; k < myJsonString.result.types.length; k++) {
                typeArray = myJsonString.result.types[k];
                document.getElementById('ContentPlaceHolder1_hdnDOLatitude').value = myJsonString.result.geometry.location.lat;
                document.getElementById('ContentPlaceHolder1_hdnDOLongitude').value = myJsonString.result.geometry.location.lng;


                if (typeArray == "airport") {
                    chkAirportDo = true;
                    document.getElementById('ContentPlaceHolder1_hdnDOAirportFullName').value = myJsonString.result.name;
                    for (var j = 0; j < myJsonString.result.address_components.length; j++) {
                        for (var m = 0; m < myJsonString.result.address_components[j].types.length; m++) {
                            var typeCountry = myJsonString.result.address_components[j].types[m];
                            if (typeCountry == "country") {
                                document.getElementById('ContentPlaceHolder1_hdnDOAirportName').value = myJsonString.result.address_components[j].long_name;
                            }
                        }
                    }
                }

                if (typeArray == "establishment") {
                    if (myJsonString.result.hasOwnProperty('name')) {
                        document.getElementById('ContentPlaceHolder1_hdnDOAddress').value = myJsonString.result.name + " ," + myJsonString.result.formatted_address;
                    }
                }
                else {
                    document.getElementById('ContentPlaceHolder1_hdnDOAddress').value = myJsonString.result.formatted_address;
                }

                for (var n = 0; n < myJsonString.result.address_components.length; n++) {
                    for (var x = 0; x < myJsonString.result.address_components[n].types.length; x++) {
                        var tcnt = myJsonString.result.address_components[n].types[x];
                        var cntShort;
                        if (tcnt == "country") {
                            cntShort = myJsonString.result.address_components[n].short_name;
                        }
                        if (myJsonString.result.address_components[n].types == "postal_code") {
                            document.getElementById('ContentPlaceHolder1_hdnDOPostalCode').value = cntShort + " " + myJsonString.result.address_components[n].long_name;
                        }
                    }
                }
                var lt = myJsonString.result.geometry.location.lat;
                var lng = myJsonString.result.geometry.location.lng;
                latlongDo = new google.maps.LatLng(lt, lng);


                if (checkRetTrip == true) {
                    checkRetTrip = false;
                } else {
                    calcRoute("DropOffAddress", latlongDo);
                }
            }
        }

        if (chkAirportDo == true) {
            document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "Y";
            $("#divDropOffAirport").show();
        } else {
            document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "N";
            $("#divDropOffAirport").hide();
        }
    }
}

function failed_previousDO(result) {
    var err = result.status + ' ' + result.statusText;
    return false;
}

function chkTripType(obj) {
    if (obj == "anchorOneWay") {
        document.getElementById('ContentPlaceHolder1_hdnTripType').value = "Point to Point";
        //SSA One Way //
        document.getElementById("DropOffAddress").placeholder = "Drop-off Address";

        $('#divDOAdd').show();

    }
    else if (obj == "anchorRoundTrip") {
        document.getElementById('ContentPlaceHolder1_hdnTripType').value = "RoundTrip";
        //SSA Round Trip  //
        document.getElementById("DropOffAddress").placeholder = "Going To...";

        $('#divDOAdd').show();
    }
    else if (obj == "anchorHourly") {
        document.getElementById('ContentPlaceHolder1_hdnTripType').value = "Hourly";
        //SSA Hourly  //
        document.getElementById("DropOffAddress").placeholder = "Enter Furthest Point of Travel";

        if (document.getElementById("ContentPlaceHolder1_hdnIsLocal").value == "Y") {
            $('#divDOAdd').hide();
        } else {
            $('#divDOAdd').show();
        }

    }
}

var hdnLocal = "N";

function getIsLocal(obj) {
    if (obj.checked == true) {
        document.getElementById('ContentPlaceHolder1_hdnIsLocal').value = "Y";
        $('#DropOffAddress').val('');
        $('#divDOAdd').hide();
        $("#divDropOffAirport").hide();
        hdnLocal = "Y";
        if (placeIdForHourlyLocal != '') {
            GetPostalWithAddress(placeIdForHourlyLocal);
        }
        document.getElementById('ContentPlaceHolder1_hdnDOAddress').value = "";
        document.getElementById('ContentPlaceHolder1_hdnDOLatitude').value = "";
        document.getElementById('ContentPlaceHolder1_hdnDOLongitude').value = "";
        document.getElementById('ContentPlaceHolder1_hdnDOPostalCode').value = "";
        document.getElementById('ContentPlaceHolder1_hdnDOAirportName').value = "";
        document.getElementById('ContentPlaceHolder1_hdnDOAirportFullName').value = "";
        document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "N";
    }
    else {
        document.getElementById('ContentPlaceHolder1_hdnIsLocal').value = "N";
        $('#divDOAdd').show();
        hdnLocal = "N";
        //GetDOPostalWithAddress(placeIdForHourlyLocalDo);
    }
}

/*       function SelectSingleRadiobutton(rdbtnid) {
           var rdBtn = document.getElementById(rdbtnid);
    var rdBtnList = document.getElementsByTagName("input");
           for (i = 0; i < rdBtnList.length; i++) {
               if (rdBtnList[i].type == "radio" && rdBtnList[i].id != rdBtn.id) {
        rdBtnList[i].checked = false;
    }
}
}
*/
function SelectSingleRadiobutton(rdbtnid) {
    var rdBtn = document.getElementById(rdbtnid);
    var rdBtnList = document.getElementsByTagName("input");
    //SSA
    var booRadio;
    $('#chkBabySeat').prop('checked', true);
    for (i = 0; i < rdBtnList.length; i++) {
        if (rdBtnList[i].type == "radio" && rdBtnList[i].id != rdBtn.id) {
            rdBtnList[i].checked = false;
        }
        //SSA Added function to allow uncheck
        rdBtnList[i].onclick = function () {

            if (booRadio == this) {
                this.checked = false;
                booRadio = null;
            } else {
                booRadio = this;
            }
        };

    }
}

function validateAddress() {
    var puAdd = $('#PickupAddress').val();
    if (hdnLocal == 'Y') {
        if (puAdd == "") {
            bootbox.alert("<h4>Enter PickUp Address</h4>");
            $('#dvLoading').hide();
            return false;
        }

        if ($("#dp2").val() == "") {
            $("#dp2").css("border", "1px solid red");
            $("#dp2").focus();
            return false;
        } else {
            $("#dp2").css("border", "");
        }


        if ($("#timepicker6").val() == "") {
            $("#timepicker6").css("border", "1px solid red");
            $("#timepicker6").focus();
            return false;
        } else {
            $("#timepicker6").css("border", "");
        }


        if (document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value == "Y") {
            if (document.getElementById('ContentPlaceHolder1_chkbxPickInside').checked == false && document.getElementById('ContentPlaceHolder1_chkbxPickOutside').checked == false) {
                bootbox.alert("<h4>Please enter all Airport information</h4>");
                $('#dvLoading').hide();
                return false;
            }
            if ($("#ContentPlaceHolder1_drpdwnAirlineName").val() == "0") {
                $("#ContentPlaceHolder1_drpdwnAirlineName").css("border", "1px solid red");
                $("#ContentPlaceHolder1_drpdwnAirlineName").focus();
                return false;
            } else {
                $("#ContentPlaceHolder1_drpdwnAirlineName").css("border", "");
            }

            if ($("#ContentPlaceHolder1_txtPickFlightNumber").val() == "") {
                $("#ContentPlaceHolder1_txtPickFlightNumber").css("border", "1px solid red");
                $("#ContentPlaceHolder1_txtPickFlightNumber").focus();
                return false;
            } else {
                $("#ContentPlaceHolder1_txtPickFlightNumber").css("border", "");
            }

            if ($("#ContentPlaceHolder1_txtPickArrivingFrom").val() == "") {
                $("#ContentPlaceHolder1_txtPickArrivingFrom").css("border", "1px solid red");
                $("#ContentPlaceHolder1_txtPickArrivingFrom").focus();
                return false;
            } else {
                $("#ContentPlaceHolder1_txtPickArrivingFrom").css("border", "");
            }

        }

    } else {
        var doAdd = $('#DropOffAddress').val();
        if (puAdd == "") {
            bootbox.alert("<h4>Enter PickUp Address</h4>");
            $('#dvLoading').hide();
            return false;
        }
        if (doAdd == "") {
            bootbox.alert("<h4>Enter DropOff Address</h4>");
            $('#dvLoading').hide();
            return false;
        }

        if ($("#dp2").val() == "") {
            $("#dp2").css("border", "1px solid red");
            $("#dp2").focus();
            return false;
        } else {
            $("#dp2").css("border", "");
        }

        if ($("#timepicker6").val() == "") {
            $("#timepicker6").css("border", "1px solid red");
            $("#timepicker6").focus();
            return false;
        } else {
            $("#timepicker6").css("border", "");
        }


        if (document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value == "Y") {
            if (document.getElementById('ContentPlaceHolder1_chkbxPickInside').checked == false && document.getElementById('ContentPlaceHolder1_chkbxPickOutside').checked == false) {
                bootbox.alert("<h4>Please enter all Airport information</h4>");
                $('#dvLoading').hide();
                return false;
            }
            if ($("#ContentPlaceHolder1_drpdwnAirlineName").val() == "0") {
                $("#ContentPlaceHolder1_drpdwnAirlineName").css("border", "1px solid red");
                $("#ContentPlaceHolder1_drpdwnAirlineName").focus();
                return false;
            } else {
                $("#ContentPlaceHolder1_drpdwnAirlineName").css("border", "");
            }

            if ($("#ContentPlaceHolder1_txtPickFlightNumber").val() == "") {
                $("#ContentPlaceHolder1_txtPickFlightNumber").css("border", "1px solid red");
                $("#ContentPlaceHolder1_txtPickFlightNumber").focus();
                return false;
            } else {
                $("#ContentPlaceHolder1_txtPickFlightNumber").css("border", "");
            }

            if ($("#ContentPlaceHolder1_txtPickArrivingFrom").val() == "") {
                $("#ContentPlaceHolder1_txtPickArrivingFrom").css("border", "1px solid red");
                $("#ContentPlaceHolder1_txtPickArrivingFrom").focus();
                return false;
            } else {
                $("#ContentPlaceHolder1_txtPickArrivingFrom").css("border", "");
            }

        }

        if (chkAirportDo == true) {
            if ($("#ContentPlaceHolder1_drpdwnAirlineNameDO").val() == "0") {
                $("#ContentPlaceHolder1_drpdwnAirlineNameDO").css("border", "1px solid red");
                $("#ContentPlaceHolder1_drpdwnAirlineNameDO").focus();
                return false;
            } else {
                $("#ContentPlaceHolder1_drpdwnAirlineNameDO").css("border", "");
            }

            //if ($("#ContentPlaceHolder1_txtDropFlightNumber").val() == "") {
            //    $("#ContentPlaceHolder1_txtDropFlightNumber").css("border", "1px solid red");
            //    $("#ContentPlaceHolder1_txtDropFlightNumber").focus();
            //    return false;
            //} else {
            //    $("#ContentPlaceHolder1_txtDropFlightNumber").css("border", "");
            //}

            if ($("#ContentPlaceHolder1_txtDropFlyingTo").val() == "") {
                $("#ContentPlaceHolder1_txtDropFlyingTo").css("border", "1px solid red");
                $("#ContentPlaceHolder1_txtDropFlyingTo").focus();
                return false;
            } else {
                $("#ContentPlaceHolder1_txtDropFlyingTo").css("border", "");
            }
        }
    }
}

function GetParameterValues(param) {
    var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < url.length; i++) {
        var urlparam = url[i].split('=');
        if (urlparam[0] == param) {
            return urlparam[1];
        }
    }
}

var pickAdd = '';
var dropAdd = '';


function EditBookaCarInformation(rstInfo) {
    editBookacarInformation = rstInfo;
}

var pickGPS;
var dropGPS;

var retTrip;
var checkRetTrip = false;
function EditBookaCarInformationFromInit(restInfo) {
    $('#dvLoading').show();
    var myJsonString = restInfo;
    if (myJsonString != "") {
        //check trip type 1=Point to Point, 2=Hourly, 3=RoundTrip
        pickAdd = myJsonString.PickupLocation;
        dropAdd = myJsonString.DropOffLocation;

        //point to point
        if (myJsonString.TripType == "1") {
            $("#tab_1_contents").addClass('tab_contents_active');
            $("#tab_2_contents").removeClass('tab_contents_active');
            $("#tab_3_contents").removeClass('tab_contents_active');
            var date = new Date(myJsonString.ResTime);
            var fulldate = (('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear());
            $("#dp2").val(fulldate);
            document.getElementById('ContentPlaceHolder1_txtDate').value = $("#dp2").val();
            var time = getCurrentTime(date.getTime());
            $('#timepicker6').val(time);
            document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = $('#timepicker6').val();
            document.getElementById('ContentPlaceHolder1_hdnTripType').value = "Point to Point";
        }
        //Hourly
        if (myJsonString.TripType == "2") {
            $("#lioneWay").removeClass('active');
            $("#lihourly").addClass('active');
            $("#tab_1_contents").addClass('tab_contents_active');
            $("#tab_2_contents").removeClass('tab_contents_active');
            $("#tab_3_contents").addClass('tab_contents_active');
            var date = new Date(myJsonString.ResTime);
            var fulldate1 = (('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear());
            $("#dp2").val(fulldate1);
            var time1 = getCurrentTime(date.getTime());
            $('#timepicker6').val(time1);
            document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = $('#timepicker6').val();
            document.getElementById('ContentPlaceHolder1_hdnTripType').value = "Hourly";
            document.getElementById('ContentPlaceHolder1_txtDate').value = $("#dp2").val();
            document.getElementById('ContentPlaceHolder1_drpdwnHours').value = myJsonString.Hours / 60 + ':00 hrs';
            if (myJsonString.IsLocal == "Y") {
                document.getElementById("switch1").checked = true;
                getIsLocal(document.getElementById("switch1"));
                $('#divDOAdd').hide();
                document.getElementById('ContentPlaceHolder1_hdnDOAddress').value = "";
                document.getElementById('ContentPlaceHolder1_hdnDOLatitude').value = "";
                document.getElementById('ContentPlaceHolder1_hdnDOLongitude').value = "";
                document.getElementById('ContentPlaceHolder1_hdnDOPostalCode').value = "";
                document.getElementById('ContentPlaceHolder1_hdnDOAirportName').value = "";
                document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "N";
            } else {
                document.getElementById("switch1").checked = false;
                getIsLocal(document.getElementById("switch1"));
                $('#divDOAdd').show();
            }
        }

        //RoundTrip
        if (myJsonString.TripType == "3") {
            $("#lioneWay").removeClass('active');
            $("#litwoWay").addClass('active');
            $("#tab_1_contents").addClass('tab_contents_active');
            $("#tab_2_contents").addClass('tab_contents_active');
            $("#tab_3_contents").removeClass('tab_contents_active');
            var date = new Date(myJsonString.ResTime);
            var fulldate2 = (('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear());
            $("#dp2").val(fulldate2);
            document.getElementById('ContentPlaceHolder1_txtDate').value = $("#dp2").val();
            var time2 = getCurrentTime(date.getTime());
            $('#timepicker6').val(time2);
            document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = $('#timepicker6').val();
            document.getElementById('ContentPlaceHolder1_hdnTripType').value = "RoundTrip";
            document.getElementById('ContentPlaceHolder1_drpdownCarWait').value = myJsonString.CarWait;
        }
        debugger;
        //show map root from pick up and drop off address
        pickGPS = pickAdd.GPS;
        var pickLatlong = new google.maps.LatLng(pickGPS.Latitude, pickGPS.Longitude);
        latlongPu = pickLatlong;

        dropGPS = dropAdd.GPS;
        var dropLatlong = new google.maps.LatLng(dropGPS.Latitude, dropGPS.Longitude);
        latlongDo = dropLatlong;


        placeIdForHourlyLocal = pickAdd.ReferenceNum;


        var paddre = pickAdd.FullAddress;
        paddre = paddre.substr(0, 32) + '...';

        var daddre = dropAdd.FullAddress;
        daddre = daddre.substr(0, 32) + '...';


        retTrip = GetParameterValues('retTrip');//on return trip it will swap value pict to drop and drop to pick
        if (retTrip != null) {
            debugger;
            checkRetTrip = true;
            $("#PickupAddress").val(daddre);
            $("#DropOffAddress").val(paddre);
            //document.getElementById('ContentPlaceHolder1_hdnDOAddress').value = pickAdd.FullAddress;
            // document.getElementById('ContentPlaceHolder1_hdnPUAddress').value = dropAdd.FullAddress;

            // document.getElementById('ContentPlaceHolder1_hdnDOLatitude').value = pickGPS.Latitude;
            //document.getElementById('ContentPlaceHolder1_hdnDOLongitude').value = pickGPS.Longitude;
            // document.getElementById('ContentPlaceHolder1_hdnDOPostalCode').value = pickAdd.PostalCode;
            // document.getElementById('ContentPlaceHolder1_hdnDOAirportName').value = myJsonString.AirportName;

            //  document.getElementById('ContentPlaceHolder1_hdnPULatitude').value = dropGPS.Latitude;
            // document.getElementById('ContentPlaceHolder1_hdnPULongitude').value = dropGPS.Longitude;
            // document.getElementById('ContentPlaceHolder1_hdnPUPostalCode').value = dropAdd.PostalCode;

            // document.getElementById('ContentPlaceHolder1_hdnPUAirportName').value = myJsonString.DOAirportName;
            document.getElementById('ContentPlaceHolder1_hdnPuPlaceId').value = dropAdd.ReferenceNum;
            document.getElementById('ContentPlaceHolder1_hdnDoPlaceId').value = pickAdd.ReferenceNum;

            GetPostalWithAddress(dropAdd.ReferenceNum);
            GetDOPostalWithAddress(pickAdd.ReferenceNum);

            if (dropGPS.Latitude == 0 && dropGPS.Longitude == 0) {

                var image;
                image = 'Images/pin_pickup_location.png';

                var myOptions = {
                    zoom: 15,
                    center: pickLatlong,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                var map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);
                var marker = new google.maps.Marker({
                    position: pickLatlong,
                    map: map,
                    icon: image,
                    title: 'Mapped Location'
                });
            } else {
                editDirection(dropLatlong, pickLatlong);
            }

            if (pickAdd.IsAirport == "Y") {
                document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "Y";
                $("#divDropOffAirport").show();

                //change airport value

                $("#divPickUpAirport").hide();
            } else {
                document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "N";
            }

            if (dropAdd.IsAirport == "Y") {
                document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value = "Y";
                $("#divDropOffAirport").hide();

                //change airport value

                $("#divPickUpAirport").show();
            } else {
                document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value = "N";
            }

        } else {
            $("#PickupAddress").val(paddre);
            $("#DropOffAddress").val(daddre);
            // document.getElementById('ContentPlaceHolder1_hdnDOAddress').value = dropAdd.FullAddress;
            //document.getElementById('ContentPlaceHolder1_hdnPUAddress').value = pickAdd.FullAddress;

            // document.getElementById('ContentPlaceHolder1_hdnDOLatitude').value = dropGPS.Latitude;
            // document.getElementById('ContentPlaceHolder1_hdnDOLongitude').value = dropGPS.Longitude;
            //  document.getElementById('ContentPlaceHolder1_hdnDOPostalCode').value = dropAdd.PostalCode;
            // document.getElementById('ContentPlaceHolder1_hdnDOAirportName').value = myJsonString.DOAirportName;

            //document.getElementById('ContentPlaceHolder1_hdnPULatitude').value = pickGPS.Latitude;
            // document.getElementById('ContentPlaceHolder1_hdnPULongitude').value = pickGPS.Longitude;
            // document.getElementById('ContentPlaceHolder1_hdnPUPostalCode').value = pickAdd.PostalCode;
            // document.getElementById('ContentPlaceHolder1_hdnPUAirportName').value = myJsonString.AirportName;

            document.getElementById('ContentPlaceHolder1_hdnPuPlaceId').value = pickAdd.ReferenceNum;
            document.getElementById('ContentPlaceHolder1_hdnDoPlaceId').value = dropAdd.ReferenceNum;

            GetPostalWithAddress(pickAdd.ReferenceNum);
            GetDOPostalWithAddress(dropAdd.ReferenceNum);

            if (dropGPS.Latitude == 0 && dropGPS.Longitude == 0) {
                var myOptions = {
                    zoom: 15,
                    center: pickLatlong,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                var map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);
                var marker = new google.maps.Marker({
                    position: pickLatlong,
                    map: map,
                    title: 'Mapped Location'
                });
            } else {
                editDirection(pickLatlong, dropLatlong);
            }
            if (pickAdd.IsAirport == "Y") {
                $("#divPickUpAirport").show();
                document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value = "Y";
                document.getElementById('ContentPlaceHolder1_drpdwnAirlineName').value = myJsonString.AirlineName;
                document.getElementById('ContentPlaceHolder1_txtPickFlightNumber').value = myJsonString.FlightNumber;
                document.getElementById('ContentPlaceHolder1_txtPickTerminal').value = myJsonString.TerminalNum;
                document.getElementById('ContentPlaceHolder1_txtPickArrivingFrom').value = myJsonString.ArrivingFrom;



                //airport PUpolicy inside airport pickup  //I=Inside, O=Outside, S=StandBy
                if (myJsonString.AirportPUPolicy == "I") {
                    document.getElementById('ContentPlaceHolder1_chkbxPickInside').checked = true;
                    $('#c1').attr('checked', true);
                    $('#c2').attr('checked', false);
                }
                if (myJsonString.AirportPUPolicy == "O") {
                    document.getElementById('ContentPlaceHolder1_chkbxPickOutside').checked = true;
                    $('#c1').attr('checked', false);
                    $('#c2').attr('checked', true);
                }
                if (myJsonString.AirportPUPolicy == "S") {
                    $('#c1').attr('checked', false);
                    $('#c2').attr('checked', false);
                }

            } else {
                document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value = "N";
                $("#divPickUpAirport").hide();
            }

            //if drop off place is airport then show airport value
            if (dropAdd.IsAirport == "Y") {
                $("#divDropOffAirport").show();
                document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "Y";
                document.getElementById('ContentPlaceHolder1_drpdwnAirlineNameDO').value = myJsonString.DOAirlineName;
                document.getElementById('ContentPlaceHolder1_txtDropFlightNumber').value = myJsonString.DOFlightNum;
                document.getElementById('ContentPlaceHolder1_txtDropFlyingTo').value = myJsonString.DODestCity;

                if (myJsonString.AirportPUPolicy == "I") {
                    document.getElementById('ContentPlaceHolder1_chkbxPickInside').checked = true;
                    $('#c1').attr('checked', true);
                    $('#c2').attr('checked', false);
                }
                if (myJsonString.AirportPUPolicy == "O") {
                    document.getElementById('ContentPlaceHolder1_chkbxPickOutside').checked = true;
                    $('#c1').attr('checked', false);
                    $('#c2').attr('checked', true);
                }
                if (myJsonString.AirportPUPolicy == "S") {
                    $('#c1').attr('checked', false);
                    $('#c2').attr('checked', false);
                }
            } else {
                document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "N";
                $("#divDropOffAirport").hide();
            }
        }

        //if pick up place is airport then show airport value
        //NOSUV, PACKAGE, CARSEAT-INFANT, CARSEAT-TODDLER, CARSEAT-BOOSTER, GWT, WHEELCHAIR, PETS, GUARENTEED RESERVATION

        if (myJsonString.SpecialRequest != "") {
            var specReq = myJsonString.SpecialRequest;
            for (var i = 0; i < specReq.length; i++) {
                if (specReq[i] == "NOSUV") {
                    document.getElementById('chkbxNoSuv').checked = true;
                    document.getElementById('chkNosuv').checked = true;
                }
                if (specReq[i] == "PACKAGE") {
                    var packageInfo = myJsonString.PackageInfo;
                    document.getElementById('chkBxPackge').checked = true;
                    document.getElementById("chkBxPackage").checked = true;
                    document.getElementById('ContentPlaceHolder1_txtPackageRecepientName').value = packageInfo.RecipientName;
                    document.getElementById('ContentPlaceHolder1_txtPackagePhoneNumaber').value = packageInfo.PhoneNum;
                    document.getElementById('ContentPlaceHolder1_drpdwnPackage').value = packageInfo.PackageWeight;
                    document.getElementById('ContentPlaceHolder1_txtPackageDeliveryInstr').value = packageInfo.DeliveryInstruction;
                }
                if (specReq[i] == "CARSEAT-INFANT") {
                    document.getElementById('ContentPlaceHolder1_radioInfant').checked = true;
                    document.getElementById('chkBabySeat').checked = true;
                }
                if (specReq[i] == "CARSEAT-TODDLER") {
                    document.getElementById('ContentPlaceHolder1_radioToddler').checked = true;
                    document.getElementById('chkBabySeat').checked = true;
                }
                if (specReq[i] == "CARSEAT-BOOSTER") {
                    document.getElementById('ContentPlaceHolder1_radioBooster').checked = true;
                    document.getElementById('chkBabySeat').checked = true;
                }
                if (specReq[i] == "GWT") {
                    document.getElementById('chkbxGuaranteedWaitingTime').checked = true;
                    document.getElementById('chkBxGwt').checked = true;
                }

                if (specReq[i] == "WHEELCHAIR") {
                    document.getElementById('chkbxWheelChair').checked = true;
                }
                if (specReq[i] == "PETS") {
                    document.getElementById('chkbxPet').checked = true;
                }
                if (specReq[i] == "GUARENTEED RESERVATION") {
                    $('#radioBooster').attr('checked', true);
                }
            }
        }
    }
    $('#dvLoading').hide();
    return false;
}

function editDirection(startAdd, endAdd) {
    directionsService = new google.maps.DirectionsService();
    var mapOptions = {
        zoom: 15
    };
    map = new google.maps.Map(document.getElementById('gmap_canvas'), mapOptions);
    var rendererOptions = {
        map: map,
        suppressMarkers: true
    };

    //var icons = {
    //    start: new google.maps.MarkerImage(
    //     // URL
    //     'img/pin_pickup_location.png'),
    //    end: new google.maps.MarkerImage(
    //     // URL
    //     'img/pin_drop_off_location.png')
    //};

    directionsDisplay = new google.maps.DirectionsRenderer(rendererOptions);
    //stepDisplay = new google.maps.InfoWindow();

    var request = {
        origin: startAdd,
        destination: endAdd,
        travelMode: google.maps.TravelMode.DRIVING
    };
    directionsService.route(request, function (response, status) {
        if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
            var leg = response.routes[0].legs[0];
            makeMarker(leg.start_location, "pickup location");
            makeMarker(leg.end_location, "dropoff location");
        }
    });
}

function makeMarker(position, title) {
    var image;
    if (title == "pickup location") {
        image = "Images/pin_pickup_location.png";
        new google.maps.Marker({
            position: position,
            map: map,
            icon: image,
            title: title
        });
    }
    else {
        image = "Images/pin_drop_off_location.png";
        new google.maps.Marker({
            position: position,
            map: map,
            icon: image,
            title: title
        });
    }

}

//get curent time from json //where e= json value
function getCurrentTime(e) {
    var time = new Date(parseInt(e));
    var day = time.getDate();
    var month = time.getMonth() + 1;
    var year = time.getFullYear();
    var minutes = time.getMinutes();
    var hours = time.getHours();
    var seconds = time.getSeconds();
    if (seconds.toString().length == 1) {
        seconds = "0" + seconds;
    }
    if (minutes.toString().length == 1) {
        minutes = "0" + minutes;
    }
    if (hours.toString().length == 1) {
        hours = "0" + hours;
    }
    if (day.toString().length == 1) {
        day = "0" + day;
    }
    if (month.toString().length == 1) {
        month = "0" + month;
    }
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    time = ('0' + hours).slice(-2) + ':' + minutes.toString() + ' ' + ampm;
    return time;
}



function EditCheckRatesInformation(chkRTInfo) {
    editCheckRatesInformation = chkRTInfo;
}

function EditCheckRatesInformationFromInit(chkRateInfo) {
    $('#dvLoading').show();
    var myJsonString = chkRateInfo;
    if (myJsonString != "") {
        //check trip type 1=Point to Point, 2=Hourly, 3=RoundTrip
        //point to point

        //for address only
        pickAdd = myJsonString.StartLocation;
        dropAdd = myJsonString.EndLocation;
        var paddre = pickAdd.FullAddress;
        paddre = paddre.substr(0, 32) + '...';

        var daddre = dropAdd.FullAddress;
        daddre = daddre.substr(0, 32) + '...';


        if (myJsonString.TripType == "1") {
            $("#tab_1_contents").addClass('tab_contents_active');
            $("#tab_2_contents").removeClass('tab_contents_active');
            $("#tab_3_contents").removeClass('tab_contents_active');
            $("#PickupAddress").val(paddre);
            $("#DropOffAddress").val(daddre);
            var date = new Date(myJsonString.ResTime);
            var fulldate = (('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear());
            $("#dp2").val(fulldate);
            document.getElementById('ContentPlaceHolder1_txtDate').value = $("#dp2").val();
            var time = getCurrentTime(date.getTime());
            $('#timepicker6').val(time);
            document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = $('#timepicker6').val();
            document.getElementById('ContentPlaceHolder1_hdnTripType').value = "Point to Point";
        }

        //hourly
        if (myJsonString.TripType == "2") {
            $("#lioneWay").removeClass('active');
            $("#lihourly").addClass('active');
            $("#tab_1_contents").addClass('tab_contents_active');
            $("#tab_2_contents").removeClass('tab_contents_active');
            $("#tab_3_contents").addClass('tab_contents_active');
            $("#PickupAddress").val(paddre);
            $("#DropOffAddress").val(daddre);
            var date = new Date(myJsonString.ResTime);
            var fulldate1 = (('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear());
            $("#dp2").val(fulldate1);
            document.getElementById('ContentPlaceHolder1_txtDate').value = $("#dp2").val();
            var time1 = getCurrentTime(date.getTime());
            $('#timepicker6').val(time1);
            document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = $('#timepicker6').val();
            document.getElementById('ContentPlaceHolder1_drpdwnHours').value = myJsonString.Hours / 60 + ':00 hrs';
            document.getElementById('ContentPlaceHolder1_hdnTripType').value = "Hourly";
            if (myJsonString.IsLocal == "Y") {
                document.getElementById("switch1").checked = true;
                getIsLocal(document.getElementById("switch1"));
                $('#divDOAdd').hide();
                document.getElementById('ContentPlaceHolder1_hdnDOAddress').value = "";
                document.getElementById('ContentPlaceHolder1_hdnDOLatitude').value = "";
                document.getElementById('ContentPlaceHolder1_hdnDOLongitude').value = "";
                document.getElementById('ContentPlaceHolder1_hdnDOPostalCode').value = "";
                document.getElementById('ContentPlaceHolder1_hdnDOAirportName').value = "";
                document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "N";
            } else {
                document.getElementById("switch1").checked = false;
                getIsLocal(document.getElementById("switch1"));
                $('#divDOAdd').show();
            }
        }

        //round trip
        if (myJsonString.TripType == "3") {
            $("#lioneWay").removeClass('active');
            $("#litwoWay").addClass('active');
            $("#tab_1_contents").addClass('tab_contents_active');
            $("#tab_2_contents").addClass('tab_contents_active');
            $("#tab_3_contents").removeClass('tab_contents_active');
            $("#PickupAddress").val(paddre);
            $("#DropOffAddress").val(daddre);
            var date = new Date(myJsonString.ResTime);
            var fulldate2 = (('0' + (date.getMonth() + 1)).slice(-2) + '/' + ('0' + date.getDate()).slice(-2) + '/' + date.getFullYear());
            $("#dp2").val(fulldate2);
            document.getElementById('ContentPlaceHolder1_txtDate').value = $("#dp2").val();
            var time2 = getCurrentTime(date.getTime());
            $('#timepicker6').val(time2);
            document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = $('#timepicker6').val();
            document.getElementById('ContentPlaceHolder1_hdnTripType').value = "RoundTrip";
            document.getElementById('ContentPlaceHolder1_drpdownCarWait').value = myJsonString.CarWait;
        }

        pickGPS = pickAdd.GPS;
        var pickLatlong = new google.maps.LatLng(pickGPS.Latitude, pickGPS.Longitude);
        latlongPu = pickLatlong;

        dropGPS = dropAdd.GPS;
        var dropLatlong = new google.maps.LatLng(dropGPS.Latitude, dropGPS.Longitude);
        latlongDo = dropLatlong;

        placeIdForHourlyLocal = pickAdd.ReferenceNum;
        GetPostalWithAddress(pickAdd.ReferenceNum);
        GetDOPostalWithAddress(dropAdd.ReferenceNum);
        //document.getElementById('ContentPlaceHolder1_hdnPuPlaceId').value = pickAdd.ReferenceNum;
        // document.getElementById('ContentPlaceHolder1_hdnDoPlaceId').value = dropAdd.ReferenceNum;
        // document.getElementById('ContentPlaceHolder1_hdnDOAddress').value = dropAdd.FullAddress;
        // document.getElementById('ContentPlaceHolder1_hdnDOLatitude').value = dropGPS.Latitude;
        // document.getElementById('ContentPlaceHolder1_hdnDOLongitude').value = dropGPS.Longitude;
        // document.getElementById('ContentPlaceHolder1_hdnDOPostalCode').value = dropAdd.PostalCode;
        // document.getElementById('ContentPlaceHolder1_hdnDOAirportName').value = myJsonString.DOAirportName;

        // document.getElementById('ContentPlaceHolder1_hdnPUAddress').value = pickAdd.FullAddress;
        // document.getElementById('ContentPlaceHolder1_hdnPULatitude').value = pickGPS.Latitude;
        //  document.getElementById('ContentPlaceHolder1_hdnPULongitude').value = pickGPS.Longitude;
        //  document.getElementById('ContentPlaceHolder1_hdnPUPostalCode').value = pickAdd.PostalCode;
        //  document.getElementById('ContentPlaceHolder1_hdnPUAirportName').value = myJsonString.PUAirportName;

        //show map root from pick up and drop off address
        if (dropGPS.Latitude == 0 && dropGPS.Longitude == 0) {
            var myOptions = {
                zoom: 15,
                center: pickLatlong,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            var map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);
            var marker = new google.maps.Marker({
                position: pickLatlong,
                map: map,
                title: 'Mapped Location'
            });
        } else {
            editDirection(pickLatlong, dropLatlong);
        }

        //if pick up place is airport then show airport value
        if (myJsonString.IsAirportPU == "Y") {
            $("#divPickUpAirport").show();
            document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value = "Y";
            document.getElementById('ContentPlaceHolder1_drpdwnAirlineName').value = myJsonString.AirlineName;
            document.getElementById('ContentPlaceHolder1_txtPickFlightNumber').value = myJsonString.FlightNumber;
            document.getElementById('ContentPlaceHolder1_txtPickTerminal').value = myJsonString.TerminalNum;
            document.getElementById('ContentPlaceHolder1_txtPickArrivingFrom').value = myJsonString.ArrivingFrom;

            // airport PUpolicy inside airport pickup  //I=Inside, O=Outside, S=StandBy
            if (myJsonString.AirportPUPolicy == "I") {
                document.getElementById('ContentPlaceHolder1_chkbxPickInside').checked = true;
                $('#c1').attr('checked', true);
                $('#c2').attr('checked', false);
            }
            if (myJsonString.AirportPUPolicy == "O") {
                document.getElementById('ContentPlaceHolder1_chkbxPickOutside').checked = true;
                $('#c1').attr('checked', false);
                $('#c2').attr('checked', true);
            }
            if (myJsonString.AirportPUPolicy == "S") {
                $('#c1').attr('checked', false);
                $('#c2').attr('checked', false);
            }
        } else {
            document.getElementById('ContentPlaceHolder1_hdnIsAirportPu').value = "N";
            $("#divPickUpAirport").hide();
        }

        //if drop off place is airport then show airport value
        if (myJsonString.IsAirportDO == "Y") {
            $("#divDropOffAirport").show();
            document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "Y";
            document.getElementById('ContentPlaceHolder1_drpdwnAirlineNameDO').value = myJsonString.DOAirlineName;
            document.getElementById('ContentPlaceHolder1_txtDropFlightNumber').value = myJsonString.DOFlightNum;
            document.getElementById('ContentPlaceHolder1_txtDropFlyingTo').value = myJsonString.DODestCity;

            if (myJsonString.AirportPUPolicy == "I") {
                document.getElementById('ContentPlaceHolder1_chkbxPickInside').checked = true;
                $('#c1').attr('checked', true);
                $('#c2').attr('checked', false);
            }
            if (myJsonString.AirportPUPolicy == "O") {
                document.getElementById('ContentPlaceHolder1_chkbxPickOutside').checked = true;
                $('#c1').attr('checked', false);
                $('#c2').attr('checked', true);
            }
            if (myJsonString.AirportPUPolicy == "S") {
                $('#c1').attr('checked', false);
                $('#c2').attr('checked', false);
            }

        } else {
            document.getElementById('ContentPlaceHolder1_hdnIsAirportDo').value = "N";
            $("#divDropOffAirport").hide();
        }
    }
    //if pick up place is airport then show airport value
    //NOSUV, PACKAGE, CARSEAT-INFANT, CARSEAT-TODDLER, CARSEAT-BOOSTER, GWT, WHEELCHAIR, PETS, GUARENTEED RESERVATION

    if (myJsonString.SpecialRequest != "") {
        var specReq = myJsonString.SpecialRequest;
        for (var i = 0; i < specReq.length; i++) {
            if (specReq[i] == "NOSUV") {
                document.getElementById('chkbxNoSuv').checked = true;
                document.getElementById('chkNosuv').checked = true;
            }
            if (specReq[i] == "PACKAGE") {
                //var packageInfo = myJsonString.PackageInfo;
                document.getElementById('chkBxPackge').checked = true;
                document.getElementById("chkBxPackage").checked = true;
                //document.getElementById('ContentPlaceHolder1_txtPackageRecepientName').value = packageInfo.RecipientName;
                //document.getElementById('ContentPlaceHolder1_txtPackagePhoneNumaber').value = packageInfo.PhoneNum;
                //document.getElementById('ContentPlaceHolder1_drpdwnPackage').value = packageInfo.PackageWeight;
                //document.getElementById('ContentPlaceHolder1_txtPackageDeliveryInstr').value = packageInfo.DeliveryInstruction;
            }
            if (specReq[i] == "CARSEAT-INFANT") {
                document.getElementById('ContentPlaceHolder1_radioInfant').checked = true;
                document.getElementById('chkBabySeat').checked = true;
            }
            if (specReq[i] == "CARSEAT-TODDLER") {
                document.getElementById('ContentPlaceHolder1_radioToddler').checked = true;
                document.getElementById('chkBabySeat').checked = true;
            }
            if (specReq[i] == "CARSEAT-BOOSTER") {
                document.getElementById('ContentPlaceHolder1_radioBooster').checked = true;
                document.getElementById('chkBabySeat').checked = true;
            }
            if (specReq[i] == "GWT") {
                document.getElementById('chkbxGuaranteedWaitingTime').checked = true;
                document.getElementById('chkBxGwt').checked = true;
            }

            if (specReq[i] == "WHEELCHAIR") {
                document.getElementById('chkbxWheelChair').checked = true;
            }

            if (specReq[i] == "PETS") {
                document.getElementById('chkbxPet').checked = true;
            }
            if (specReq[i] == "GUARENTEED RESERVATION") {
                $('#radioBooster').attr('checked', true);
            }
        }
    }

    $('#dvLoading').hide();
    return false;
}
function ScrollToPickup() {
    //window.scrollTo(0,$("#PickupAddress").offset().top);
}
function activateCalendar() {
    $('#dp2').datepicker('show');
    $("#dp2").attr("autocomplete", "off");
};

function activateTime() {
    $('#timepicker6').timepicker("showWidget");
    $("#timepicker6").attr("autocomplete", "off");
};
function authUserChanged() {
    var selectBox = document.getElementById("AuthorizedUsers");
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;
    switchUser(selectedValue);
}
function SetupAuthorizedUsers(authorizedUsersList) {
    docAuthorizedUsers = document.getElementById('AuthorizedUsers');
    //var authorizedUsersList = results.AuthorizedUserList;
    var vAuthorizedUsersList = JSON.parse(authorizedUsersList);
    if (vAuthorizedUsersList.length <= 1 || vAuthorizedUsersList == null) {
        $("#divAuthorizedUsers").hide();
        return;
    }
    for (var i = 0; i < vAuthorizedUsersList.length; i++) {
        var authUser = vAuthorizedUsersList[i];
        var opt = document.createElement('option');
        opt.value = authUser.UserID;
        opt.innerHTML = authUser.FirstName + " " + authUser.LastName;
        docAuthorizedUsers.appendChild(opt);
    }
}
function switchUser(UserID) {

    $('#dvLoading').show();
    $('#dvLoading').css('display', 'block');
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: proxy + HostName + "/EliteService.asmx/Login",
            data: "{emailAddress: '" + UserID + "',passWord:'" + "SWITCH" + "',rememberMe:'" + "false" + "' }",
            success: succ_switchuser_login,
            error: fail_switchuser_login
        });

    return false;
}

function succ_switchuser_login(result) {
    if (result.d != "") {
        var myJsonString = JSON.parse(result.d);
        if (myJsonString != null) {
            var code = myJsonString.Code;
            if (myJsonString.Code == "1") {
                //window.location = "MyProfile.aspx";
                window.location.href = "Book-a-car.aspx";
                $('#dvLoading').hide();
            }
            else {
                bootbox.alert("<h4>" + myJsonString.Message + "</h4>");
                //var tooltip = document.getElementById("tooltip1");
                //tooltip.innerHTML = myJsonString.Message;
                //tooltip.style.display = "block";
                //setTimeout(function () {
                //    tooltip.style.display = "none";
                //}, 3000);

            }
            $('#dvLoading').hide();
            return false;
        }

    }
}

function fail_switchuser_login(result) {
    var err = result.status + ' ' + result.statusText;
    $('#dvLoading').hide();
    return false;
}

var airportType;
var airportTypeDo;
var directionsService;
var directionsDisplay;
var geocoder;
var map;
var map2    //initialize
var latDO;  //latitude dropoff
var lngDO;  //longitude dropoff
var originPickUp;
var destinationDropOff;
var resultList = [];

var stepDisplay;

function disableEnter1(e) {
    //var code = (e.keyCode ? e.keyCode : e.which);
    //if (code == 13) { //Enter keycode
    //    return false;
    //}
}

var nowDate = new Date();
var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);

$(document).ready(function () {

    //$("#liMyProfile").removeClass("active");
    //$("#liBookaCar").addClass("active");

    //$('#dp2').datepicker().on("changeDate", function (ev) {
    //    if (today <= ev.date.valueOf()) {
    //        document.getElementById('ContentPlaceHolder1_txtDate').value = $("#dp2").val();
    //        $('#timepicker6').focus();
    //    }
    //    else {
    //        bootbox.alert("<h4>You can not select previous date</h4>");
    //        $('#dvLoading').hide();
    //        $("#dp2").val('');
    //    }
    //    $('#dp2').datepicker('hide');
    //});

    //$('#dp2').keydown(function (e) {
    //    var keyCode = e.keyCode || e.which;
    //    if (keyCode == 9) {
    //        e.preventDefault();
    //        $('#dp2').datepicker('hide');
    //        $('#timepicker6').focus();
    //    }
    //});

    //$('#timepicker6').timepicker({
    //    minuteStep: 5,
    //    showInputs: true,
    //    showMeridian: true,
    //});

    //$('#timepicker6').click(function (ev) {
    //    document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = $('#timepicker6').val();
    //});

    var $div1 = $('#divSearchPickUp');
    var $div2 = $('#divSearchDropOff');
    if (!$div1.has(this).length) { // if the click was not within $div
        $div1.hide();
    }

    //if (!$div2.has(this).length) { // if the click was not within $div
    //    $div2.hide();
    //}

    //$("#ContentPlaceHolder1_txtPackagePhoneNumaber").keydown(function (e) {
    //    // Allow: backspace, delete, tab, escape, enter and .
    //    if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
    //        // Allow: Ctrl+A
    //        (e.keyCode == 65 && e.ctrlKey === true) ||
    //        // Allow: home, end, left, right, down, up
    //        (e.keyCode >= 35 && e.keyCode <= 40)) {
    //        // let it happen, don't do anything
    //        return;
    //    }
    //    // Ensure that it is a number and stop the keypress
    //    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
    //        e.preventDefault();
    //    }
    //});


    //$('#switch1').change(function () {
    //    $('#furthestPoint').fadeToggle();
    //});

    //$("#timepicker6").on("focus", function (e) {
    //    return $(this).timepicker("showWidget");
    //    document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = e.value;
    //});

    //$('#timepicker6').change(function (ev) {
    //    document.getElementById('ContentPlaceHolder1_hdnTimeValue').value = $('#timepicker6').val();
    //});
    ////$('#overlay').css('display', 'none');

    //$('.tab').click(function (event) {
    //    event.preventDefault();
    //    // Remove the 'active' class from the active tab.
    //    $('#tabs_container > .tabs > li.active')
    //        .removeClass('active');

    //    // Add the 'active' class to the clicked tab.
    //    $(this).parent().addClass('active');

    //    // Remove the 'tab_contents_active' class from the visible tab contents.
    //    $('#tabs_container > .tab_contents_container > div.tab_contents_active')
    //        .removeClass('tab_contents_active');

    //    // Add the 'tab_contents_active' class to the associated tab contents.
    //    $(this.rel).addClass('tab_contents_active');
    //    if (this.rel == "#tab_2_contents") {
    //        //this.rel = "#tab_1_contents";
    //        $("#tab_1_contents").addClass('tab_contents_active');
    //        $("#tab_2_contents").addClass('tab_contents_active');
    //        $("#tab_3_contents").removeClass('tab_contents_active');
    //    }
    //    if (this.rel == "#tab_3_contents") {
    //        $("#tab_1_contents").addClass('tab_contents_active');
    //        $("#tab_2_contents").removeClass('tab_contents_active');
    //        $("#tab_3_contents").addClass('tab_contents_active');

    //    }
    //    if (this.rel == "#tab_1_contents") {
    //        $("#tab_1_contents").addClass('tab_contents_active');
    //        $("#tab_2_contents").removeClass('tab_contents_active');
    //        $("#tab_3_contents").removeClass('tab_contents_active');
    //    }
    //});

});


function hideSearchBoxPickUp() {
    var container = $('#divSearchPickUp');
    $(document).mouseup(function (e) {
        if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.hide();
        }
    });

    $(document).on('keydown', '#PickupAddress', function (e) {
        //  alert('asad')
        var keyCode = e.keyCode || e.which;
        if (keyCode == 9) {
            e.preventDefault();
            container.hide();
            $('.datetimepicker').focus();
        }
    });
}

function hideSearchBoxDropOff() {
    var container = $('#divSearchDropOff');
    $(document).mouseup(function (e) {
        if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.hide();
        }
    });

    $(document).on('keydown', '#DropOffAddress', function (e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode == 9) {
            e.preventDefault();
            container.hide();
            $('.PassengerName').focus();
        }
    });
}

function setPickUpSearchBox() {
    var txtBoxHeight = $('#PickupAddress').height();
    $('#divSearchPickUp').css('top', txtBoxHeight + 12);
}

function setDropOffSearchBox() {
    var txtBoxHeight = $('#DropOffAddress').height();
    $('#divSearchDropOff').css('top', txtBoxHeight + 12);
}

function hideSearchResults() {
    $('#PickupAddress').focusout(function () {
        $('#divSearchPickUp').hide();
    });

    $('#DropOffAddress').focusout(function () {
        $('#divSearchDropOff').hide();
    });
}

var service;
var geolatitude;
var geolongitude;
var userLatLng;
var editBookacarInformation = '';
var editCheckRatesInformation = '';

function initializeMap(locationFound, geolatitude, geolongitude) {
    //  alert("pickUp Address");
    $("#PickupAddress").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: proxy + HostName + "/EliteService.asmx/LocationAutocomplete",
                type: "POST",
                data: "{text:'" + request.term + "', latitude: '" + geolatitude + "',longitude: '" + geolongitude + "'}",
                headers: {
                    'Content-Type': 'application/json; charset=utf-8',
                    'Authorization': 'Basic *********',
                    'X-Atlassian-Token': 'no-check',
                    'Access-Control-Allow-Origin': '*'
                },
                crossDomain: true,
                // contentType: "application/json; charset=utf-8",
                success: function (data) {
                    var string = '';
                    var myJsonString = JSON.parse(data.d);
                    var predictions = myJsonString.predictions;

                    $('#divSearchPickUp').html('');
                    var i = 0;
                    if (predictions != "") {
                        response($.map(predictions, function (item) {
                            setPickUpSearchBox();
                            $('#divSearchPickUp').css("display", "block");
                            $('#divSearchPickUp').show();
                            var puAddress = "'" + item.description.replace(/'/g, "") + "'";

                            var types = [];
                            types = "'" + item.types + "'";
                            var placeId = "'" + item.place_id + "'";
                            $('#divSearchPickUp').html($('#divSearchPickUp').html() + '<table class="col-md-12"><tr ><td class="col-md-11"><a  class="anchorPointer" onclick="fillupValuePUTextbox(' + puAddress + ', ' + types + ',' + placeId + ',' + geolatitude + ',' + geolongitude + ');"><b>' + item.description + '</b></a><hr /></td><td class="tdUnfavourite1" style="float:right;cursor:pointer"><input type="image" src="Images/star-unselected.png"  id="img' + i + '" alt="Submit" height="25px" onclick="return addFavourite(' + puAddress + ',this.id,' + placeId + ')"> </td></tr></table>');
                            i++;
                        }));
                        hideSearchBoxPickUp();
                    } else {
                        $('#divSearchPickUp').hide();
                    }
                },
                error: function (error) {
                    //bootbox.alert("<h4>" + error.responseText + "</h4>");
                    alert("error");
                    $('#dvLoading').hide();
                }
            });
        },
        select: function (event, ui) {
            $("#PickupAddress").val(ui.item.value);
        }
    });

    $("#DropOffAddress").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: proxy + HostName + "/EliteService.asmx/LocationAutocomplete",
                type: "POST",
                data: "{text:'" + request.term + "', latitude: '" + geolatitude + "',longitude: '" + geolongitude + "'}",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    var myJsonString = JSON.parse(data.d);
                    var predictions = myJsonString.predictions;
                    $('#divSearchDropOff').html('');

                    var i = 0;
                    if (predictions != "") {
                        response($.map(predictions, function (item) {
                            setPickUpSearchBox();
                            $('#divSearchDropOff').css("display", "block");
                            $('#divSearchDropOff').show();
                            var puAddress = "'" + item.description.replace(/'/g, "") + "'";

                            var types = [];
                            types = "'" + item.types + "'";
                            var placeId = "'" + item.place_id + "'";
                            $('#divSearchDropOff').html($('#divSearchDropOff').html() + '<table class="col-md-12"><tr ><td class="col-md-11"><a  class="anchorPointer"  onclick="fillupValueDOTextbox(' + puAddress + ', ' + types + ',' + placeId + ',' + geolatitude + ',' + geolongitude + ');"><b>' + item.description + '</b></a><hr /></td><td class="tdUnfavourite1"  style="float:right;cursor:pointer"><input type="image" src="Images/star-unselected.png" id="img1' + i + '" alt="" height="25px"  onclick="return addFavouriteDO(' + puAddress + ',this.id,' + placeId + ')"> </td></tr></table>');
                            i++;
                        }));
                        hideSearchBoxDropOff();
                    } else {
                        $('#divSearchDropOff').hide();
                    }
                },
                error: function (error) {
                    //bootbox.alert("<h4>" + error.responseText + "</h4>");
                    $('#dvLoading').hide();
                }
            });
        },
        select: function (event, ui) {
            $("#DropOffAddress").val(ui.item.value);
        }
    });

    var image;
    image = 'Images/pin_tracking_dot.png';
    mapOptions = {
        center: userLatLng,
        zoom: 14,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    map = new google.maps.Map(document.getElementById('gmap_canvas'), mapOptions);

    var marker = new google.maps.Marker({
        position: userLatLng,
        map: map,
        icon: image
    });

    if (editBookacarInformation != '') {
        EditBookaCarInformationFromInit(editBookacarInformation);
    }

    if (editCheckRatesInformation != '') {
        EditCheckRatesInformationFromInit(editCheckRatesInformation);
    }

}
function initialize1() {
    var options = {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
    };

    function setOptions(geoLoc) {
        geoLoc.enableHighAccuracy = true;
        geoLoc.timeout = 30;
        geoLoc.maximumAge = 0;
    }

    function doStuff(geoLoc) {
        if (geoLoc == "true") {
            userLatLng = new google.maps.LatLng(40.75000, -73.99000);
            geolatitude = 40.75000;
            geolongitude = -73.99000;
        } else {
            userLatLng = new google.maps.LatLng(geoLoc.coords.latitude, geoLoc.coords.longitude);
            geolatitude = geoLoc.coords.latitude;
            geolongitude = geoLoc.coords.longitude;
        }

        initializeMap(true, geolatitude, geolongitude);

    }

    function error(geoLoc) {
        doStuff("true");
    }

    navigator.geolocation.getCurrentPosition(doStuff, error, options);
    initializeMap(false, 40.75000, -73.99000);
    function callback(results, status) {
        if (status == google.maps.places.PlacesServiceStatus.OK) {
            for (var i = 0; i < results.length; i++) {
                var place = results[i];
            }
        }
    }

}

var imageId = "";

function addFavourite(address, imgId, placeId) {
    $('#dvLoading').show();
    var retVal;
    bootbox.prompt("Enter nick name?", function (result) {
        if (result === null) {
            $('#dvLoading').hide();
        } else {
            retVal = result;
            imageId = imgId;
            $.ajax(
                {
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: proxy + HostName + "/EliteService.asmx/SetFavouriteAddress",
                    data: "{addressFav: '" + address + "',nickName:'" + retVal + "',placeId:'" + placeId + "'}",
                    success: succeeded_previousFav,
                    error: failed_previousFav
                });
        }
    });
    $('#dvLoading').hide();
    return false;
}

function succeeded_previousFav(result) {
    var myJsonString = JSON.parse(result.d);
    if (myJsonString != null) {
        if (myJsonString.Code == '1') {
            document.getElementById(imageId).src = "Images/star-selected.png";
            imageId = "";
            getfavouriteAddress();
            bootbox.alert(myJsonString.Message);
            $('#dvLoading').hide();
        }
    }
}

function failed_previousFav() {

}

var imageId1 = "";

function addFavouriteDO(address, imgId, placeId) {
    $('#dvLoading').show();
    var retVal;
    bootbox.prompt("Enter nick name?", function (result) {
        if (result === null) {
            $('#dvLoading').hide();
        } else {
            retVal = result;
            imageId1 = imgId;
            $.ajax(
                {
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: proxy + HostName + "/EliteService.asmx/SetFavouriteAddress",
                    data: "{addressFav: '" + address + "',nickName:'" + retVal + "',placeId:'" + placeId + "'}",
                    success: succeeded_previousFavDo,
                    error: failed_previousFavDo
                });
        }
    });
    $('#dvLoading').hide();
    return false;
}

function succeeded_previousFavDo(result) {
    var myJsonString = JSON.parse(result.d);
    if (myJsonString != null) {
        if (myJsonString.Code == '1') {
            document.getElementById(imageId1).src = "Images/star-selected.png";
            imageId1 = "";
            getfavouriteAddress();
            bootbox.alert(myJsonString.Message);
            $('#dvLoading').hide();
        }
    }
}

function failed_previousFavDo() {

}

var placeIdForHourlyLocal = '';

function fillupValuePUTextbox(puAddress, types, placeId, latitude, longitude) {
    var PickUpAddress = puAddress;
    puAddress = puAddress.toLowerCase();
    if (puAddress != '') {
        $('.airportAreas').addClass('hidden');
        $('#divPUMap').removeClass('hidden');
        $('.btnClosePickUp').removeClass('hidden');
        var geocodermap = new google.maps.Geocoder();
        //console.log(latitue);
        //var paddress = address;
        geocodermap.geocode({ 'address': puAddress }, function (results, status) {
            //   debugger;
            // alert(results);
            if (status == google.maps.GeocoderStatus.OK) {
                var lat = results[0].geometry.location.lat();
                var lng = results[0].geometry.location.lng();
                ShowPickUpStreetView(lat, lng, puAddress);
            }
        });

        //if (puAddress.indexOf('3601 37th ave') >= 0 || puAddress.indexOf('36-01 37th ave') >= 0) {
        //    $('.airportAreas').addClass('hidden');
        //    $('.svbImage').removeClass('hidden');
        //    $('#divPUMap').addClass('hidden');
        //    $('.eliteImage').addClass('hidden'); 
        //    $('.btnClosePickUp').removeClass('hidden'); 

        //}
        //else if (puAddress.indexOf('3272 gale ave') >= 0 || puAddress.indexOf('32-72 gale ave') >= 0) {
        //    $('.airportAreas').addClass('hidden');
        //    $('.eliteImage').removeClass('hidden');
        //    $('.svbImage').addClass('hidden');
        //    $('#divPUMap').addClass('hidden');
        //    $('.btnClosePickUp').removeClass('hidden'); 
        //}
        //else {
        //    $('.airportAreas').addClass('hidden');
        //    $('#divPUMap').removeClass('hidden');
        //    $('.eliteImage').addClass('hidden');
        //    $('.svbImage').addClass('hidden');
        //    $('.btnClosePickUp').addClass('hidden'); 
        //    ShowPickupMap(puAddress);
        //}

    }
    else {
        $('.airportAreas').removeClass('hidden'); //doAreas
        $('#divPUMap').addClass('hidden');
        $('.btnClosePickUp').addClass('hidden');
    }
    // ShowPickupMap(puAddress);
    $('#divSearchPickUp').css("display", "none");
    //  puAddress = puAddress.substr(0, 32) + '...';
    $("#PickupAddress").val(PickUpAddress);
    chkAirportPu = false;
    placeIdForHourlyLocal = placeId;
    document.getElementById('ContentPlaceHolder1_hdnPuPlaceId').value = placeId;
    GetPostalWithAddress(placeId);
    $('#divSearchPickUp').hide();
    // $('#DropOffAddress').focus();
    //$(".datetimepicker").focus();
    return false;
}

var placeIdForHourlyLocalDo = '';

function fillupValueDOTextbox(doAddress, types, placeId, latitude, longitude) {

    var dropOffAddress = doAddress;
    doAddress = doAddress.toLowerCase();
    if (doAddress != '') {
        $('.doAreas').addClass('hidden');
        $('#divDOMap').removeClass('hidden');
        $('.btnCloseDO').removeClass('hidden');

        var geocodermap = new google.maps.Geocoder();
        //var paddress = address;
        geocodermap.geocode({ 'address': doAddress }, function (results, status) {
            //   debugger;
            // alert(results);
            if (status == google.maps.GeocoderStatus.OK) {
                var lat = results[0].geometry.location.lat();
                var lng = results[0].geometry.location.lng();
                ShowDOStreetView(lat, lng, doAddress);


            }
        });

        //if (doAddress.indexOf('3601 37th ave') >= 0 || doAddress.indexOf('36-01 37th ave') >= 0) {
        //    $('.doAreas').addClass('hidden'); 
        //    $('.svbImageDO').removeClass('hidden');
        //    $('#divDOMap').addClass('hidden');
        //    $('.eliteImageDO').addClass('hidden');
        //    $('.btnCloseDO').removeClass('hidden'); 
        //}
        //else if (doAddress.indexOf('3272 gale ave') >= 0 || doAddress.indexOf('32-72 gale ave') >= 0) {
        //    $('.doAreas').addClass('hidden'); 
        //    $('.eliteImageDO').removeClass('hidden');
        //    $('.svbImageDO').addClass('hidden');
        //    $('#divDOMap').addClass('hidden');
        //    $('.btnCloseDO').removeClass('hidden'); 
        //}
        //else {
        //    $('.doAreas').addClass('hidden'); 
        //    $('#divDOMap').removeClass('hidden');
        //    $('.eliteImageDO').addClass('hidden');
        //    $('.svbImageDO').addClass('hidden');
        //    $('.btnCloseDO').addClass('hidden'); 
        //    ShowDropOffMap(doAddress);
        //}

    }
    else {
        $('.doAreas').removeClass('hidden');
        $('#divDOMap').addClass('hidden');
        $('.eliteImageDO').addClass('hidden');
        $('.svbImageDO').addClass('hidden');
        $('.btnCloseDO').addClass('hidden');
    }

    // ShowDropOffMap(doAddress);
    $('#divSearchDropOff').css("display", "none");
    //  doAddress = doAddress.substr(0, 32) + '...';
    $("#DropOffAddress").val(dropOffAddress);
    chkAirportDo = false;
    placeIdForHourlyLocalDo = placeId;
    document.getElementById('ContentPlaceHolder1_hdnDoPlaceId').value = placeId;
    GetDOPostalWithAddress(placeId);
    $('#divSearchDropOff').hide();
    // $('#dp2').focus();
    // $(".PassengerName").focus();
    return false;
}

function calcRoute(txtid, latLong) {
    geocoder = new google.maps.Geocoder();
    var mapOptions = {
        zoom: 14,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    map = new google.maps.Map(document.getElementById('gmap_canvas'), mapOptions);
    var infowindow = new google.maps.InfoWindow();
    infowindow.close();
    var start = document.getElementById("PickupAddress").value;
    directionsService = new google.maps.DirectionsService();
    directionsDisplay = new google.maps.DirectionsRenderer();
    var end = document.getElementById("DropOffAddress").value;
    if (start != null && (end == null || end == '')) {
        infowindow.close();
        geocoder.geocode({ "address": start }, function (results, status) {
            var image;
            if (status == google.maps.GeocoderStatus.OK) {
                image = 'Images/pin_pickup_location.png';
                var mapOptions = {
                    zoom: 14,
                    center: latLong,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                map = new google.maps.Map(document.getElementById('gmap_canvas'), mapOptions);
                marker = new google.maps.Marker({
                    position: latLong,
                    map: map,
                    icon: image
                });
            }
        });
    }
    else if (end != null && (start == null || start == '')) {
        infowindow.close();
        geocoder.geocode({ "address": end }, function (results, status) {
            var image;
            if (status == google.maps.GeocoderStatus.OK) {
                image = 'Images/pin_drop_off_location.png';
                var mapOptions = {
                    zoom: 14,
                    center: latLong,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                map = new google.maps.Map(document.getElementById('gmap_canvas'), mapOptions);
                marker = new google.maps.Marker({
                    position: latLong,
                    map: map,
                    icon: image
                });
            }
        });
    }
    else {
        editDirection(latlongPu, latlongDo);
    }
}

var favLocation;

//get favourite location from page load
function GetFavouriteLocation(favLocatin) {
    favLocation = favLocatin;
}

var recentHistory;

function GetRecentHistory(results) {
    recentHistory = results;
}

function hidePUFavourite() {
    var container = $('#divPuFavourite');
    $(document).mouseup(function (e) {
        if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.hide();
            $('#divPuFavAdd').css("background-position", "0 3px");
        }
    });
}

function hideDOFavourite() {
    var container = $('#divDOFavourite');
    $(document).mouseup(function (e) {
        if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.hide();
            $('#divDoFavAdd').css("background-position", "0 3px");
        }
    });
}

function hidePuRecentTrip() {
    var container = $('#divPuRecentTrip');
    $(document).mouseup(function (e) {
        if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.hide();
            $('#divPuRecAdd').css("background-position", "0 0px");
        }
    });
}

function hideDORecentTrip() {
    var container = $('#divDORecentTrip');
    $(document).mouseup(function (e) {
        if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.hide();
            $('#divDoRecAdd').css("background-position", "0 0px");
        }
    });
}

function getfavouriteAddress() {
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: proxy + HostName + "/EliteService.asmx/GetFavouriteAddressBook",
            data: "{userId:'" + userIdGlobal + "'}",
            success: succeeded_previousFavAdd,
            error: failed_previousFavAdd
        });
}

function succeeded_previousFavAdd(result) {
    favLocation = result.d;
}

function failed_previousFavAdd() {

}

var isFavouriteAddShow = false;

function getFavouriteLocationOnDiv() {
    $('#dvLoading').show();

    getfavouriteAddress();
    setTimeout(function () {
        $("#divDOFavourite").hide();
        $('#divSearchDropOff').css("display", "none");
        isFavouriteAddShow = true;
        $('#dvLoading').show();
        //$("#divPuFavourite").css("overflow-y", "scroll");
        var string = '';
        if (favLocation == undefined || favLocation == "null" || favLocation == "") {
            bootbox.alert("<h4>No favourite location available</h4>");
            $('#divPuFavourite').css("display", "none");
            $('#dvLoading').hide();
            return false;
        }
        $('#divPuFavAdd').css("background-position", "0 -30px");
        var myJsonString = JSON.parse(favLocation);
        if (myJsonString != null) {
            string = '<div style="display: block; overflow-y: scroll; max-height: 315px;"><table class="col-md-12" style="background-color:white;text-transform:none">';
            for (var i = 0; i < myJsonString.length; i++) {
                var address = myJsonString[i].Address;
                var fullAddress = "'" + address.FullAddress + "'";
                var placeId = "'" + address.ReferenceNum + "'";
                if (myJsonString[i].NickName == "null" || myJsonString[i].NickName == "Nick Name" || myJsonString[i].NickName == "" || myJsonString[i].NickName == null) {
                    myJsonString[i].NickName = "";
                    string = string + '<tr><td class="col-md-11"> <a class="anchorClass" onclick="getAddressValue(' + fullAddress + ',' + placeId + ');"><b>' + myJsonString[i].NickName + '</b><br />';
                } else {
                    string = string + '<tr><td> <a  class="anchorClass" onclick="getAddressValue(' + fullAddress + ',' + placeId + ');"><b>' + myJsonString[i].NickName + '</b><br/>';
                }
                string = string + '' + address.FullAddress + "," + address.PostalCode + '</a></td>';
                string = string + '<td class="tdUnfavourite1"><span class="glyphicon glyphicon-star anchorFont" ></span></td>';
                string = string + '<td class="tdUnfavourite" style="display:none;"><span class="glyphicon glyphicon-star anchorFont" onclick="return UnfavouriteLocation(' + myJsonString[i].AddressID + ')"></span></td></tr>';
            }
            string = string + '</table></div > ';
            $('#divPuFavourite').html(string);
            $("#divPuFavourite").css("display", "block");
            $('#dvLoading').hide();
        }
    }, 2000);
    hidePUFavourite();
}

function getRecentLocationOnDiv() {
    $('#dvLoading').show();
    $("#divDOFavourite").hide();
    $('#divSearchDropOff').css("display", "none");
    $("#divDORecentTrip").hide();
    $('#divSearchDropOff').css("display", "none");
    //$("#divPuRecentTrip").css("overflow-y", "scroll");
    var string = '';
    if (recentHistory == undefined || recentHistory == "null" || recentHistory == "") {
        bootbox.alert("<h4>No Recent Trip available</h4>");
        $('#divPuRecentTrip').css("display", "none");
        $('#dvLoading').hide();
        return false;
    }
    $('#divPuRecAdd').css("background-position", "0 -30px");
    var myJsonString = JSON.parse(recentHistory);
    if (myJsonString != null) {
        string = '<div style="display: block; overflow-y: scroll; max-height: 315px;"><table class="col-md-12" style="background-color:white;text-transform:none">';
        for (var i = 0; i < myJsonString.length; i++) {
            var address = myJsonString[i].Address;
            var fullAddress = "'" + address.FullAddress + "'";
            var placeId = "'" + address.ReferenceNum + "'";
            if (myJsonString[i].NickName == "null" || myJsonString[i].NickName == "Nick Name" || myJsonString[i].NickName == "" || myJsonString[i].NickName == null) {
                myJsonString[i].NickName = "";
                string = string + '<tr><td class="col-md-11"> <a  class="anchorClass" onclick="getAddressValue(' + fullAddress + ',' + placeId + ');"><b>' + myJsonString[i].NickName + '</b><br/>';
            } else {
                string = string + '<tr><td> <a  class="anchorClass" onclick="getAddressValue(' + fullAddress + ',' + placeId + ');"><b>' + myJsonString[i].NickName + '</b><br/>';
            }
            string = string + '' + address.FullAddress + "," + address.PostalCode + '</a></td><td class="tdUnfavourite1" style="cursor:pointer"><input type="image" src="Images/star-unselected.png"  id="img' + i + '" alt="Submit" height="25px" onclick="return addFavourite(' + fullAddress + ',this.id,' + placeId + ')"> </td></tr>';
        }
        string = string + '</table></div>';
        $('#divPuRecentTrip').html(string);
        $("#divPuRecentTrip").css("display", "block");
        $('#dvLoading').hide();
    }
    $('#dvLoading').hide();
    hidePuRecentTrip();
}

function getRecentLocationOnDODiv() {
    $('#dvLoading').show();
    $("#divDOFavourite").hide();
    $('#divSearchDropOff').css("display", "none");
    $("#divPuRecentTrip").hide();
    $('#divSearchDropOff').css("display", "none");
    //$("#divDORecentTrip").css("overflow-y", "scroll");
    var string = '';
    if (recentHistory == undefined || recentHistory == "null" || recentHistory == "") {
        bootbox.alert("<h4>No Recent Trip available</h4>");
        $('#divDORecentTrip').css("display", "none");
        $('#dvLoading').hide();
        return false;
    }
    $('#divDoRecAdd').css("background-position", "0 -30px");
    var myJsonString = JSON.parse(recentHistory);
    if (myJsonString != null) {
        string = '<div style="display: block; overflow-y: scroll; max-height: 315px;"><table class="col-md-12" style="background-color:white;text-transform:none">';
        for (var i = 0; i < myJsonString.length; i++) {
            var address = myJsonString[i].Address;

            var fullAddress = "'" + address.FullAddress + "'";
            var placeId = "'" + address.ReferenceNum + "'";
            if (myJsonString[i].NickName == "null" || myJsonString[i].NickName == "Nick Name" || myJsonString[i].NickName == "" || myJsonString[i].NickName == null) {
                myJsonString[i].NickName = "";
                string = string + '<tr><td class="col-md-11"> <a  class="anchorClass" onclick="getDOAddressValue(' + fullAddress + ',' + placeId + ');"><b>' + myJsonString[i].NickName + '</b><br/>';
            } else {
                string = string + '<tr><td> <a  class="anchorClass" onclick="getDOAddressValue(' + fullAddress + ',' + placeId + ');"><b>' + myJsonString[i].NickName + '</b><br/>';
            }
            string = string + '' + address.FullAddress + "," + address.PostalCode + '</a></td><td class="tdUnfavourite1"  style="cursor:pointer"><input type="image" src="Images/star-unselected.png" id="img1' + i + '" alt="" height="25px"  onclick="return addFavouriteDO(' + fullAddress + ',this.id,' + placeId + ')"> </td></tr>';
        }
        string = string + '</table></div>';
        $('#divDORecentTrip').html(string);
        $("#divDORecentTrip").css("display", "block");
        $('#dvLoading').hide();
    }
    $('#dvLoading').hide();
    hideDORecentTrip();
}

function getAddressValue(address, placeId) {
    address = address.substr(0, 32) + '...';
    $("#PickupAddress").val(address);
    $('#divPuFavourite').css("display", "none");
    $('#divPuRecentTrip').css("display", "none");
    $('#DropOffAddress').focus();
    document.getElementById('ContentPlaceHolder1_hdnPuPlaceId').value = placeId;
    GetPostalWithAddress(placeId);
}

var isFavouriteAddShowDO = false;

function getFavouriteLocationOnDODiv() {
    $('#dvLoading').show();
    getfavouriteAddress();
    setTimeout(function () {
        $("#divPuFavourite").hide();
        $('#divSearchDropOff').css("display", "none");
        isFavouriteAddShowDO = true;
        //$("#divDOFavourite").css("overflow-y", "scroll");
        $('#dvLoading').show();
        var string = '';
        if (favLocation == undefined || favLocation == "null" || favLocation == "") {
            bootbox.alert("<h4>No favourite location available</h4>");
            $('#divPuFavourite').css("display", "none");
            $('#dvLoading').hide();
            return false;
        }
        $('#divDoFavAdd').css("background-position", "0 -30px");
        var myJsonString = JSON.parse(favLocation);
        if (myJsonString != null) {
            string = string + '<div style="display: block; overflow-y: scroll; max-height: 315px;"><table class="tableFavLoc">';
            for (var i = 0; i < myJsonString.length; i++) {
                var address = myJsonString[i].Address;
                var fullAddress = "'" + address.FullAddress + "'";
                var placeId = "'" + address.ReferenceNum + "'";
                if (myJsonString[i].NickName == "null" || myJsonString[i].NickName == "Nick Name" || myJsonString[i].NickName == "" || myJsonString[i].NickName == null) {
                    myJsonString[i].NickName = "";
                    string = string + '<tr><td> <a  class="anchorClass"  onclick="getDOAddressValue(' + fullAddress + ',' + placeId + ');"><b>' + myJsonString[i].NickName + '</b><br/>';
                } else {
                    string = string + '<tr><td> <a  class="anchorClass"   onclick="getDOAddressValue(' + fullAddress + ',' + placeId + ');"><b>' + myJsonString[i].NickName + '</b><br/>';
                }
                string = string + '' + address.FullAddress + "," + address.PostalCode + '</a></td>';
                string = string + '<td class="tdUnfavourite1"><span class="glyphicon glyphicon-star anchorFont" ></span></td>';
                string = string + '<td class="tdUnfavourite" style="display:none;"><span class="glyphicon glyphicon-star anchorFont" onclick="return UnfavouriteLocation(' + myJsonString[i].AddressID + ')"></span></td></tr>';
            }
            string = string + '</table></div>';
            $('#divDOFavourite').html(string);
            $("#divDOFavourite").css("display", "block");
            $('#dvLoading').hide();
        }
    }, 2000);
    hideDOFavourite();
}

function getDOAddressValue(address, placeId) {
    address = address.substr(0, 32) + '...';
    $("#DropOffAddress").val(address);
    $('#dp2').focus();
    $('#divDOFavourite').css("display", "none");
    $("#divDORecentTrip").css("display", "none");
    document.getElementById('ContentPlaceHolder1_hdnDoPlaceId').value = placeId;
    GetDOPostalWithAddress(placeId);
}




$(document).ready(function () {
    $('.zoom').zoom();
    $('#tripType').removeClass('hidden');
});


$("#dropOffNext").on("click", function () {
    $('#tripType').addClass('hidden');
});



$(window).on("load", function () {
    $('#tripType').removeClass('hidden');
    /* === JFK Terminal === */
    $("." + MyclassName + " area").on("click", function () {
        if (!$("#AirportForm").hasClass("hidden")) {
            $("#AirportForm").addClass('hidden');
        }

        //start 23-11-2018
        var className = this.className;
        if (className == 't3') {

            $(this).parent().siblings('.terminal4-pickup-points').addClass('active');
            $('.super').removeClass('disabled');
            $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
            $(this).parents('.limonet-area').removeClass("disabled");
            // $(".address-field.pickup-add").val('JFK').trigger('keyup');
            $(".address-field.pickup-add").val('JFK Airport, New York, USA');

        }// End and then remove else {}
        else {
            $(this).parent().siblings('.pickup-points').addClass('active');
            $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
            $(this).parents('.limonet-area').removeClass("disabled");
            // $(".address-field.pickup-add").val('JFK').trigger('keyup');
            $(".address-field.pickup-add").val('JFK Airport, New York, USA');
        }

        return false;
    });
    $(".terminal4-pickup-points .goback").on("click", function () {
        $(this).siblings(".pickup-point").removeClass("selected disabled");
        $(this).parents('.terminal4-pickup-points').removeClass("active");
        $('.super').removeClass('disabled');
        $(".limonet-area").removeClass("disabled");
        $(".address-field.pickup-add").val('').trigger('keyup');

        $('.pickup-point1').removeClass("selected disabled");
        $('.pickup-point2').removeClass("selected disabled");
        $('.pickup-point3').removeClass("selected disabled");//
        $('.pickup-point4b').removeClass("disabled");//
        $('.point4btextOthers').removeClass("selected disabled");


        //  $('.point4b').removeClass('selected').addClass("disabled");
        $('.point4bimgOthers').removeClass('hidden');
        $('.point4btextOthers').addClass('hidden');
        $('.point4btextOthers').val('');
        return false;
    });

    /* === Pickup Points === */
    $(".pickup-point").on("click", function () {
        $(".pickup-btns").addClass('active');
        $(this).removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");
        var name = this.className;
        //$('.point4b').removeClass('selected').addClass("disabled");
        //$('.point4bimgOthers').removeClass('hidden');
        //$('.point4btextOthers').addClass('hidden');
        if (name != 'pickup-point pickup-point6a' || name != 'pickup-point point4b') {
            $('.imgOthers').removeClass('hidden');
            $('.textOthers').addClass('hidden');
            $('.textOthers').val('');
            $('.point4btextOthers').val('');
            $('.point4bimgOthers').removeClass('hidden');
            $('.point4btextOthers').addClass('hidden');
        }
        else {
            $('.point4btextOthers').val('');
            $('.textOthers').val('');
            $('.imgOthers').addClass('hidden');
            $('.textOthers').removeClass('hidden');
            $('.point4bimgOthers').addClass('hidden');
            $('.point4btextOthers').removeClass('hidden');
        }

        if (name == 'pickup-point super selected') {

            $(this).removeClass("disabled").addClass("selected");
            $('.pickup-point1a').removeClass('selected').addClass("disabled");
            $('.pickup-point2a').removeClass('selected').addClass("disabled");
            $('.pickup-point3a').removeClass('selected').addClass("disabled");
            $('.pickup-point4a').removeClass('selected').addClass("disabled");
            $('.pickup-point6a').removeClass('selected').addClass("disabled");

            $('.imgOthers').removeClass('hidden');
            $('.textOthers').addClass('hidden');
            $('.textOthers').val('');
            $('.point4btextOthers').val('');
            $('.point4bimgOthers').removeClass('hidden');
            $('.point4btextOthers').addClass('hidden');

        }
        else {
            $('.super').removeClass('selected').addClass("disabled");

        }
    });
    $(".pickup-point6a").on("click", function () {
        $('.pickup-point6a').removeClass('selected');
        $('.imgOthers').addClass('hidden');
        $('.textOthers').removeClass('hidden');
        $('.textOthers').val('');

        $('.point4bimgOthers').addClass('hidden');
        $('.point4btextOthers').removeClass('hidden');
        $('.point4btextOthers').val('');
        // addPickUpLocation("", "", 5);
    });
    $(".point4b").on("click", function () {
        // addPickUpLocation("", "", 5);
        $('.point4b').removeClass('selected');
        $('.point4bimgOthers').addClass('hidden');
        $('.point4btextOthers').removeClass('hidden');
        $('.point4btextOthers').val('');
        $('.pickup-point1').removeClass('selected').addClass("disabled");
        $('.pickup-point2').removeClass('selected').addClass("disabled");
        $('.pickup-point3b').removeClass('selected').addClass("disabled");

    });

    function addPickUpLocation(address, imgId, placeId) {
        $('#dvLoading').show();
        var retVal;
        bootbox.prompt("Please mention pickup area:", function (result) {
            if (result === null) {
                $('#dvLoading').hide();
            } else {
                retVal = result;
                imageId = imgId;
                $.ajax(
                    {
                        type: "POST",
                        contentType: "application/json; charset=utf-8",
                        url: proxy + HostName + "/EliteService.asmx/SetFavouriteAddress",
                        data: "{addressFav: '" + address + "',nickName:'" + retVal + "',placeId:'" + placeId + "'}",
                        success: succeeded_previousFav,
                        error: failed_previousFav
                    });
            }
        });
        $('#dvLoading').hide();
        return false;
    }
    //New-pickup-point

    /* === Pickup Points Go Back === */
    $(".pickup-points .goback").on("click", function () {
        $(this).siblings(".pickup-point").removeClass("selected disabled");
        $(this).parents('.pickup-points').removeClass("active");
        $(".limonet-area").removeClass("disabled");
        $(".address-field.pickup-add").val('').trigger('keyup');

        $('.pickup-point1a').removeClass("selected disabled");
        $('.pickup-point2a').removeClass("selected disabled");
        $('.pickup-point3a').removeClass("selected disabled");
        $('.pickup-point4a').removeClass("selected disabled");
        $('.pickup-point6a').removeClass("selected disabled");
        $('.super').removeClass("selected disabled");

        $('.pickup-point1').removeClass("selected disabled");
        $('.pickup-point2').removeClass("selected disabled");
        $('.pickup-point3').removeClass("selected disabled");//
        $('.pickup-point4b').removeClass("disabled");//
        $('.point4btextOthers').removeClass("selected disabled");

        $('.imgOthers').removeClass('hidden');
        //$('.textOthers').value('');
        $('.textOthers').addClass('hidden');
        $('.textOthers').val('');

        $('.point4bimgOthers').removeClass('hidden');
        $('.point4btextOthers').addClass('hidden');
        $('.point4btextOthers').val('');

        return false;
    });

    //New-pickup-point



    /* === LGA Terminal === */
    $(".lga-airline area").on("click", function () {
        if (!$("#AirportForm").hasClass("hidden")) {
            $("#AirportForm").addClass('hidden');
        }
        $(".pickup-btns").addClass('active');
        $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
        $(this).parents('.limonet-area').removeClass("disabled").addClass('stop');
        $(this).parents(".limonet-area").find(".airlines").addClass('active');
        // $(".address-field.pickup-add").val('LGA').trigger('keyup');
        $(".address-field.pickup-add").val('LGA Airport, New York, USA');
        return false;
    });
    $(".Newark-airline area").on("click", function () {
        debugger;
        if (!$("#AirportForm").hasClass("hidden")) {
            $("#AirportForm").addClass('hidden');
        }
        $(".pickup-btns").addClass('active');
        // $(".address-field.pickup-add").val('LGA').trigger('keyup');
        $(".address-field.pickup-add").val('Newark Liberty International Airport, Newark, NJ, USA');
        return false;
    });


    /* === Airlines Go Back === */
    $(".airlines .goback").on("click", function () {
        $(".limonet-area").removeClass("disabled");
        $(".limonet-area").find(".airlines").removeClass('active');
        $(".address-field.pickup-add").val('').trigger('keyup');
        return false;
    });

    /* === Date Picker Initialize == */
    jQuery('.datetimepicker').datetimepicker({
        validateOnBlur: false,
        format: 'm-d-Y h:i A',
        step: 15,
        value: new Date()
    });

    /* === Address Field == */
    $("body").on("keyup", ".address-field.pickup-add", function () {
        let val = $(this).val();
        if (val == 'jfk' || val == 'lga' || val == 'ewr' || val == 'JFK' || val == 'LGA' || val == 'EWR') {
            $(".more-fields").removeClass('hidden');
        }
        else {
            $(".more-fields").addClass('hidden');
        }

        if (val.length > 0) {
            $(".pickup-btns").addClass('active');
        }
        else {
            $(".pickup-btns").removeClass('active');
        }
        if (val == '') {

            $('.airportAreas').removeClass('hidden');
            $('#divPUMap').addClass('hidden');
            $('.eliteImage').addClass('hidden');
            $('.svbImage').addClass('hidden');
            $('.btnClosePickUp').addClass('hidden');

            $(".pickup-btns").removeClass('active');
            // $("html, body").animate({scrollTop: $('#PickupAddress').offset().top }, 1000);
        }
    });
    $("#PickupAddress").focusout(function (e) {
        let val = $(this).val().toLowerCase();
        if (val != '') {


            $('.airportAreas').addClass('hidden');
            $('#divPUMap').removeClass('hidden');
            $('.btnClosePickUp').removeClass('hidden');
            var geocodermap = new google.maps.Geocoder();
            //console.log(latitue);
            //var paddress = address;
            geocodermap.geocode({ 'address': val }, function (results, status) {
                //   debugger;
                // alert(results);
                if (status == google.maps.GeocoderStatus.OK) {
                    var lat = results[0].geometry.location.lat();
                    var lng = results[0].geometry.location.lng();
                    ShowPickUpStreetView(lat, lng, val);
                }
            });
            if (e.keyCode == 9) {

                $(".datetimepicker").focus();
                e.preventDefault()
            }

        }
        else {
            $('.airportAreas').removeClass('hidden');
            $('#divPUMap').addClass('hidden');
            $('.btnClosePickUp').addClass('hidden');
            $(".pickup-btns").removeClass('active');
        }
    });

    $(".btnClosePickUp").on("click", function () {
        $('.airportAreas').removeClass('hidden');
        $('#divPUMap').addClass('hidden');
        $('.eliteImage').addClass('hidden');
        $('.svbImage').addClass('hidden');
        $('.btnClosePickUp').addClass('hidden');
        $('#PickupAddress').val('');
        $('.pickup-btns').removeClass('active');
    });
    $(".btnCloseDO").on("click", function () {
        $('.doAreas').removeClass('hidden');
        $('#divDOMap').addClass('hidden');
        $('.eliteImageDO').addClass('hidden');
        $('.svbImageDO').addClass('hidden');
        $('.btnCloseDO').addClass('hidden');
        // $('.pickup-btns').removeClass('active');
        $('#DropOffAddress').val('');
    });
    $('#PickupAddress').keypress(function (event) {
        let val = $(this).val().toLowerCase();
        if (event.keyCode == 13) {
            if (val != '') {

                $('.airportAreas').addClass('hidden');
                $('#divPUMap').removeClass('hidden');
                $('.btnClosePickUp').removeClass('hidden');
                var geocodermap = new google.maps.Geocoder();
                //console.log(latitue);
                //var paddress = address;
                geocodermap.geocode({ 'address': val }, function (results, status) {
                    //   debugger;
                    // alert(results);
                    if (status == google.maps.GeocoderStatus.OK) {
                        var lat = results[0].geometry.location.lat();
                        var lng = results[0].geometry.location.lng();
                        ShowPickUpStreetView(lat, lng, val);
                    }
                });
                if (e.keyCode == 9) {

                    $(".datetimepicker").focus();
                    e.preventDefault()
                }

            }
            else {
                $('.airportAreas').removeClass('hidden');
                $('#divPUMap').addClass('hidden');
                $('.btnClosePickUp').addClass('hidden');
                $(".pickup-btns").removeClass('active');
            }
        }
        else if (event.keyCode == 9 && !event.shiftKey == 9) {

            $(".datetimepicker").focus();
            event.preventDefault();
        }

    });

    $("#DropOffAddress").focusout(function () {
        let val = $(this).val().toLowerCase();
        if (val != '') {

            $('.doAreas').addClass('hidden');
            $('#divDOMap').removeClass('hidden');
            $('.btnCloseDO').removeClass('hidden');

            var geocodermap = new google.maps.Geocoder();
            //var paddress = address;
            geocodermap.geocode({ 'address': val }, function (results, status) {
                //   debugger;
                // alert(results);
                if (status == google.maps.GeocoderStatus.OK) {
                    var lat = results[0].geometry.location.lat();
                    var lng = results[0].geometry.location.lng();
                    ShowDOStreetView(lat, lng, val);


                }
            });
        }
        else {
            $('.doAreas').removeClass('hidden');
            $('#divDOMap').addClass('hidden');
            $('.btnCloseDO').addClass('hidden');
        }
    });

    $('#DropOffAddress').keypress(function (event) {
        let val = $(this).val().toLowerCase();
        // alert(event.keyCode);
        if (event.keyCode == 13) {
            if (val != '') {

                $('.doAreas').addClass('hidden');
                $('#divDOMap').removeClass('hidden');
                $('.btnCloseDO').removeClass('hidden');

                var geocodermap = new google.maps.Geocoder();
                //var paddress = address;
                geocodermap.geocode({ 'address': val }, function (results, status) {
                    //   debugger;
                    // alert(results);
                    if (status == google.maps.GeocoderStatus.OK) {
                        var lat = results[0].geometry.location.lat();
                        var lng = results[0].geometry.location.lng();
                        ShowDOStreetView(lat, lng, val);


                    }
                });
            }
            else {
                $('.doAreas').removeClass('hidden');
                $('#divDOMap').addClass('hidden');
                $('.btnCloseDO').addClass('hidden');
            }
            e.preventDefault();
        }
        else if (event.keyCode == 9) {
            $(".PassengerName").focus();
            e.preventDefault();
        }
    });
    $("body").on("keyup", "#DropOffAddress", function () {
        let val = $(this).val();

        if (val != '') {
            //$('#divDOMap').removeClass('hidden');
            //ShowDropOffMap(val);
        }
        else {
            $('.doAreas').removeClass('hidden');
            $('#divDOMap').addClass('hidden');
            $('.eliteImageDO').addClass('hidden');
            $('.svbImageDO').addClass('hidden');
            $('.btnCloseDO').addClass('hidden');
            // $("html, body").animate({scrollTop: $('#DropOffAddress').offset().top }, 1000);
        }


    });
    /* === Special Request Radios == */
    $("#roundtrip").on("change", function () {
        if ($(this).prop("checked") == true) {
            $(".roundtrip").removeClass("hidden");
            $(".hourly").addClass("hidden");
        }
    });
    $("#hourly").on("change", function () {
        if ($(this).prop("checked") == true) {
            $(".hourly").removeClass("hidden");
            $(".roundtrip").addClass("hidden");
        }
    });
    $("#oneway").on("change", function () {
        if ($(this).prop("checked") == true) {
            $(".hourly").addClass("hidden");
            $(".roundtrip").addClass("hidden");
        }
    });

    /* === More Options == */
    $(".more > a").on("click", function () {
        $(this).toggleClass('active');
        $(".special-box").slideToggle();
        var topMargin = $(this).offset().top - $(".limonet-ride").offset().top;
        $(".special-box").css({ "top": topMargin });
        $("html,body").animate({
            "scrollTop": 500
        }, 1000);
        return false;
    });


    $("a.close-this").on("click", function () {
        $(".special-box").slideUp();
        $(".more > a").removeClass('active');
        return false;
    });


    /* === Pickup Next == */
    $(".pickup-btns .next").on("click", function () {
        $(".limonet-panel.dropoff").removeClass('hidden');
        $(this).parents('.limonet-panel-body').slideUp();
        $(this).parents('.limonet-panel').addClass('collapsed');
        return false;
    });

    /* === Pickup Next == */
    $(".open-body").on("click", function () {
        $(".limonet-panel.dropoff").addClass('hidden');
        $('#tripType').removeClass('hidden');
        $(this).parents('.limonet-panel').find('.limonet-panel-body').slideDown();
        $(this).parents('.limonet-panel').removeClass('collapsed');
        return false;
    });


    $(".limonet-area area").on("mouseenter", function () {
        var thisarea = $(this).attr('class');
        console.log(thisarea);
        $(this).parents('.limonet-area').find('.area-hovers img').hide();
        $(this).parents('.limonet-area').find(".area-hovers #" + thisarea).show();
    });

    $(".limonet-area").on("mouseout", function () {
        $(this).find('.area-hovers img').hide();
        $(this).find('.area-hovers img:last-child').show();
    });

});

var t = initialize1();