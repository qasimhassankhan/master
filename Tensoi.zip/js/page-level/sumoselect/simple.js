$(window).on("load",function(){
      $('.console_sumoselect').SumoSelect({
            search: true,
            searchText: 'Search here.'
      });
});
