$(window).on("load",function(){
      $(".range").ionRangeSlider();

});
