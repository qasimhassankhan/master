$(window).on("load",function(){

      $('.dropdown-sin-1').dropdown({
        readOnly: true,
        input: '<input type="text" maxLength="20" placeholder="Search">'
      });

})
