$(window).on("load",function(){
      $('.email').tagEditor({
            delimiter: ', ', /* space and comma */
            placeholder: 'Enter email'
      });
});
