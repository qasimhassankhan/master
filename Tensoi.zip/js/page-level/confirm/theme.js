$('.example-the-1').on('click', function(){
   $.confirm({
        icon: 'fa fa-smile-o',
        theme: 'modern',
        closeIcon: true,
        animation: 'scale',
        type: 'blue',
   });
});
$('.example-the-2').on('click', function(){
   $.confirm({
        icon: 'fa fa-question-circle-o',
        theme: 'supervan',
        closeIcon: true,
        animation: 'scale',
        type: 'orange',
   });
});
$('.example-the-3').on('click', function(){
   $.confirm({
        icon: 'fa fa-question',
        theme: 'material',
        closeIcon: true,
        animation: 'scale',
        type: 'orange',
   });
});
$('.example-the-4').on('click', function(){
   $.confirm({
        icon: 'fa fa-question',
        theme: 'bootstrap',
        closeIcon: true,
        animation: 'scale',
        type: 'orange',
   });
});
