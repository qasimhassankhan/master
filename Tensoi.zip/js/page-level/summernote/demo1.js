$(window).on("load", function(){

      $('.summernote').summernote({
        placeholder: 'Hello stand alone ui',
        tabsize: 2,
        height: 170
      });


})
