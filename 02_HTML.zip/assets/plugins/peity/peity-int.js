$(document).ready(function(){
	'use strict';

	$('.student-stat').peity('bar', {
	  fill: ['#b3cfb8'],
	  width: '70',
	  height: '35'
	});

	$('.course-stat').peity('bar', {
	  fill: ['#49666d'],
	  width: '70',
	  height: '35'
	});

});