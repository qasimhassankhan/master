VELLUM — Interior & Architecture HTML Template
================================================

A multi-variant HTML template for interior design and architecture studios.
Built with clean, hand-written HTML, CSS, and vanilla JavaScript — no build
step, no framework, no dependencies (except Google Fonts).

-------------------------------------------------------------------
WORK IN PROGRESS — this package is being built out page by page.
Full documentation, landing page, and preview assets will be added
once all pages are complete.
-------------------------------------------------------------------

FOLDER STRUCTURE
----------------
vellum/
├── index.html            01 — Interior Design Studio (home variant)
├── architecture.html     02 — Architecture Firm (home variant)
├── assets/
│   ├── css/
│   │   ├── root.css         Design tokens — colors, type, spacing.
│   │   │                     Change a value here, it updates everywhere.
│   │   │                     Per-variant themes live here (body classes).
│   │   ├── base.css         Reset, typography, layout helpers, reveal anims.
│   │   ├── components.css   Nav, footer, buttons, cards, forms, modals,
│   │   │                     lightbox, estimator wizard.
│   │   ├── pages.css        Section-specific styles for each page.
│   │   └── fx.css           Ambient background effects (aurora, orbs,
│   │                         particles, grain, cursor glow). Optional —
│   │                         add class="no-fx" to <body> to disable.
│   ├── js/
│   │   └── main.js          All interactivity (vanilla JS, no libraries).
│   └── images/              SVG illustrations + scenes.

THEMING
-------
Each home variant sets a body class (e.g. <body class="v-interior">,
<body class="v-architecture">) which shifts the color palette via CSS
variables defined in root.css. To recolor a whole variant, edit only
that variant's block in root.css.

REPLACING ILLUSTRATIONS WITH PHOTOS
-----------------------------------
The template ships with custom SVG illustrations. To use real photography,
replace the relevant <img src="assets/images/..."> paths with your own
images. Showcase sections include a comment marking where to swap in a
full-width photo (recommended 1600px wide).

FONTS
-----
Fraunces, Cormorant Garamond, Jost, JetBrains Mono — loaded via Google
Fonts CDN in each page's <head>. Can be self-hosted if preferred.

— stillidea
