/* ============================================================
   VELLUM — Main JS (main.js)
   Shared behaviour for all pages. Pure vanilla, no deps.
   ============================================================ */
(function () {
  'use strict';

  /* ---------------------------------------------------------
     1. MOBILE NAV DRAWER
     --------------------------------------------------------- */
  function initNav() {
    var toggle = document.querySelector('[data-nav-toggle]');
    var drawer = document.querySelector('[data-nav-drawer]');
    if (!toggle || !drawer) return;
    var closeBtn = drawer.querySelector('[data-nav-close]');

    function open() {
      drawer.classList.add('is-open');
      document.body.style.overflow = 'hidden';
      toggle.setAttribute('aria-expanded', 'true');
    }
    function close() {
      drawer.classList.remove('is-open');
      document.body.style.overflow = '';
      toggle.setAttribute('aria-expanded', 'false');
    }
    toggle.addEventListener('click', open);
    if (closeBtn) closeBtn.addEventListener('click', close);
    drawer.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', close); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  }

  /* ---------------------------------------------------------
     2. SCROLL REVEAL
     --------------------------------------------------------- */
  function initReveal() {
    var els = document.querySelectorAll('.reveal');
    if (!els.length) return;
    if (!('IntersectionObserver' in window)) {
      els.forEach(function (el) { el.classList.add('is-visible'); });
      return;
    }
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    els.forEach(function (el) { obs.observe(el); });
  }

  /* ---------------------------------------------------------
     3. GENERIC MODAL SYSTEM
     [data-open-modal="id"] opens .modal#id; [data-modal-close] closes
     --------------------------------------------------------- */
  function initModals() {
    var lastFocus = null;
    function open(id) {
      var modal = document.getElementById(id);
      if (!modal) return;
      lastFocus = document.activeElement;
      modal.classList.add('is-open');
      document.body.style.overflow = 'hidden';
      var focusable = modal.querySelector('input, button, [tabindex]');
      if (focusable) setTimeout(function () { focusable.focus(); }, 50);
      document.dispatchEvent(new CustomEvent('modal:open', { detail: { id: id } }));
    }
    function close(modal) {
      modal.classList.remove('is-open');
      document.body.style.overflow = '';
      if (lastFocus) lastFocus.focus();
    }
    document.querySelectorAll('[data-open-modal]').forEach(function (btn) {
      btn.addEventListener('click', function () { open(btn.getAttribute('data-open-modal')); });
    });
    document.querySelectorAll('.modal').forEach(function (modal) {
      modal.querySelectorAll('[data-modal-close], .modal__overlay').forEach(function (el) {
        el.addEventListener('click', function () { close(modal); });
      });
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        var openModal = document.querySelector('.modal.is-open');
        if (openModal) close(openModal);
      }
    });
    // expose for programmatic use
    window.VellumModal = { open: open };
  }

  /* ---------------------------------------------------------
     4. LIGHTBOX (galleries)
     Any [data-lightbox] image joins a gallery by [data-lightbox-group]
     --------------------------------------------------------- */
  function initLightbox() {
    var triggers = Array.prototype.slice.call(document.querySelectorAll('[data-lightbox]'));
    if (!triggers.length) return;

    var box = document.createElement('div');
    box.className = 'lightbox';
    box.innerHTML =
      '<button class="lightbox__close" aria-label="Close">&times;</button>' +
      '<button class="lightbox__nav lightbox__nav--prev" aria-label="Previous">&#8249;</button>' +
      '<img class="lightbox__img" alt="">' +
      '<button class="lightbox__nav lightbox__nav--next" aria-label="Next">&#8250;</button>' +
      '<div class="lightbox__counter"></div>';
    document.body.appendChild(box);

    var imgEl = box.querySelector('.lightbox__img');
    var counter = box.querySelector('.lightbox__counter');
    var current = 0, gallery = [];

    function show(i) {
      current = (i + gallery.length) % gallery.length;
      var src = gallery[current].getAttribute('data-lightbox') || gallery[current].src;
      imgEl.src = src;
      imgEl.alt = gallery[current].alt || '';
      counter.textContent = (current + 1) + ' / ' + gallery.length;
    }
    function openAt(trigger) {
      var group = trigger.getAttribute('data-lightbox-group');
      gallery = group
        ? triggers.filter(function (t) { return t.getAttribute('data-lightbox-group') === group; })
        : triggers;
      box.classList.add('is-open');
      document.body.style.overflow = 'hidden';
      show(gallery.indexOf(trigger));
    }
    function close() { box.classList.remove('is-open'); document.body.style.overflow = ''; }

    triggers.forEach(function (t) {
      t.style.cursor = 'zoom-in';
      t.addEventListener('click', function () { openAt(t); });
    });
    box.querySelector('.lightbox__close').addEventListener('click', close);
    box.querySelector('.lightbox__nav--prev').addEventListener('click', function () { show(current - 1); });
    box.querySelector('.lightbox__nav--next').addEventListener('click', function () { show(current + 1); });
    box.addEventListener('click', function (e) { if (e.target === box) close(); });
    document.addEventListener('keydown', function (e) {
      if (!box.classList.contains('is-open')) return;
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowLeft') show(current - 1);
      if (e.key === 'ArrowRight') show(current + 1);
    });
  }

  /* ---------------------------------------------------------
     5. TOAST
     --------------------------------------------------------- */
  var toastEl = null, toastTimer = null;
  function showToast(msg) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'toast';
      toastEl.innerHTML = '<span class="toast__dot"></span><span class="toast__msg"></span>';
      document.body.appendChild(toastEl);
    }
    toastEl.querySelector('.toast__msg').textContent = msg;
    toastEl.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('is-visible'); }, 3600);
  }
  window.VellumToast = showToast;

  /* ---------------------------------------------------------
     6. FORM VALIDATION (lightweight)
     [data-validate] forms: required fields, email pattern.
     Shows success toast; no real backend.
     --------------------------------------------------------- */
  function initForms() {
    document.querySelectorAll('form[data-validate]').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var valid = true;
        form.querySelectorAll('[required]').forEach(function (field) {
          var wrap = field.closest('.field') || field;
          var val = (field.value || '').trim();
          var ok = !!val;
          if (ok && field.type === 'email') ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
          if (!ok) { valid = false; wrap.classList.add('has-error'); }
          else { wrap.classList.remove('has-error'); }
        });
        if (!valid) {
          var firstErr = form.querySelector('.has-error [required], [required].has-error');
          if (firstErr && firstErr.focus) firstErr.focus();
          return;
        }
        var msg = form.getAttribute('data-success') || 'Message sent — we will be in touch.';
        showToast(msg);
        form.reset();
      });
      // clear error on input
      form.querySelectorAll('[required]').forEach(function (field) {
        field.addEventListener('input', function () {
          var wrap = field.closest('.field') || field;
          wrap.classList.remove('has-error');
        });
      });
    });
  }

  /* ---------------------------------------------------------
     7. CUSTOM CHOICE (checkbox/radio) selected state for chips/opts
     --------------------------------------------------------- */
  function initChoiceState() {
    // option cards + chips reflect their input's checked state visually
    document.querySelectorAll('.opt input, .chip input').forEach(function (input) {
      function sync() {
        var holder = input.closest('.opt, .chip');
        if (!holder) return;
        if (input.type === 'radio') {
          var name = input.name;
          document.querySelectorAll('input[name="' + name + '"]').forEach(function (r) {
            var h = r.closest('.opt, .chip'); if (h) h.classList.toggle('is-selected', r.checked);
          });
        } else {
          holder.classList.toggle('is-selected', input.checked);
        }
      }
      input.addEventListener('change', sync);
      sync();
    });
  }

  /* ---------------------------------------------------------
     8. ESTIMATOR WIZARD (flagship)
     Works on estimate.html (inline) AND inside the popup modal.
     Pricing is transparent & configurable via VELLUM_PRICING.
     --------------------------------------------------------- */

  // Buyer edits these rates to match their real pricing.
  var VELLUM_PRICING = {
    // base rate per sq ft by finish level
    finish: { essential: 12, premium: 22, luxury: 40 },
    // scope multiplier
    scope: { consultation: 0.25, partial: 0.65, full: 1.0 },
    // project-type modifier
    type: { residential: 1.0, commercial: 1.15, renovation: 1.1, newbuild: 1.25 },
    currency: '$',
    rangeSpread: 0.18 // +/- band around the central estimate
  };
  window.VELLUM_PRICING = VELLUM_PRICING;

  function initEstimator(root) {
    var steps = Array.prototype.slice.call(root.querySelectorAll('.estimator__step'));
    var pips = Array.prototype.slice.call(root.querySelectorAll('.estimator__pip'));
    var btnNext = root.querySelector('[data-est-next]');
    var btnPrev = root.querySelector('[data-est-prev]');
    var readout = root.querySelector('[data-est-readout]');
    var successEl = root.querySelector('.estimator__success');
    var stepsWrap = root.querySelector('[data-est-steps]');
    var navWrap = root.querySelector('.estimator__nav');
    if (!steps.length) return;

    var idx = 0;
    var state = {
      type: 'residential', area: 800, finish: 'premium',
      scope: 'full', rooms: [], style: '', timeline: '', name: '', email: ''
    };

    function calc() {
      var perSqft = VELLUM_PRICING.finish[state.finish] || 0;
      var scopeMul = VELLUM_PRICING.scope[state.scope] || 1;
      var typeMul = VELLUM_PRICING.type[state.type] || 1;
      var central = state.area * perSqft * scopeMul * typeMul;
      var low = Math.round(central * (1 - VELLUM_PRICING.rangeSpread) / 100) * 100;
      var high = Math.round(central * (1 + VELLUM_PRICING.rangeSpread) / 100) * 100;
      return { low: low, high: high };
    }
    function fmt(n) { return VELLUM_PRICING.currency + n.toLocaleString('en-US'); }

    function updateReadout() {
      if (!readout) return;
      var est = calc();
      readout.innerHTML = '<span class="accent">' + fmt(est.low) + '</span> &ndash; <span class="accent">' + fmt(est.high) + '</span>';
    }

    function showStep(n) {
      idx = Math.max(0, Math.min(n, steps.length - 1));
      steps.forEach(function (s, i) { s.classList.toggle('is-active', i === idx); });
      pips.forEach(function (p, i) {
        p.classList.toggle('is-done', i < idx);
        p.classList.toggle('is-active', i === idx);
      });
      if (btnPrev) btnPrev.style.visibility = idx === 0 ? 'hidden' : 'visible';
      if (btnNext) btnNext.textContent = idx === steps.length - 1 ? 'Submit request' : 'Continue';
      updateReadout();
    }

    // Capture inputs within this estimator
    root.querySelectorAll('input, select').forEach(function (input) {
      input.addEventListener('change', function () {
        var key = input.getAttribute('data-est');
        if (!key) return;
        if (key === 'rooms') {
          state.rooms = Array.prototype.slice.call(
            root.querySelectorAll('[data-est="rooms"]:checked')
          ).map(function (c) { return c.value; });
        } else {
          state[key] = input.value;
        }
        updateReadout();
      });
      if (input.getAttribute('data-est') === 'area') {
        input.addEventListener('input', function () {
          state.area = parseInt(input.value, 10) || 0;
          var label = root.querySelector('[data-est-area-label]');
          if (label) label.firstChild ? label.childNodes[0].nodeValue = state.area + ' ' : label.textContent = state.area;
          updateReadout();
        });
      }
    });

    function validateStep() {
      var step = steps[idx];
      var ok = true;
      step.querySelectorAll('[required]').forEach(function (field) {
        var wrap = field.closest('.field') || field;
        var val = (field.value || '').trim();
        var good = !!val;
        if (good && field.type === 'email') good = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
        if (!good) { ok = false; wrap.classList.add('has-error'); }
        else wrap.classList.remove('has-error');
      });
      return ok;
    }

    if (btnNext) btnNext.addEventListener('click', function () {
      if (!validateStep()) return;
      if (idx === steps.length - 1) { finish(); return; }
      showStep(idx + 1);
    });
    if (btnPrev) btnPrev.addEventListener('click', function () { showStep(idx - 1); });

    function finish() {
      var est = calc();
      if (stepsWrap) stepsWrap.style.display = 'none';
      if (navWrap) navWrap.style.display = 'none';
      var prog = root.querySelector('.estimator__progress');
      if (prog) prog.style.display = 'none';
      if (successEl) {
        successEl.classList.add('is-visible');
        var range = successEl.querySelector('[data-est-final]');
        if (range) range.innerHTML = fmt(est.low) + ' &ndash; ' + fmt(est.high);
      }
      // persist (demo)
      try { localStorage.setItem('vellum-estimate', JSON.stringify({ state: state, est: est, at: Date.now() })); } catch (e) {}
    }

    showStep(0);
  }

  function initEstimators() {
    document.querySelectorAll('[data-estimator]').forEach(initEstimator);
  }

  /* ---------------------------------------------------------
     9. PROJECT FILTER (projects grid)
     --------------------------------------------------------- */
  function initFilter() {
    var filterBar = document.querySelector('[data-filter-bar]');
    if (!filterBar) return;
    var items = Array.prototype.slice.call(document.querySelectorAll('[data-filter-item]'));
    var countEl = document.querySelector('[data-filter-count]');
    filterBar.querySelectorAll('[data-filter]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var cat = btn.getAttribute('data-filter');
        filterBar.querySelectorAll('[data-filter]').forEach(function (b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        var shown = 0;
        items.forEach(function (item) {
          var match = cat === 'all' || (item.getAttribute('data-cats') || '').indexOf(cat) > -1;
          item.style.display = match ? '' : 'none';
          if (match) shown++;
        });
        if (countEl) countEl.textContent = shown;
      });
    });
  }

  /* ---------------------------------------------------------
     10. READING PROGRESS (blog single)
     --------------------------------------------------------- */
  function initReadingProgress() {
    var bar = document.querySelector('[data-reading-progress]');
    if (!bar) return;
    var article = document.querySelector('[data-article]');
    if (!article) return;
    function update() {
      var rect = article.getBoundingClientRect();
      var total = article.offsetHeight - window.innerHeight;
      var scrolled = Math.min(Math.max(-rect.top, 0), total);
      var pct = total > 0 ? (scrolled / total) * 100 : 0;
      bar.style.width = pct + '%';
    }
    window.addEventListener('scroll', update, { passive: true });
    update();
  }

  /* ---------------------------------------------------------
     11. CURSOR GLOW (ambient FX)
     --------------------------------------------------------- */
  function initCursorGlow() {
    if (document.body.classList.contains('no-fx')) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (window.matchMedia && window.matchMedia('(max-width: 768px)').matches) return;
    var glow = document.querySelector('.fx-cursor');
    if (!glow) return;
    var tx = 0, ty = 0, cx = 0, cy = 0, active = false, raf = null;
    function loop() {
      cx += (tx - cx) * 0.12;
      cy += (ty - cy) * 0.12;
      glow.style.transform = 'translate3d(' + cx + 'px,' + cy + 'px,0)';
      raf = requestAnimationFrame(loop);
    }
    window.addEventListener('mousemove', function (e) {
      tx = e.clientX; ty = e.clientY;
      if (!active) { active = true; glow.classList.add('is-active'); if (!raf) loop(); }
    }, { passive: true });
    window.addEventListener('mouseleave', function () {
      active = false; glow.classList.remove('is-active');
    });
  }

  /* ---------------------------------------------------------
     12. FLOATING PARTICLES (ambient FX)
     Subtle drifting motes on a canvas. Light, capped count.
     --------------------------------------------------------- */
  function initParticles() {
    if (document.body.classList.contains('no-fx')) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var canvas = document.querySelector('.fx-particles');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var w, h, dpr, particles = [], raf = null, running = true;

    // accent rgb (azure) — read from CSS var, fallback
    var accent = '47,111,176';
    var probe = getComputedStyle(document.body).getPropertyValue('--accent').trim();
    // keep default; CSS var is hex so we just use a fixed cool-blue tint for canvas

    function size() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.width = window.innerWidth * dpr;
      h = canvas.height = window.innerHeight * dpr;
      canvas.style.width = window.innerWidth + 'px';
      canvas.style.height = window.innerHeight + 'px';
    }
    function makeParticles() {
      var count = Math.min(34, Math.floor(window.innerWidth / 42));
      particles = [];
      for (var i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          r: (Math.random() * 1.8 + 0.7) * dpr,
          vx: (Math.random() - 0.5) * 0.1 * dpr,
          vy: (Math.random() - 0.5) * 0.1 * dpr - 0.04 * dpr,
          a: Math.random() * 0.35 + 0.18,
          tint: Math.random() > 0.5,
          tw: Math.random() * Math.PI * 2  // twinkle phase
        });
      }
    }
    function tick() {
      if (!running) return;
      ctx.clearRect(0, 0, w, h);
      for (var k = 0; k < particles.length; k++) {
        var p = particles[k];
        p.x += p.vx; p.y += p.vy;
        p.tw += 0.02;
        if (p.x < 0) p.x = w; if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h; if (p.y > h) p.y = 0;
        var ta = p.a * (0.6 + 0.4 * Math.sin(p.tw)); // gentle twinkle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.tint
          ? 'rgba(' + accent + ',' + ta + ')'
          : 'rgba(88,101,119,' + (ta * 0.8) + ')';
        ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    }
    function start() { if (!raf) { running = true; tick(); } }
    function stop() { running = false; if (raf) { cancelAnimationFrame(raf); raf = null; } }

    size(); makeParticles(); start();
    window.addEventListener('resize', function () { size(); makeParticles(); });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) stop(); else start();
    });
  }

  /* ---------------------------------------------------------
     13. SECTOR EXPLORER (architecture feature)
     Click a sector chip -> filter projects + swap capability line
     --------------------------------------------------------- */
  function initSectorExplorer() {
    var root = document.querySelector('[data-sector-explorer]');
    if (!root) return;
    var chips = root.querySelectorAll('[data-sector]');
    var items = root.querySelectorAll('[data-sector-item]');
    var blurb = root.querySelector('[data-sector-blurb]');
    var blurbs = {
      residential: 'Homes and housing — from single villas to multi-unit developments, designed around how people actually live.',
      commercial: 'Offices, retail, and mixed-use — buildings that work as hard as the businesses inside them.',
      civic: 'Libraries, schools, and public buildings — architecture in service of the community.',
      cultural: 'Museums, galleries, and performance spaces — where the building is part of the experience.'
    };
    function select(sector) {
      chips.forEach(function (c) {
        var on = c.getAttribute('data-sector') === sector;
        c.classList.toggle('is-active', on);
        c.setAttribute('aria-selected', on ? 'true' : 'false');
      });
      items.forEach(function (it) {
        var cats = it.getAttribute('data-sector-item');
        var show = sector === 'all' || cats.indexOf(sector) > -1;
        it.style.display = show ? '' : 'none';
      });
      if (blurb && blurbs[sector]) {
        blurb.style.opacity = '0';
        setTimeout(function () { blurb.textContent = blurbs[sector]; blurb.style.opacity = '1'; }, 200);
      }
    }
    chips.forEach(function (c) {
      c.addEventListener('click', function () { select(c.getAttribute('data-sector')); });
    });
    // default to first sector
    var first = chips[0];
    if (first) select(first.getAttribute('data-sector'));
  }

  /* ---------------------------------------------------------
     14. PROCESS TIMELINE (architecture feature)
     Click a phase -> expand its detail, advance the progress line
     --------------------------------------------------------- */
  function initProcessTimeline() {
    var root = document.querySelector('[data-timeline]');
    if (!root) return;
    var nodes = root.querySelectorAll('[data-phase]');
    var panels = root.querySelectorAll('[data-phase-panel]');
    var fill = root.querySelector('[data-timeline-fill]');
    function activate(idx) {
      nodes.forEach(function (n, i) {
        n.classList.toggle('is-active', i === idx);
        n.classList.toggle('is-done', i < idx);
      });
      panels.forEach(function (p, i) { p.classList.toggle('is-active', i === idx); });
      if (fill) fill.style.width = (nodes.length > 1 ? (idx / (nodes.length - 1)) * 100 : 0) + '%';
    }
    nodes.forEach(function (n, i) {
      n.addEventListener('click', function () { activate(i); });
      n.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activate(i); }
      });
    });
    activate(0);
  }

  /* ---------------------------------------------------------
     15. FULLSCREEN HERO SLIDER (architecture feature)
     --------------------------------------------------------- */
  function initHeroSlider() {
    var slider = document.querySelector('[data-hero-slider]');
    if (!slider) return;
    var slides = slider.querySelectorAll('[data-slide]');
    var dots = slider.querySelectorAll('[data-slide-dot]');
    var prev = slider.querySelector('[data-slide-prev]');
    var next = slider.querySelector('[data-slide-next]');
    var idx = 0, timer = null;
    function go(n) {
      idx = (n + slides.length) % slides.length;
      slides.forEach(function (s, i) { s.classList.toggle('is-active', i === idx); });
      dots.forEach(function (d, i) { d.classList.toggle('is-active', i === idx); });
    }
    function auto() { timer = setInterval(function () { go(idx + 1); }, 5500); }
    function reset() { clearInterval(timer); auto(); }
    if (next) next.addEventListener('click', function () { go(idx + 1); reset(); });
    if (prev) prev.addEventListener('click', function () { go(idx - 1); reset(); });
    dots.forEach(function (d, i) { d.addEventListener('click', function () { go(i); reset(); }); });
    go(0); auto();
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) clearInterval(timer); else reset();
    });
  }

  /* ---------------------------------------------------------
     INIT ALL
     --------------------------------------------------------- */
  document.addEventListener('DOMContentLoaded', function () {
    initNav();
    initReveal();
    initModals();
    initLightbox();
    initForms();
    initChoiceState();
    initEstimators();
    initFilter();
    initReadingProgress();
    initCursorGlow();
    initParticles();
    initSectorExplorer();
    initProcessTimeline();
    initHeroSlider();
    // footer year
    var y = document.querySelector('[data-year]');
    if (y) y.textContent = new Date().getFullYear();
  });
})();
