<?php
/**
 * Vellum — form mail handler
 * -------------------------------------------------------------
 * Receives form submissions (contact form + project inquiry) and
 * emails them to you. Works on any standard PHP host.
 *
 * SETUP (one line):
 *   Set $TO_EMAIL below to the address that should receive messages.
 *
 * The front-end posts JSON or form-encoded data to this file and
 * expects a JSON response: { "ok": true } or { "ok": false, "error": "..." }.
 * -------------------------------------------------------------
 */

// ===== 1. CONFIGURE THIS =====
$TO_EMAIL   = 'hello@vellum.studio';      // <-- your inbox
$SITE_NAME  = 'Vellum Studio';
$FROM_EMAIL = 'no-reply@vellum.studio';    // ideally an address on your domain
// =============================

header('Content-Type: application/json; charset=utf-8');

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

// Accept JSON or normal form posts
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    $data = $_POST;
}

// Helper: clean a value
function clean($v) {
    return trim(filter_var((string)$v, FILTER_SANITIZE_FULL_SPECIAL_CHARS));
}

// Honeypot (anti-spam): if filled, silently succeed
if (!empty($data['company'])) {
    echo json_encode(['ok' => true]);
    exit;
}

$name    = clean($data['name']    ?? '');
$email   = clean($data['email']   ?? '');
$subject = clean($data['subject'] ?? 'New enquiry');
$message = clean($data['message'] ?? '');

// Inquiry-form extra fields (optional)
$type     = clean($data['type']     ?? '');
$budget   = clean($data['budget']   ?? '');
$timeline = clean($data['timeline'] ?? '');

// Validate
$errors = [];
if ($name === '')  $errors[] = 'name';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'email';
if ($message === '' && $type === '') $errors[] = 'message';

if ($errors) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'error' => 'Please check: ' . implode(', ', $errors)]);
    exit;
}

// Build body
$lines = [];
$lines[] = "New message from your website";
$lines[] = str_repeat('-', 40);
$lines[] = "Name:    $name";
$lines[] = "Email:   $email";
if ($subject)  $lines[] = "Subject: $subject";
if ($type)     $lines[] = "Project: $type";
if ($budget)   $lines[] = "Budget:  $budget";
if ($timeline) $lines[] = "Timeline:$timeline";
$lines[] = '';
if ($message)  $lines[] = $message;
$body = implode("\n", $lines);

$mailSubject = "[$SITE_NAME] " . ($subject ?: 'New enquiry') . " — $name";

$headers = [];
$headers[] = "From: $SITE_NAME <$FROM_EMAIL>";
$headers[] = "Reply-To: $name <$email>";
$headers[] = "Content-Type: text/plain; charset=utf-8";
$headers[] = "MIME-Version: 1.0";

$sent = @mail($TO_EMAIL, $mailSubject, $body, implode("\r\n", $headers));

if ($sent) {
    echo json_encode(['ok' => true]);
} else {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Mail server error — check host mail settings.']);
}
