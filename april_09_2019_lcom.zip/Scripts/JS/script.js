$(window).on("load", function() {
      "use strict";
      $("header").load("includes/header.html");
      $(".sidemenu").load("includes/sideheader.html");
      $(".bottom-bar").load("includes/bottombar.html");

      /*------------- Full Screen --------------*/
      $("body").on("click",".fullscreen",function(){
            $(this).parents('.widget').toggleClass('fullscreen');
      });

      /*================== Panel Collapse =====================*/
      $("body").on("click",".collapse-panel-btn",function(){
            $(this).parents('.widget').find('.widget-body').slideToggle();
            let i = $(this).find('i');
            if(i.hasClass('fa-angle-double-up')){
                  i.attr('class','fa fa-angle-double-down');
            }
            else{
                  i.attr('class','fa fa-angle-double-up');
            }
            return false;
      });


      /*================== Custom Dropdown List =====================*/
      $("body").on("click",'.has-ddl > a',function(){
          $(".ddl").removeClass('active');
          $(this).next('.ddl').toggleClass('active');
          return false;
      });

      /*================== Dropdown Button =====================*/
      $("body").on("click",function(event){
            if($(event.target).parents().hasClass('has-ddl')){
                  return;
            }
            else{
                  $('.ddl').removeClass('active');
            }
      });


      /*================== Sidemenu Button =====================*/
      $("body").on('click','.sidemenu-btn',function(){
      	$(this).parent('.sidemenu').toggleClass('active');
      	return false;
      });


      /*================== Sidemenu Dropdown =====================*/
      $("body").on("click", ".sidemenu nav ul li.menu-item-has-children > a", function() {
          $(this).parent().toggleClass("active").siblings().removeClass("active");
          $(this).next("ul").slideToggle();
          $(this).parent().siblings().find("ul").slideUp();
          return false;
      });




      /*================== Open Settings =====================*/
      $("body").on("click",".open-settings",function(){
            $(this).toggleClass('active').next('.widget-settings-inner').slideToggle();
            return false;
      });


      /*================== By Default Sidemenu Collapse on Small Screen =====================*/
      if($(window).width() < 1025){
            $(".sidemenu").addClass('active');
      }


      $("body").on("click",".table-action > a",function(){
            $(this).parents('tr').siblings().find('.action-drop').removeClass('active');
            $(this).parents('td').css({'overflow':'visible'});
            $(this).siblings('.action-drop').toggleClass('active');
            return false;
      });





      /*=== Render DATA from JSON on Top Icons ===*/
      var jobs;
      var vehicles;
      $.get("Scripts/JS/icons.json", function( data ) {
            jobs = data.jobsStatus;
            vehicles = data.vehicleStatus;
            $.each(jobs, function(idx,val){
                  $(".icon-set.jobsStatus").append(`<a data-toggle="tooltip" data-placement="bottom" class="icon-btn style2" href="affiliate-dashboard2.html#jobStatusLink" title=" ${jobs[idx].title} "><span class="${jobs[idx].icon}"></span><i>${jobs[idx].count}</i></a>`);
            });
            $.each(vehicles, function(idx,val){
                  $(".icon-set.vehicleStatus").append(`<a data-toggle="tooltip" data-placement="bottom" class="icon-btn style2" href="affiliate-dashboard2.html#fleetStatusLink" title=" ${vehicles[idx].title} "><span class="${vehicles[idx].icon}"></span><i>${vehicles[idx].count}</i></a>`);
            });
            $('[data-toggle="tooltip"]').tooltip()
      });


      setInterval(function cf(){
            $.get("Scripts/JS/icons.json", function( data ) {
                  jobs = data.jobsStatus;
                  vehicles = data.vehicleStatus;
                  var i = 1;
                  $.each(jobs, function(idx,val){
                        $(".icon-set.jobsStatus a:nth-child(" + i + "n) i").html(jobs[idx].count);
                        $(".icon-set.vehicleStatus a:nth-child(" + i + "n) i").html(vehicles[idx].count);
                        i++;
                  });
            });
      },5000);


      /*================== Plugins Initializations =====================*/

      /*=== Select2 ===*/
      $('.select,.bottom select').select2({
            placeholder: 'Select an option'
      });



      /*=== Font Awesome ===*/
      window.FontAwesomeConfig = {
            searchPseudoElements: true
      }


      /*=== Tooltip ===*/
      $('[data-toggle="tooltip"]').tooltip({
          trigger : 'hover'
      })

      /*------------- preloader js --------------*/
      $('.loader-container').delay(500).fadeOut('slow');// will first fade out the loading animation
      $('.page-loader').delay(500).fadeOut('slow');// will fade out the white DIV that covers the website.


      /*------------- Toggle Button --------------*/
      $('.cb-value').click(function() {
            var mainParent = $(this).parent('.toggle-btn');
            if($(mainParent).find('input.cb-value').is(':checked')) {
                  $(mainParent).addClass('active');
            } else {
                  $(mainParent).removeClass('active');
            }

      });



      $(".widget, .show-options").each(function(){
            if($(this).attr('data-refresh') ==  "true"){
                  $(this).find('.widget-options').append(`<a href="#" title="Refresh"><i class="fas fa-sync-alt"></i></a>`);
            }
            if($(this).attr('data-autorefresh') ==  "true"){
                  $(this).find('.widget-options').append(`<a href="" title="Auto Refresh"> <img src="images/icons/auto-refresh.png" alt="" /> </a>`);
            }
            if($(this).attr('data-external') ==  "true"){
                  $(this).find('.widget-options').append(`<a href="#" title="Open In A New Window"><i class="fas fa-external-link-alt"></i></a>`);
            }
            if($(this).attr('data-fullscreen') ==  "true"){
                  $(this).find('.widget-options').append(`<a  class="fullscreen" href="#" title="Full Screen"><i class="fas fa-expand"></i></a>`);
            }
            if($(this).attr('data-settings') ==  "true"){
                  $(this).find('.widget-options').append(`<a href="preferences.html" title="Control Settings"><i class="fa fa-cog"></i></a>`);
            }
            // Width
            if($(this).attr('data-width')){
                  if($(this).attr('data-width') == '25%'){
                        $(this).parent().attr('class','col-lg-3');
                  }
                  else if($(this).attr('data-width') == '33%'){
                        $(this).parent().attr('class','col-lg-4');
                  }
                  else if($(this).attr('data-width') == '50%'){
                        $(this).parent().attr('class','col-lg-6');
                  }
                  else if($(this).attr('data-width') == '75%'){
                        $(this).parent().attr('class','col-lg-8');
                  }
                  else{
                        $(this).parent().attr('class','col-lg-12');
                  }
            }
            // Height
            if($(this).attr('data-height')){
                  let hgt = $(this).attr('data-height');
                  $(this).find('.widget-body').css('height', hgt);
            }
            // Collapse State
            if($(this).attr('data-collapsestate') == "true"){
                  $(this).find('.widget-body').css('display','none');
                  $(this).find('.collapse-panel-btn').find('i').attr('class', 'fa fa-angle-double-down');
            }
            // Separator
            if($(this).attr('data-separator') == "true"){
                  $(this).parent().append(`<hr class="custom-border">`);
            }
            // X Position
            if($(this).attr('data-xposition')){
                  let xpos = $(this).attr('data-xposition') + 'px';
                  $(this).parent().css('left', xpos);
            }
            // Y Position
            if($(this).attr('data-yposition')){
                  let ypos = $(this).attr('data-yposition') + 'px';
                  $(this).parent().css('top', ypos);
            }
            // Alignment  // If Alignement is Set To Middle Or Right the X Position Attribute will be ignored
            if($(this).attr('data-alignment') == 'middle'){
                  $(this).parent().css('left', '50%');
                  $(this).parent().css('transform', 'translateX(-50%)');
            }
            if($(this).attr('data-alignment') == 'right'){
                  $(this).parent().css('left', '100%');
                  $(this).parent().css('transform', 'translateX(-100%)');
            }
      });


      var x = '';
      function StartAutoRefresh(){
            x = setTimeout(function(){
                  console.log('Done');
            },2000);
      }

      $(".widget").on("click",function(){
            x != 'null' ? clearTimeout(x):'';
            StartAutoRefresh();
      });





});
