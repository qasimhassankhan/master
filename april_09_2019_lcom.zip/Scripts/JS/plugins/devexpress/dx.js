

$(document).ready(function(){

	
    setInterval(function cf(){
		notifications();
    },5000);

    function notifications(){
		
		
		
		
		var file = "Scripts/JS/plugins/devexpress/notes.json";
		
		if( $("#txtHiddenFolder").val()=='INBOX')
			file = "Scripts/JS/plugins/devexpress/inbox.json";
		if( $("#txtHiddenFolder").val()=='ARCHIVE')
			file = "Scripts/JS/plugins/devexpress/archive.json";
		if( $("#txtHiddenFolder").val()=='TRASH')
			file = "Scripts/JS/plugins/devexpress/trash.json";
		
		
		
		
		$.get(file, function( data ) {
				var Columndata2 = data.Notifications;
				var headings2 = data.Headings;
				var dataGrid = $("#notifications").dxDataGrid({
					dataSource: Columndata2,
					columnMinWidth:50,
					columns: headings2,
					allowColumnReordering: true,
					allowColumnResizing: true,
					columnResizingMode: "widget", // "nextColumn" or "widget"
					showRowLines: false,
					rowAlternationEnabled: true,
					scrolling: {
							columnRenderingMode: "virtual"
					},
					showBorders: false,
					columnChooser: {
                                enabled: false,
                                mode: "select" // or "select" or "dragAndDrop"
                            },
					paging: {
							pageSize:7
					},
					filterRow: {
							visible: false,
							applyFilter: "auto"
					},
					searchPanel: {
							visible: false,
							width: 240,
							placeholder: "Search..."
					},
					headerFilter: {
							visible:false
					},
					sorting: {
							mode:"single"
					},
                              onContentReady: function(e) {
                                    /*=== Tooltip ===*/
                                    $('[data-toggle="tooltip"]').tooltip({
                                    container: '.layout-wrapper'
                                    });
									
								$("#notifications").parents('.widget').find(`.loader`).detach();	
                              },
                              onRowClick:function(){
                                    $('#read-notification').modal('toggle')
                              }
                        }).dxDataGrid('instance');
		});
    }
	function LoadMessages(vFolder) {
				SetActiveFolder(vFolder);
				$("#txtHiddenFolder").val(vFolder);
				notifications();
			}
			function SetActiveFolder(vFolder) {
				if (vFolder == 'INBOX') {
					$("#MsgInboxLink").css("background-color", "#eff");
					$("#MsgTrashLink").css("background-color", "#fff");
					$("#MsgArchiveLink").css("background-color", "#fff");
				}
				else if
					(vFolder == 'TRASH') {
					$("#MsgInboxLink").css("background-color", "#fff");
					$("#MsgTrashLink").css("background-color", "#eff");
					$("#MsgArchiveLink").css("background-color", "#fff");
				}
				else if
					(vFolder == 'ARCHIVE') {
					$("#MsgInboxLink").css("background-color", "#fff");
					$("#MsgTrashLink").css("background-color", "#fff");
					$("#MsgArchiveLink").css("background-color", "#eff");
				}
				
			}
	LoadMessages('INBOX');
    //notifications();


			var data_for_dev;
			var getHeadings = [];
			var getRow = [];
			var getData = [];

			$.ajax({
			method: "GET",
			url: "Scripts/JS/plugins/devexpress/jobs.json",
			dataType: "JSON"
			}).success(function( data ) {
				$.each(data.JMetaData.colHeading ,function(i, e){
					getHeadings.push(`{"dataField": "` + data.JMetaData.colHeading[i] + `"}`);
				});
				$.each(data.JData ,function(rowindex, e){
					$.each(data.JData[rowindex] ,function(dataindex, e){
						getData.push(`"` + data.JMetaData.colHeading[dataindex] + `" : "` + data.JData[rowindex][dataindex] + `"`)
					});
					getRow.push(`{` + getData + `}`);
				});


				data_for_dev = `{
				"header" : [
					{"ActionCode"	: "1"},
					{"Message"		: "Request is parsed successfully and corresponding response is generaed!"},
					{"SysVersion"	: "1.0.2"}
				],
				"Headings":[` + getHeadings + `],
				"jData" :[` + getRow +  `]
				}`;
				data_for_dev = JSON.parse(data_for_dev);
			});




			//$.get("Scripts/JS/plugins/devexpress/jobs.json", function( data ) {
				$.get("Scripts/JS/plugins/devexpress/oldJson.json", function( data ) {
				/*var Columndata = data_for_dev.jData;
				var headings = data_for_dev.Headings;
				var newColumnData = [];

				$.each(Columndata, function( index, value ) {
					let temp = [];
					temp[0] = Columndata[index].RESERVATION_NUM;
					temp[1] = Columndata[index].RIDE_DATE + "<br>" + Columndata[index].RIDE_TIME;
					temp[2] = Columndata[index].PASSENGER_NAME + "<br>" + Columndata[index].VIP_NUM;
					temp[3] = Columndata[index].PHONE_NUM + "<br>" + Columndata[index].EMAIL_ADDRESS;
					temp[4] = Columndata[index].PICKUP_ADDRESS + "<br>" + Columndata[index].DROPOFF_ADDRESS;
					temp[5] = Columndata[index].CAR_NUM + "<br>" + Columndata[index].DRIVER_NAME;
					temp[6] = Columndata[index].JOB_STATUS + "<br>" + Columndata[index].CAR_STATUS;
					newColumnData.push(temp);
				});

getHeadings.push(`{ "caption": "ACTIONS",  "width": 150 , "cellTemplate": "" }`);*/

				//=================================================
				var dataGrid = $("#gridContainer").dxDataGrid({
						dataSource: data.jData,//Columndata,
						columnMinWidth: 30,
						columns: data.Headings,
									/*
                                    columns: [
                                                      {dataField: "RES #"},
                                                      {dataField: "ORIG_LINE_NUM"},
                                                      {dataField: "LINE_NUM"},
                                                      {dataField: "ORIGINATE_DATE_TIME"},
                                                      {dataField: "ACCOUNT_NUM"},
                                                      {dataField: "ACCOUNT_NAME"},
                                                      {dataField: "VIP_NUM"},
                                                      {
                                                            dataField: "Actions",
                                                            caption: "Actions",
                                                            width: "150px",
                                                            cellTemplate: `<div class='action'><select class='select'><option>Select</option><option>Assign</option><option>Not Assign</option><option>Reject</option></select><input type='text' value='' style='width:40px;padding:3px' /><a class='td-icon' href='#' title=''><i class='fa fa-save'></i></a></div>`
                                                      }

                                                ],
									*/			
						allowColumnReordering: true,
						allowColumnResizing: true,
						columnResizingMode: "widget", // "nextColumn" or "widget"
						showRowLines: true,
						rowAlternationEnabled: true,
						scrolling: {
								columnRenderingMode: "virtual"
						},
						showBorders: true,
						paging: {
								pageSize:7
						},
						filterPanel: { visible: true },
						filterRow: {
								visible: true,
								applyFilter: "auto"
						},
						searchPanel: {
								visible: true,
								width: 240,
								placeholder: "Search..."
						},
						headerFilter: {
								visible: true
						},
						sorting: {
								mode:"single"
						},
                                    onRowClick:function(){
                                    },
                                    onInitialized: function (e) {
      						setTimeout(function(){
      							$('.select').select2({
      								placeholder: 'Select an option'
      							});
      						},30);
      					},                           
                                    onCellClick: function (e) {
                                          console.log(e.rowType);
                                      if (e.columnIndex != (e.row.cells.length - 1)) {
                                            location.href = "job-detail.html";
                                      }else{
                                      }
                                  }
				}).dxDataGrid('instance');
				}).then(function(){
				setTimeout(function(){
					$($(".dx-datagrid-filter-row td")).each(function(i,e){
						let getcode = $(this).find('.dx-editor-with-menu');
						var puthere = $($(".custom-heading")[i]);
						$(getcode).appendTo(puthere);
					});
					$(".dx-header-row").addClass('dx-datagrid-filter-row');

					$(".custom-heading").on("click",function(e){
							$(this).find('.dx-editor-with-menu').addClass('show');
							e.stopPropagation();
					});

					$('html').on('click',function(e){
						$('.dx-editor-with-menu').removeClass('show');
					});

				},100);
				$($(".dx-datagrid-search-panel")).appendTo(".dev_search");
			});




			function asc(cn, a, b) {
				return a[cn] - b[cn];
			}

			function desc(cn, a, b) {
				console.log(cn);
				return b[cn] - a[cn];
			}

			function ascBtn(colname) {
					var dg = $("#gridContainer").dxDataGrid("instance");
					var sortedJson = dg._options.dataSource.sort(asc.bind(this,colname));
					$("#gridContainer").dxDataGrid({dataSource: sortedJson});
			}
			function descBtn(colname) {
					var dg = $("#gridContainer").dxDataGrid("instance");
					var sortedJson = dg._options.dataSource.sort(desc.bind(this,colname));
					$("#gridContainer").dxDataGrid({dataSource: sortedJson});
			}



	});
