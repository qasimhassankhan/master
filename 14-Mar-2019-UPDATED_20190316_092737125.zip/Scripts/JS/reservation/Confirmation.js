
    var directionsService = null;
    var directionsDisplay = null;
    var lat_lng = new Array();
    var infoWindows = [];
    var infoMarkers = [];
    var map = null;
    var locations = null;

    var isMap = true;
    //alert(locations);
    locations = [
            ['<b>Car is at the pickup location.</b>', 40.63747894421177, -74.01819999999998, 9], //6305 5th Ave, Brooklyn, NY 11220, USA
            ['<b>Passenger is in the car.</b>', 40.63747894421177, -74.01819999999998, 11],
            ['<b>Passenger dropped off.</b>', 40.5283, -74.1891, 13] //1065 Huguenot Ave, Staten Island, NY 10312, USA
];
        //'<b>Driver accepted the call.</b>',40.6273,-74.0234,4],
        for (i = 0; i < locations.length; i++) {
            var myLatlng = new google.maps.LatLng(locations[i][1], locations[i][2]);
    lat_lng.push(myLatlng);
}
//alert(lat_lng.length);
var l = Math.floor(lat_lng.length / 2);

        function initMap() {
        map = new google.maps.Map(document.getElementById('map_canvas'), {
            zoom: 16,
            center: lat_lng[l]
        });
    directionsService = new google.maps.DirectionsService;
    directionsDisplay = new google.maps.DirectionsRenderer;

    directionsDisplay.setMap(map);
            directionsDisplay.setOptions({suppressMarkers: true });
    calculateAndDisplayRoute(directionsService, directionsDisplay);

}

        function calculateAndDisplayRoute(directionsService, directionsDisplay) {
            var waypts = [];
            for (var i = 1; i < lat_lng.length - 1; i++) {
        waypts.push({
            location: lat_lng[i],
            stopover: true
        });
    }

            directionsService.route({
        origin: lat_lng[0],
    destination: lat_lng[lat_lng.length - 1],
    waypoints: waypts,
    optimizeWaypoints: true,
    travelMode: 'DRIVING'
            }, function (response, status) {
                if (status === 'OK') {
        directionsDisplay.setDirections(response);
    var route = response.routes[0];
    var count = route.legs.length;

                    for (var i = 0; i <= route.legs.length; i++) {
                        var myLatlng = new google.maps.LatLng(locations[i][1], locations[i][2]);
    var strText = locations[i][0];
                        var IsContain = strText.includes("<b>");
    //alert(IsContain)
                        if ($.trim(locations[i][3]) == "9" || $.trim(locations[i][3]) == "13") {
                            var vIcon = "";
                            if ($.trim(locations[i][3]) == "9") {//=================at pickup location
            vIcon = "images/pin_on_location.png";
        }
                            else if ($.trim(locations[i][3]) == "13") {//=================passenger dropoff
            vIcon = "images/pin_drop_off_location.png";
        }
                            else {
            vIcon = null;
        }
                            var marker = new google.maps.Marker({
            position: myLatlng,
        map: map,
        icon: vIcon
    });
    var infowindow = new google.maps.InfoWindow();
                            var strContent = "<h3>" + locations[i][0] + "</h3>";
        infowindow.setContent(strContent);
                            if (i == 0) {
            //infowindow.open(map, marker);
        }

        infoWindows.push(infowindow);
        infoMarkers.push(marker);
    }

}
SetClickEvent();
ShowAddressInfo();
                } else {
            //window.alert('Directions request failed due to ' + status);
            //window.alert("Tracking data is not available for this call");
            ShowMessage("Tracking data is not available for this call");
        }
    });

}

        function SetClickEvent() {
            //alert(infoWindows.length);
            for (var i = 0; i < infoWindows.length; i++) {
                var marker = infoMarkers[i];
                google.maps.event.addListener(marker, 'click', (function (marker, i) {
                    return function () {
            //infowindow.setContent(strContent);
            infoWindows[i].open(map, marker);
        }
    })(marker, i));
}
}
        function ShowInfoWindow(index) {
            for (var i = 0; i < infoWindows.length; i++) {
                var infowindow = infoWindows[i];
                if (infowindow) {
            infowindow.close();
        }
    }
    var marker = infoMarkers[index];
    infoWindows[index].open(map, marker);
}


        $(document).ready(function () {
            //initMap();

        });

    
        $(document).ready(function () {

            $('.lblSelectedCar').addClass('hidden');
        $('#liSignOut').click(function (e) {
            bootbox.confirm("Do you want to Sign out ?", function (result) {
                if (result == true) {
                    loginPage();
                }
            });
        });//clearTxt

            $('.clearTxt').click(function (e) {

            $('#selectedCar').text('Select more car types here ...');
        $('.clearTxt').addClass('hidden');
        // $('.clearTxt').removeClass('active');
        $('.lblSelectedCar').addClass('hidden');

        $('#selectedCar').css("margin-top", "0px");

        $(".special-box").slideToggle();
        $('.carType').removeClass('disabled').find(".pickup-points").removeClass('active').find(".pickup-point").addClass("disabled").removeClass("selected");
        //$('.luxSedan').removeClass('disabled').find(".pickup-points").removeClass('active').find(".pickup-point").addClass("disabled").removeClass("selected");
        //$('.execSuv').removeClass('disabled').find(".pickup-points").removeClass('active').find(".pickup-point").addClass("disabled").removeClass("selected");


        // return false;
    }); //cancleSelection


            $('.cancleSelection').click(function (e) {

            $('#selectedCar').text('Select more car types here ...');
        $('.clearTxt').addClass('hidden');
        // $('.clearTxt').removeClass('active');
        $('.lblSelectedCar').addClass('hidden');

        $('#selectedCar').css("margin-top", "0px");

        //  $(".special-box").slideToggle();
        $('.carType').removeClass('disabled');
        //$('.luxSedan').removeClass('disabled');
        //$('.execSuv').removeClass('disabled');


        // return false;
    }); //cancleSelection
            $('#moreTypes').click(function (e) {


                //$(".special-box").slideUp();
                //$(".more > a").removeClass('active');
                //$('.open-bodyPayment').addClass('hidden');
                //$('.execSedan').parents('.limonet-panel-body').slideUp();
                //$('.execSedan').parents('.limonet-panel').addClass('collapsed');



                //$(".limonet-panel.dropoff").removeClass('hidden');
                //$("#collapseTwo").addClass('inSection');

                return false;
    });
            $('.carType').click(function (e) {

            // $(this).parent().siblings('.pickup-points').addClass('active');
            $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
        $(this).parents('.limonet-area').removeClass("disabled");
        $(this).removeClass("disabled");

        $(this).find(".pickup-points").addClass('active');
        $(".pickup-point").removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");

        $(".special-box").slideUp();
        $(".more > a").removeClass('active');
        $('.open-bodyPayment').addClass('hidden');
        $(".limonet-panel.dropoff").removeClass('hidden');
        $(this).parents('.limonet-panel-body').slideUp();
        $(this).parents('.limonet-panel').addClass('collapsed');
        $('#collapseTwo').removeClass('collapse');
        return false;
    });

            $('.luxSedan').click(function (e) {

            $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
        $(this).parents('.limonet-area').removeClass("disabled");
        $(this).removeClass("disabled");

        $(this).find(".pickup-points").addClass('active');
        $(".pickup-point").removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");

        $(".special-box").slideUp();
        $(".more > a").removeClass('active');
        $('.open-bodyPayment').addClass('hidden');
        $(".limonet-panel.dropoff").removeClass('hidden');
        $(this).parents('.limonet-panel-body').slideUp();
        $(this).parents('.limonet-panel').addClass('collapsed');
        $('#collapseTwo').removeClass('collapse');
        return false;
    });
            $('.execSuv').click(function (e) {

            $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
        $(this).parents('.limonet-area').removeClass("disabled");
        $(this).removeClass("disabled");

        $(this).find(".pickup-points").addClass('active');
        $(".pickup-point").removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");


        $(".special-box").slideUp();
        $(".more > a").removeClass('active');
        $('.open-bodyPayment').addClass('hidden');
        $(".limonet-panel.dropoff").removeClass('hidden');
        $(this).parents('.limonet-panel-body').slideUp();
        $(this).parents('.limonet-panel').addClass('collapsed');
        $('#collapseTwo').removeClass('collapse');
        return false;
    });
});
        $(document).ready(function () {
            $('#liSignOut2').click(function (e) {
                bootbox.confirm("Do you want to Sign out ?", function (result) {
                    if (result == true) {
                        loginPage();
                    }
                });
            });
        });

        function GetCustomerPicture(results) {
            bootbox.alert(results);
        }

        function loginPage() {
            $.ajax(
                {
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: "/EliteService.asmx/LogOut",
                    success: succeeded_previous,
                    error: failed_previous
                });
        }

        function succeeded_previous(result) {
            if (result.d == "true") {
            window.location.href = "Confirmation.html";
        }
    }

        function failed_previous(parameters) {

        }

        function NewBooking() {
            $.ajax(
                {
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: "/EliteService.asmx/CancelBookACar",
                    success: succeeded_prev,
                    error: failed_prev
                });
        }

        function succeeded_prev(result) {
            if (result.d == "true") {
            window.location.href = "Confirmation.html";
        }
    }

        function failed_prev(parameters) {

        }



        $(document).ready(function () {

            //$('#moreTypes td').each(function () {
            //    var cellText = $(this).text();
            //   // alert(cellText);
            //});
            $("#moreTypes tr").click(function () {

                if (this.className == 'limo') {
                    $('#selectedCar').text('Stretch Limo: Lincoln MKT, Chrysel or Similar');
                }
                else if (this.className == 'Sprinter') {
                    $('#selectedCar').text('Luxury Sprinter');
                }
                else if (this.className == 'mini') {
                    $('#selectedCar').text('Mini BUS');
                }
                else if (this.className == 'Coach') {
                    $('#selectedCar').text('Motor Coach');
                }

                $('.clearTxt').removeClass('hidden');
                $('.lblSelectedCar').removeClass('hidden');
                $('#selectedCar').css("margin-top", "-38px");

                $('.carType').addClass('disabled').find(".pickup-points").removeClass('active').find(".pickup-point").addClass("disabled").removeClass("selected");
                //$('.carType').addClass('disabled').find(".pickup-points").removeClass('active').find(".pickup-point").addClass("disabled").removeClass("selected");
                //$('.carType ').addClass('disabled').find(".pickup-points").removeClass('active').find(".pickup-point").addClass("disabled").removeClass("selected");

                $(".special-box").slideUp();
                $(".more > a").removeClass('active');
                $('.open-bodyPayment').addClass('hidden');
                $('.carType').parents('.limonet-panel-body').slideUp();
                $('.carType').parents('.limonet-panel').addClass('collapsed');



                $(".limonet-panel.dropoff").removeClass('hidden');
                $("#collapseTwo").addClass('inSection').removeClass("collapse");

            });

        $("#vehicalSelection").click(function () {
                debugger;
                if (!$("#collapseOne").hasClass("inSection")) {
            $("#collapseOne").addClass('inSection');
        }
                else {
            $("#collapseOne").removeClass('inSection');
        }

        // $("#collapseOne").removeClass('in');
    });//

            $("#vehicalPayment").click(function () {
                debugger;
                if (!$("#collapseTwo").hasClass("inSection")) {
            $("#collapseTwo").addClass('inSection');
        }
                else {
            $("#collapseTwo").removeClass('inSection');
        }

        // $("#collapseOne").removeClass('in');
    });//
            $("#vehicleReview").click(function () {
                debugger;
                if (!$("#collapseThree").hasClass("inSection")) {
            $("#collapseThree").addClass('inSection');
        }
                else {
            $("#collapseThree").removeClass('inSection');
        $("#collapseThree").removeClass('in');
    }

    // $("#collapseOne").removeClass('in');
});//vehicleReview

getCarList();
//fill dynamic year dropdown;
            $('#txtPersInputSecurityCode').keyup(function () {
                var count = $('#txtPersInputSecurityCode').val().length;
                if (count <= 4) {
                    return true;
    }
                else {
            $('#txtPersInputSecurityCode').val($('#txtPersInputSecurityCode').val().slice(0, -1));
        }
            }).blur(function () {
                var count = $('#txtPersInputSecurityCode').val().length;
                if (count < 3) {
            $('#txtPersInputSecurityCode').css("border", "1px solid red");
        } else {
            $('#txtPersInputSecurityCode').css("border", "");
        }
    });

            $('#txtCorPassword').keyup(function () {
                var count = $('#txtCorPassword').val().length;
                if (count <= 4) {
                    return true;
    }
                else {
            $('#txtCorPassword').val($('#txtCorPassword').val().slice(0, -1));
        }
            }).blur(function () {
                var count = $('#txtCorPassword').val().length;
                if (count < 3) {
            $('#txtCorPassword').css("border", "1px solid red");
        } else {
            $('#txtCorPassword').css("border", "");
        }
    });

    $("#hidePerCreditCard").css("display", "none");
    $("#hideCorCreditCard").css("display", "none");

    //window.onbeforeunload = HandleBackFunctionality();
            $.ajax({
            url: "/EliteService.asmx/BindCountryCode",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: succeeded_previousBCC,
        error: failed_previousBCC
    });

});
var saveAddPhoneSelectedIndex = 0;
var saveAddAltPhoneSelectedIndex = 0;
var saveEmailSelectedIndex = 0;
var saveCCEmailSelectedIndex = 0;
var countryJson;

        function succeeded_previousBCC(result) {

            countryJson = JSON.parse(result.d);

        }

        function failed_previousBCC(result) {
        }

        $("#drpdwnCorporateCC").change(function () {
            var end = this.value;
        var firstDropVal = $('#pick').val();
    });

    //get car list from web service
        function getCarList(parameters) {
            $('#dvLoading').show();
        $.ajax(
                {
            type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/EliteService.asmx/GetCarList",
        success: succeeded_previousGC,
        error: failed_previousGC
    });

return false;
}

var restInfoDetail;     //store restInfoDetail from web service.
var carList;        //store car list from web service.
var vehicleList;        //store vehicle image list from web service.
var customerInfo;       //store customer information from web service
var FareInfoArray = [];
var pickUpAddress;      //get full address from pickup address. use in GetCarList Success method
var dropOffAddress;     //get full address from DROP OFF address. use in GetCarList Success method
var resTimewithHour;
var resDateTime;        //Get only date from json full string .use in GetCarList Success method
var resHour;            //Get only hour from json full string .use in GetCarList Success method
var paymentType;        //store payment type to receive credit card info or not.
var accountRequest;     //store account request on pageload
var customInfoAccountNum;

//BSA 12-19-2016
var phoneContacts;  //store saved phone numbers
var emailContacts;  //store saved email addresses

//genarate dynamic html vehical selection from ws_GetCarList from web service
        function succeeded_previousGC(result) {
            debugger;
        $('#collapseOne').html('');
        var myJsonString = JSON.parse(result.d);
            if (myJsonString != null) {
                if (myJsonString.Code == '0') {
            bootbox.alert("<h4>" + myJsonString.Message + "</h4>", function () {
                editReviewDetail()
            });

        $('#dvLoading').hide();
                } else {
                    var string = '';
        restInfoDetail = myJsonString.restInfoFull;
        carList = myJsonString.carList;
        vehicleList = myJsonString.VehicleList;
        customerInfo = myJsonString.CustInfo;

        GetAddressandDate(restInfoDetail);
                    string = string + '<div class="panel-body">';
        var fareInfo = '';
                    for (var i = 0; i < carList.length; i++) {
                        for (var j = 0; j < vehicleList.length; j++) {
                            if (carList[i].CarTypeCode == vehicleList[j].CarTypeCode) {
                                var price = 0;
                                if (carList[i].Price == 'CALL') {
                price = "'" + carList[i].Price + "'";
            } else {
                price = carList[i].Price;
            price = price.replace(",", "");
        }
        //NEW
                                var description = '<div id="divFareInfo_' + i + '" >' + carList[i].Description + '</div>';
            FareInfoArray.push(description);
                                string = string + '<div class="option-container" id="divMainCar_' + i + '" ><div class="row"><div class="col-md-5">';
                                string = string + '<img src=' + vehicleList[j].ImageURL + ' alt="elite premium sedan" class="img-responsive" /></div>';
                                string = string + '<div class="col-md-2"><div class="inner-address"><span class="label label-success">Pick-Up</span>';
                                string = string + '<br /><br /><address>' + pickUpAddress + '</address>';
                                string = string + '<h5><strong>Date:</strong>' + resDateTime + '</h5>';
                                string = string + '<h5><strong>Time:</strong> ' + resHour + '</h5></div></div>';
                                string = string + '<div class="col-md-2"><div class="inner-address"><span class="label label-info">Drop-Off</span>';
                                string = string + '<br /><br /><address>' + dropOffAddress + '</address></div></div>';
                                string = string + '<div class="col-md-3" ><div style="margin-top: 20px; height: 204px;" class="option-selection" id="car_' + i + '_' + carList[i].CarTypeCode + '"><br /><div id="div_' + i + '_' + carList[i].CarTypeCode + '" style="display:none;"></div><span>$</span><span>' + carList[i].Price + '</span><br /><h5 onclick="return openFareInfo(' + i + ')"><b style="color:white;cursor:pointer;" >FARE INFO</b></h5><h4>ETA: ' + carList[i].ETA + '</h4>';
                                string = string + '<button type="button" class="btn btn-primary" id="btnSelect_' + i + '_' + carList[i].CarTypeCode + '" onclick="return openPaymentModule(\'' + carList[i].CarTypeCode + '\', ' + i + ',' + price + ')">Select</button></div></div>';
                                string = string + '</div></div> ';
        }
    }
}
                    string = string + '</div>';
        $('#collapseOne').html(string);
        $('#collapseOne').addClass("panel-collapse collapse in");
        $('#collapseOne').css("height", "");
    }
}
$('#dvLoading').hide();
}

        function failed_previousGC(result) {
        }

        var customerCCInfo1;
        //bind CreditCard calling from page load
        function GetCreditCard(results) {
            var myJsonString = JSON.parse(results);
            if (myJsonString != null) {
            customerCCInfo1 = myJsonString.CCList;
        }

        var myselect = document.getElementById("drpexpireYY"), year = new Date().getFullYear();
            var gen = function (max) {
                do {
            //   myselect.add(new Option(year, year), null);
            year = year + 1;
        max = max - 1;
    } while (max > 0);
}(21);
$("#drpexpireMM").val(0);
$("#drpexpireYY").val(0);

var myselect1 = document.getElementById("drcorpexpireYY"), year = new Date().getFullYear();
            var gen1 = function (max) {
                do {
            myselect1.add(new Option(year, year), null);
        year = year + 1;
        max = max - 1;
    } while (max > 0);
}(21);
$("#drcorpexpireMM").val(0);
$("#drcorpexpireYY").val(0);


//preserver previous value after coming on edit mode
var itemValue = localStorage.getItem("optionRB");
            if (itemValue != null && itemValue != "") {
                if (itemValue == "inlineRadio2Corporate") {
            $("input[id=\"" + itemValue + "\"]").click();
        var itemPaytype = localStorage.getItem("PMType");
        //localStorage.setItem("PMType", paymentType);
        var itemAccNum = localStorage.getItem("AccNum");

        paymentType = itemPaytype;
        customInfoAccountNum = itemAccNum;
        SelectSingleRadiobutton("inlineRadio2Corporate");
        localStorage.setItem("optionRB", "");
        localStorage.setItem("PMType", "");
        localStorage.setItem("AccNum", "");
                } else {
                    var creditCardId = localStorage.getItem("optionRB1");
        $("input[id=\"" + itemValue + "\"]").click();
        document.getElementById('ContentPlaceHolder1_drpdwnPersonalCC').value = creditCardId;
        GetPerTextBoxValue();
        //GetCorTextBoxValue();
        localStorage.setItem("optionRB", "");

        localStorage.setItem("optionRB1", "");
    }
    $('#dvLoading').hide();
}
}

//calling from page load
        function pageLoadCustoInfo(result, ccresults) {
            $('#dvLoading').show();
        var myJsonString = result;
            if (myJsonString != null) {
            paymentType = myJsonString.PaymentType;
        var accReq = myJsonString.AcctReqs;
        customInfoAccountNum = result.AccountNum;

                if (!$.isArray(accReq) || !accReq.length) {
            accountRequest = "";
        } else {
            accountRequest = myJsonString.AcctReqs;
        }

        //BSA 12-19-2016
        var phoneCon = result.PhoneContacts;
        var emailCon = result.EmailContacts;
                if (!$.isArray(phoneCon) || !phoneCon.length) {
            phoneContacts = "";
        } else {
            phoneContacts = result.PhoneContacts;
        }

                if (!$.isArray(emailCon) || !emailCon.length) {
            emailContacts = "";
        } else {
            emailContacts = result.EmailContacts;
        }
    }
    $('#dvLoading').hide();
}


//Redirect to book a car page ,when click on edit in review section.
        function editReviewDetail() {
            localStorage.setItem("optionRB", selectedRadioButton);
        localStorage.setItem("optionRB1", selectedCC);
        window.location = "Confirmation.html?edit=true";
    }

    //select car inside vehical selection .select only 1 car at a time.
        function getCarTypeCodeandPrice(carTypeId, i, price) {
            selectedCarTypeCode = carTypeId;
        selectedPrice = price;
        carPrice = price;
            if (price == 'CALL') {
            selectedPrice = 0;
        }

            if (previousSelected == carTypeId || statusCar == "Selected") {
                var divClass = $("#car_" + i + "_" + carTypeId).attr("class");
                if (divClass == "option-selection") {
                    if (previousSelectedButton != '') {
            $("#" + previousSelectedButton).removeClass();
        $("#" + previousSelectedButton).addClass("option-selection");
        $("#" + previousDiv).css("border", "1px solid #ccc");
    }
    previousSelectedButton = "car_" + i + "_" + carTypeId;
    previousDiv = "divMainCar_" + i;

    statusCar = "Selected";
    $("#car_" + i + "_" + carTypeId).removeClass();
    $("#car_" + i + "_" + carTypeId).addClass("option-selection-selected");
    $("#divMainCar_" + i).css("border", "1px solid #5cb85c");
    $('#divPaymentSelection').hide();
    $('#divReviewAndConfirmationSelection').hide();
}
                else {
            selectedCarTypeCode = '';
        selectedPrice = '';
        statusCar = "NotSelected"
        $('#divPaymentSelection').hide();
        $('#divReviewAndConfirmationSelection').hide();
        $("#car_" + i + "_" + carTypeId).removeClass();
        $("#car_" + i + "_" + carTypeId).addClass("option-selection");
        $("#divMainCar_" + i).css("border", "1px solid #ccc");
    }
}
            else {
            statusCar == "Selected"
                $('#divPaymentSelection').hide();
        $('#divReviewAndConfirmationSelection').hide();
        $("#car_" + i + "_" + previousSelected).removeClass();
        $("#car_" + i + "_" + previousSelected).addClass("option-selection");
                if (previousSelectedButton != '') {
            $("#" + previousSelectedButton).removeClass();
        $("#" + previousSelectedButton).addClass("option-selection");
        $("#" + previousDiv).css("border", "1px solid #ccc");
    }
    previousSelectedButton = "car_" + i + "_" + carTypeId;
    previousDiv = "divMainCar_" + i;
    $("#car_" + i + "_" + carTypeId).removeClass();
    $("#car_" + i + "_" + carTypeId).addClass("option-selection-selected");
    $("#divMainCar_" + i).css("border", "1px solid #5cb85c");
}
previousSelected = carTypeId;
//getReviewDetail();
return false;
}

//get address and date from restinfo detail.
        function GetAddressandDate(restInfoDetail) {
            if (restInfoDetail != null) {
                var puLoc = restInfoDetail.PickupLocation;
        var doLoc = restInfoDetail.DropOffLocation;
        pickUpAddress = puLoc.FullAddress;
        dropOffAddress = doLoc.FullAddress;

        resTimewithHour = restInfoDetail.ResTime.split(' ');
        var date = new Date(restInfoDetail.ResTime);
        var time = getCurrentTime(date.getTime());
                if (resTimewithHour.length > 0) {
            resDateTime = resTimewithHour[0];
        resHour = time;
    }
}
}

//get curent time from json //where e= json value
        function getCurrentTime(e) {
            var time = new Date(parseInt(e));
        var day = time.getDate();
        var month = time.getMonth() + 1;
        var year = time.getFullYear();
        var minutes = time.getMinutes();
        var hours = time.getHours();
        var seconds = time.getSeconds();

        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12;

            if (seconds.toString().length == 1) {
            seconds = "0" + seconds;
        }
            if (minutes.toString().length == 1) {
            minutes = "0" + minutes;
        }
            if (hours.toString().length == 1) {
            hours = "0" + hours;
        }
            if (day.toString().length == 1) {
            day = "0" + day;
        }
            if (month.toString().length == 1) {
            month = "0" + month;
        }

        time = hours.toString() + ':' + minutes.toString() + ' ' + ampm;
        return time;
    }
        $("#paymentMethod").on("click", function () {
            $('.open-bodyPayment').removeClass('hidden');
        $('.Review').removeClass('hidden');
        $("#divReviewAndConfirmationSelection").show();
        $('#collapseTwo').removeClass("inSection");

        $('#collapseTwo').addClass('collapse');
        $('.Review').slideDown();

    });
        function CreditCardVerified() {

            $('.open-bodyPayment').removeClass('hidden');
        $('.Review').removeClass('hidden');
        $("#divReviewAndConfirmationSelection").show();
        $('#collapseTwo').removeClass("inSection");

        $('#collapseTwo').addClass('collapse');
        $('.Review').slideDown();
        $('.pickup-btns').addClass('active');
        isMap = true;
        initMap();

        return true;
    }
    var selectedCarType = "0";    //for getting riviewandconfirmation
    var selected_I;  //for getting riviewandconfirmation
    var selectedPrice;   //for getting riviewandconfirmation
    var selectedImgUrl; //for getting riviewandconfirmation
    var selectedPickAdd;    //for getting riviewandconfirmation
    var selectedDate;   //for getting riviewandconfirmation
    var selectedTime;   //for getting riviewandconfirmation
    var selectedDropAdd;    //for getting riviewandconfirmation
    var selectedDescription;    //for getting riviewandconfirmation
    var selectedETA;    //for getting riviewandconfirmation
    var statusCar = "Selected"   // for selected and unselected status


        function openPaymentModule(carTypeId, i, price) {
            debugger;
        $('#collapseOne').removeClass("inSection");
        $('#collapseTwo').addClass("inSection");
        getCarTypeCodeandPrice(carTypeId, i, price);

            if (selectedCarType != carTypeId || statusCar == "Selected") {
            selectedCarType = carTypeId;
        selected_I = i;
        selectedPrice = price;
        selectedPickAdd = pickUpAddress;
        selectedDate = resDateTime;
        selectedTime = resHour;
        selectedDropAdd = dropOffAddress;
        //selectedDescription = description;

                //for (var j = 0; j < vehicleList.length; j++) {
            //    if (vehicleList[j].CarTypeCode == carTypeId) {
            //        selectedImgUrl = vehicleList[j].ImageURL;
            //    }
            //}

            //for (var i = 0; i < carList.length; i++) {
            //    if (carList[i].CarTypeCode == carTypeId) {
            //        selectedETA = carList[i].ETA;
            //    }
            //}

            updateCarType(carTypeId);

        $('#collapseTwo').addClass("panel-collapse collapse");
        $('#collapseTwo').css("height", "");
        $('#collapseThree').addClass("panel-collapse collapse");
        $('#collapseOne').removeClass("panel-collapse collapse");
        $('#collapseOne').addClass("panel-collapse collapse");
        $('#divPaymentSelection').show();

        $('#collapseThree').css("height", "");
    }
}

        function HandleBackFunctionality() {
            if (window.event) //Internet Explorer
            {
            alert('Browser back button is clicked on Internet Explorer�');
        }
        else //Other browsers e.g. Chrome
            {
            alert('Browser back button is clicked on other browser�');
        }
    }

        function locationHashChanged() {
            alert("The anchor part has changed!");
        //editReviewDetail();
        }

        function openFareInfo(index) {
            if (FareInfoArray.length > 0) {
                for (var i = 0; i < FareInfoArray.length; i++) {
                    if (i == index) {
            bootbox.alert(FareInfoArray[index]);
        }
    }
}
return false;
}

var cardNum;            //get card num when select from dropdown

var previousSelected = '';
var selectedCarTypeCode = '';        //getting review page when click on vehicle next button
var previousSelectedButton = '';
var selectedPrice = '';
var previousDiv = '';

//get review section from click on next button in vehicle selection
        function getReviewDetail() {
            $('#dvLoading').show();
        var additionalInfo;
            if (selectedCarTypeCode != "") {
                debugger;
        $('#collapseThree').addClass("panel-collapse collapse");
        $('#collapseTwo').removeClass("panel-collapse collapse");
        $('#collapseTwo').addClass("panel-collapse collapse");
        $('#collapseThree').css("height", "auto");

        var string = '';
        var insideString = '';
        var date1 = new Date(restInfoDetail.ResTime);
        var dateTime = date1.toDateString();

        var phoneCntryCode;
        var altPhoneCntryCode;
        var specialRequest = '';    //get multiple special request in single variable
        var availableRequest = ["NOSUV", "PACKAGE", "CARSEAT-INFANT", "CARSEAT-TODDLER", "CARSEAT-BOOSTER", "GWT", "WHEELCHAIR", "PETS", "GUARANTEED RESERVATION"];
        var sr = restInfoDetail.SpecialRequest;
                if (sr.length > 0) {
                    var kk = sr.length;
                    for (var k = 0; k < sr.length; k++) {
                        for (var i = 0; i < availableRequest.length; i++) {
                            if (sr[k] == availableRequest[i]) {
                                if (specialRequest == '') {
                                    if ((k + 1) == kk)
                                        specialRequest = specialRequest + '<p>' + sr[k] + '</p>';
    else
                                        specialRequest = specialRequest + '<p>' + sr[k] + '</p>';
                                } else {
                                    if ((k + 1) == kk)
                                        specialRequest = specialRequest + '<p>' + sr[k] + '</p>';
    else
                                        specialRequest = specialRequest + '<p>' + sr[k] + '</p>';
}
}
}
}
}
                for (var i = 0; i < carList.length; i++) {
                    for (var j = 0; j < vehicleList.length; j++) {
                        if (selectedCarTypeCode == carList[i].CarTypeCode) {
                            if (selectedCarTypeCode == vehicleList[j].CarTypeCode) {

                                if (restInfoDetail.AdditionalNote == null || restInfoDetail.AdditionalNote == '') {
            additionalInfo = '';
        } else {
            additionalInfo = restInfoDetail.AdditionalNote;
        }
                                if (restInfoDetail.PhoneCountryCode == null || restInfoDetail.PhoneCountryCode == '') {
            restInfoDetail.PhoneCountryCode = '';
        phoneCntryCode = restInfoDetail.PhoneCountryCode;
                                } else {
            phoneCntryCode = restInfoDetail.PhoneCountryCode;
        if (phoneCntryCode.indexOf("+") != -1) {
            phoneCntryCode = phoneCntryCode.replace("+", "");
        //                                        phoneCntryCode = phoneCntryCode;
        } else {
            phoneCntryCode = phoneCntryCode.replace("+", "");
        //                                        phoneCntryCode = '+' + phoneCntryCode;
        }
    }
                                if (restInfoDetail.AltPhoneCountryCode == null || restInfoDetail.AltPhoneCountryCode == '') {
            restInfoDetail.AltPhoneCountryCode = '';
        altPhoneCntryCode = restInfoDetail.AltPhoneCountryCode;
                                } else {
            altPhoneCntryCode = restInfoDetail.AltPhoneCountryCode;
        if (altPhoneCntryCode.indexOf("+") != -1) {
            altPhoneCntryCode = altPhoneCntryCode.replace("+", "");
        //                                        phoneCntryCode = phoneCntryCode;
        } else {
            altPhoneCntryCode = altPhoneCntryCode.replace("+", "");
        //                                        phoneCntryCode = '+' + phoneCntryCode;
        }
    }
    carName = vehicleList[j].CarTypeName;

    var price = 0;
                                if (carList[i].Price == 'CALL') {
            price = "'" + carList[i].Price + "'";
        } else {
            price = carList[i].Price;
        price = price.replace(",", "");
    }

    var lname = "'LastName'";
    var fname = "'FirstName'";
    var pname = "'PhoneNumber'";
    var pConfCode = "'PhoneConfirmationCode'";
    var altpname = "'AltPhoneNumber'";
    var altpConfCode = "'AltPhoneConfirmationCode'";
    var note = "'Note'";
    var CntryCode = "'CountryCode'";
    var AltCntryCode = "'AltCountryCode'";
    var lblEmail = "'email'";
    var lblCCEmail = "'ccEmail'";

                                string = string + '<div class="row"><h4>Please take a moment to review your trip details before submitting.</h4> </div>';
                                string = string + '<div class="option-container" style="width: 95%;"><div class="row"><div class="col-md-5 success">';
                                string = string + '<img src=' + vehicleList[j].ImageURL + ' alt="elite premium sedan" class="img-responsive" /></div>';
                                string = string + '<div class="col-md-2"><div class="inner-address"><span class="label label-success">Pick-Up</span><br /><br />';
                                string = string + '<address>' + selectedPickAdd + '</address> <h5><strong>Date:</strong> ' + selectedDate + '</h5><h5><strong>Time:</strong>' + selectedTime + ' </h5></div></div>';
                                string = string + '<div class="col-md-2"><div class="inner-address"><span class="label label-info">Drop-Off</span><br /><br />';
                                string = string + '<address>' + selectedDropAdd + '</address></div> </div><div class="col-md-3 success"><div class="option-selection"><br />';
                                string = string + '<span>$</span><span> ' + price + '</span><h5 onclick="return openFareInfo(' + selected_I + ')"><b style="color: white; cursor: pointer;">FARE INFO';
                                string = string + '</b></h5><h4>ETA: ' + carList[i].ETA + '</h4></div></div></div></div><br />';



                                /*            insideString = insideString + '<div class="col-md-6"><div class="form-inline"><div> <label>PASSENGER:</label><br />';
                                            insideString = insideString + '<input id="txtFSTName" class="form-control" type="text" onblur="return updateCustomerNameAndNote(this.value,' + fname + ')" value="' + restInfoDetail.FirstName + '" />';
                                            insideString = insideString + '<input id="txtLSTName" class="form-control" type="text" value="' + restInfoDetail.LastName + '" onblur="return updateCustomerNameAndNote(this.value,' + lname + ')" />';
                                            insideString = insideString + '</div></div><br /></div>';
        //
                                            insideString = insideString + '<div class="col-md-7"><label>PHONE NUMBER:</label><br />';
                                            insideString = insideString + '<div class="input-group">';
                                            insideString = insideString + '<span class="input-group-addon" id="basic-addon1" style="background: #eee !important; border: 1px solid #ccc !important;">' + phoneCntryCode + '</span>';
                                            insideString = insideString + '<input type="text" class="form-control" placeholder="Phone Number" aria-describedby="basic-addon1" maxlength="20" value="' + restInfoDetail.PhoneNum + '" onkeypress="return isNumberKey(event)" onblur="return updateCustomerNameAndNote(this.value,' + pname + ')">';
                                            insideString = insideString + '</div><br />';

                                            insideString = insideString + '<label>EMAIL ADDRESS:</label><br />';
                                            insideString = insideString + '<input id="txtRevEmailAddress" class="form-control" placeholder="EMAIL ADDRESS" type="email" onblur="return updateCustomerNameAndNote(this.value,' + lblEmail + ')" value="' + customerInfo.EmailAddress + '" />';
                                            insideString = insideString + '<br />';
                                            insideString = insideString + '<label>CC EMAIL ADDRESS:</label><br />';
                                            insideString = insideString + '<input id="txtRevCCEmailAddress" class="form-control" type="email" value="" onblur="return updateCustomerNameAndNote(this.value,' + lblCCEmail + ')" />';
                                            insideString = insideString + '<br />';


                                            insideString = insideString + '<label>ADDITIONAL NOTE FOR DRIVER:</label>';
                                            insideString = insideString + '<textarea id="txtNote" class="form-control" name="message" rows="6" cols="50" placeholder="Enter any additional information that you would like the driver to know." style="resize: none;" value="' + additionalInfo + '" onblur="return updateCustomerNameAndNote(this.value,' + note + ')"></textarea>';
                                            insideString = insideString + '</div>';
                                            insideString = insideString + '<div class="col-md-5"><label>SPECIAL REQUESTS:</label>';
                                            insideString = insideString + '<br /> <span>' + specialRequest + '</span></div></div>';
        */
                                insideString = insideString + '<div class="col-md-12">';

                                insideString = insideString + '<div class="row"><div class="col-md-6"><h2>Passenger Info.</h2><br /><div class="form-inline"><label>PASSENGER:</label><br /> ';
                                insideString = insideString + ' <input id="txtFSTName" class="form-control" type="text" onblur="return updateCustomerNameAndNote(this.value,' + fname + ')" value="' + restInfoDetail.FirstName + '" />';
                                insideString = insideString + '<input id="txtLSTName" class="form-control" type="text" value="' + restInfoDetail.LastName + '" onblur="return updateCustomerNameAndNote(this.value,' + lname + ')" style="margin-left:10px;" />';
                                insideString = insideString + '</div></div></div><br />';

                                insideString = insideString + ' <!-- Phone Number Row --><div id="phoneRows"><div class="row" id="phoneNumberRow"><div class="col-md-6"><label>PHONE NUMBER:</label><br />';
                                insideString = insideString + '<span class="combo-input"> '
                                insideString = insideString + ' <select class="form-control" id="phonecountrycode" onchange="return updateCustomerNameAndNote(this.value,' + CntryCode + ')" style="background: #eee !important; border: 1px solid #eee !important;">' + phoneCntryCode + '</select>';

                    //BSA 12-19-2016
                                // insideString = insideString + ' <input id="txtPhoneNum" type="text" class="form-control" placeholder="Phone Number" aria-describedby="basic-addon1" maxlength="20" value="' + restInfoDetail.PhoneNum + '" onkeypress="return isNumberKey(event)" onblur="return updateCustomerNameAndNote(this.value,' + pname + ')" />'';
                                insideString = insideString + ' <select class="form-control" id="txtPhoneNum" onchange="return updateCustomerNameAndNote(this.value,' + pname + ')" />';

                                insideString = insideString + '</span>'
                                insideString = insideString + '</div><div class="col-md-4"><label>CONFIRMATION BY:</label><br /><select id="PhoneConfirmationCode" class="form-control" onChange=" setSelectedOption(' + pConfCode + ')"><option>None</option><option>Call Back</option><option>Send Text Message</option></select>';
                                insideString = insideString + '</div></div><br /><!-- Phone Number Row End -->';

                                insideString = insideString + ' <!-- Alternate Phone Number Row --><div class="row" id="altPhoneNumberRow"><div class="col-md-6"><label>ALTERNATE PHONE NUMBER:</label><br />';
                                insideString = insideString + '<span class="combo-input"> '
                                insideString = insideString + ' <select class="form-control" id="altphonecountrycode" onchange="return updateCustomerNameAndNote(this.value,' + AltCntryCode + ')" style="background: #eee !important; border: 1px solid #eee !important;">' + altPhoneCntryCode + '</select>';

                        //BSA 12-19-2016
                                //insideString = insideString + ' <input id="txtAltPhoneNum" type="text" class="form-control" placeholder="Phone Number" aria-describedby="basic-addon1" maxlength="20" value="' + restInfoDetail.AltPhoneNum + '" onkeypress="return isNumberKey(event)" onblur="return updateCustomerNameAndNote(this.value,' + altpname + ')" />';
                                insideString = insideString + ' <select class="form-control" id="txtAltPhoneNum" onchange="return updateCustomerNameAndNote(this.value,' + altpname + ')" />';

                                insideString = insideString + '</span>'
                                insideString = insideString + '</div><div class="col-md-4"><label>CONFIRMATION BY:</label><br /><select id="AltPhoneConfirmationCode" class="form-control" onChange="setSelectedOption(' + altpConfCode + ')"><option>None</option><option>Send Text Message</option></select>';
                                insideString = insideString + '</div></div><br /><!-- Alternate Phone Number Row End --></div>';

                                /*                                insideString = insideString + ' <!-- Alternate Phone Number Row --><div class="row"><div class="col-md-6"><label>ALTERNATE PHONE NUMBER:</label><br />';
                                                                insideString = insideString + '  <div class="input-group">';
                                                                //insideString = insideString + ' <span class="input-group-addon" id="basic-addon1" style="background: #eee !important; border: 1px solid #ccc !important;">' + phoneCountryCode + '</span>';
                                                                insideString = insideString + ' <input id="txtAltPhoneNum" type="text" class="form-control" placeholder="Phone Number" aria-describedby="basic-addon1" maxlength="20" value="' + restInfoDetail.AltPhoneNum + '" onkeypress="return isNumberKey(event)" onblur="return updateCustomerNameAndNote(this.value,' + altpname + ')" />';
                                                                insideString = insideString + '</div></div><div class="col-md-4"><label>CONFIRMATION BY:</label><br /><select id="AltPhoneConfirmationCode" class="form-control" onChange="setSelectedOption(' + altpConfCode + ')"><option>None</option><option>Send Text Message</option></select>';
                                                                insideString = insideString + '</div></div><br /><!-- Alternate Phone Number Row End -->';
            */
                                insideString = insideString + '<!-- Email Row --><div class="row" id="emailRows"><div class="col-md-6" id="emailRow"><label>EMAIL ADDRESS:</label><br />';

            //BSA 12-23-2016
                                //insideString = insideString + '<input id="txtRevEmailAddress" class="form-control" placeholder="EMAIL ADDRESS" type="email" onblur="return updateCustomerNameAndNote(this.value,' + lblEmail + ')" value="' + customerInfo.EmailAddress + '" /><br />';
                                insideString = insideString + ' <select class="form-control" id="txtRevEmailAddress" onchange="return updateCustomerNameAndNote(this.value,' + lblEmail + ')" />';

                                insideString = insideString + '</div><div class="col-md-6" id="altEmailRow"> <label>CC EMAIL ADDRESS:</label><br />';

                //BSA 12-23-2016
                                //insideString = insideString + '<input id="txtRevCCEmailAddress" class="form-control" placeholder="CC EMAIL ADDRESS" type="email" value="" onblur="return updateCustomerNameAndNote(this.value,' + lblCCEmail + ')" />';
                                insideString = insideString + ' <select class="form-control" id="txtRevCCEmailAddress" onchange="return updateCustomerNameAndNote(this.value,' + lblCCEmail + ')" />';

                                insideString = insideString + '</div></div><br /><!-- Email Row End -->';

                                insideString = insideString + '<!-- NOTES/SPECIAL REQUEST ROW --><div class="row"><div class="col-md-6"><label>ADDITIONAL NOTE FOR DRIVER:</label>';
                                insideString = insideString + '<textarea id="txtNote" class="form-control" name="message" rows="6" cols="50" placeholder="Enter any additional information that you would like the driver to know." style="resize: none;" value="' + additionalInfo + '" onblur="return updateCustomerNameAndNote(this.value,' + note + ')"></textarea>';
                                insideString = insideString + '</div><div class="col-md-6"><label>SPECIAL REQUESTS:</label><br /> <span>' + specialRequest + '</span>';
                                insideString = insideString + '</div></div><!-- NOTES/SPECIAL REQUEST ROW END--></div>';
        break;
    }
}
}
}
$('#divContainerReview').html(string);
$('#divPassangerInfo').html(insideString);
getConfirmation();
$("textarea#txtNote").val(additionalInfo);
$('#divReviewAndConfirmationSelection').show();

var testDdl = $('#phonecountrycode');
                for (var i = 0; i < countryJson.length; i++) {
            $("#phonecountrycode").append("<option value='" + countryJson[i].code + "'>" + countryJson[i].cityName + "</option>");
        }
                $("#phonecountrycode").prepend("<option value='" + 1 + "' selected>United States (+1)</option>");
        document.getElementById("phonecountrycode").value = phoneCntryCode;

                for (var i = 0; i < countryJson.length; i++) {
            $("#altphonecountrycode").append("<option value='" + countryJson[i].code + "'>" + countryJson[i].cityName + "</option>");
        }
                $("#altphonecountrycode").prepend("<option value='" + 1 + "' selected>United States (+1)</option>");
        document.getElementById("altphonecountrycode").value = altPhoneCntryCode;


        //BSA 12-23-2016
                for (var i = 0; i < phoneContacts.length; i++) {
            $("#txtPhoneNum").append("<option value='" + phoneContacts[i].PhoneNum + "'>" + phoneContacts[i].NickName + ": " + phoneContacts[i].PhoneNum + "</option>");
        }
                $("#txtPhoneNum").prepend("<option value='" + restInfoDetail.PhoneNum + "' selected>Primary Phone #: " + restInfoDetail.PhoneNum + "</option>");
                $("#txtPhoneNum").append("<option value='addPhone'>Add New Phone Number</option>");

                for (var i = 0; i < phoneContacts.length; i++) {
            $("#txtAltPhoneNum").append("<option value='" + phoneContacts[i].PhoneNum + "'>" + phoneContacts[i].NickName + ": " + phoneContacts[i].PhoneNum + "</option>");
        }
                $("#txtAltPhoneNum").prepend("<option value='' selected></option>");
                $("#txtAltPhoneNum").append("<option value='addPhone'>Add New Phone Number</option>");


                for (var i = 0; i < emailContacts.length; i++) {
            $("#txtRevEmailAddress").append("<option value='" + emailContacts[i].EmailAddress + "'>" + emailContacts[i].NickName + ": " + emailContacts[i].EmailAddress + "</option>");
        }
                $("#txtRevEmailAddress").prepend("<option value='" + customerInfo.EmailAddress + "' selected>Primary Email: " + customerInfo.EmailAddress + "</option>");
                $("#txtRevEmailAddress").append("<option value='addEmail'>Add New Email Address</option>");

                for (var i = 0; i < emailContacts.length; i++) {
            $("#txtRevCCEmailAddress").append("<option value='" + emailContacts[i].EmailAddress + "'>" + emailContacts[i].NickName + ": " + emailContacts[i].EmailAddress + "</option>");
        }
                $("#txtRevCCEmailAddress").prepend("<option value=' ' selected></option>");
                $("#txtRevCCEmailAddress").append("<option value='addEmail'>Add New Email Address</option>");

            } else {
        }
        $('#dvLoading').hide();
        return false;
    }

        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode != 46 && charCode > 31
                && (charCode < 48 || charCode > 57))
        return false;

    return true;
}

        function updateCarType(carTypeCode) {
            debugger;
        $('#dvLoading').show();

        $.ajax(
                {
            type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/EliteService.asmx/UpdateCarType",
                    data: "{carTypeCode: '" + carTypeCode + "'}",
        success: succeeded_previousCarType,
        error: failed_previousCarType
    });

return false;
}

        function succeeded_previousCarType(result) {
            $('#dvLoading').hide();
        //getConfirmation();
        }

        function failed_previousCarType(result) {

        }

        function setSelectedOption(selectId) {
            var sel = document.getElementById(selectId);
        var value = sel.options[sel.selectedIndex].value;
        updateCustomerNameAndNote(value, selectId);
    }

        function updateCustomerNameAndNote(value, type) {
            //BSA 12-23-2016
            if (value != "addPhone") {
            saveAddPhoneSelectedIndex = $("txtPhoneNum").prop('selectedIndex');
        saveAddAltPhoneSelectedIndex = $("#txtAltPhoneNum").prop('selectedIndex');
    }
            if (value != "addEmail") {
            saveEmailSelectedIndex = $("#txtRevEmailAddress").prop('selectedIndex');
        saveCCEmailSelectedIndex = $("#txtRevCCEmailAddress").prop('selectedIndex');

    }
            if (value == "addPhone" || value == "addEmail") {
            editField(value);
        return false;
    }

            if ($("#txtFSTName").val() == "") {
            $('#txtFSTName').css("border", "1px solid red");
        return false;
            } else {
            $('#txtFSTName').css("border", "");
        }

            if ($("#txtLSTName").val() == "") {
            $('#txtLSTName').css("border", "1px solid red");
        return false;
            } else {
            $('#txtLSTName').css("border", "");

        }

            if ($("#txtPhNumber").val() == "") {
            $('#txtPhNumber').css("border", "1px solid red");
        return false;
            } else {
            $('#txtPhNumber').css("border", "");
        }

        $('#dvLoading').show();

        $.ajax(
                {
            type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/EliteService.asmx/UpdateCustomerNameAndNote",
                    data: "{value: '" + value + "',type:'" + type + "'}",
        success: succeeded_previousNameNote,
        error: failed_previousNameNote
    });

return false;
}

        function succeeded_previousNameNote(result) {
            var myJsonString = JSON.parse(result.d);
            if (myJsonString != null) {
            $("#txtFSTName").val(myJsonString.FirstName);
        $("#txtLSTName").val(myJsonString.LastName);
        $("#txtNote").text(myJsonString.AdditionalNote);

        //BSA 12-19-2016
        //$("#txtPhNumber").text(myJsonString.PhoneNum);
        //$("#txtAltPhNumber").text(myJsonString.AltPhoneNum);
        //$("#txtRevEmailAddress").text(myJsonString.EmailAddress);
        //$("#txtRevCCEmailAddress").text(myJsonString.CCEmailAddress);
    }
    $('#dvLoading').hide();
}

        function failed_previousNameNote(result) {

        }

        //BSA 12-23-2016
        function editField(value) {
            var pname = "'PhoneNumber'";
        var altpname = "'AltPhoneNumber'";
        var lblEmail = "'email'";
        var lblCCEmail = "'ccEmail'";
            switch (value) {
                case "addPhone":
            var innerDivPhoneEmail = '';
            var row = document.getElementById('newPhone');
                    if (row == null) {
            document.getElementById('phoneNumberRow').style.display = 'none';
        document.getElementById('altPhoneNumberRow').style.display = 'none';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<div class="col-md-12" id="newPhoneTable" style="padding:0"><label>ADD NEW PHONE NUMBER</label><table class="table upcoming-table table-striped" style="border: 1px solid #ccc;"><thead style="background-color: #252525; color: white;">';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<th>NickName</th><th>Country Code</th><th>Phone Number</th><th>Mobile Phone</th><th>Send Texts</th><th><button class="btn btn-danger btn-block" type="button" id="btnCancelPhone" style="padding:0" onclick="return cancelAddPhone();">Cancel</button></th></thead><tbody id="tbdyPhone">';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<tr style="border-top: none;" id="newPhone">'
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><input type="text" class="form-control" ID="txtAddPhoneNickname" onkeypress="return disableEnter(event);" /></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><select class="form-control" id="addphonecountrycode"></select></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><input type="text" class="form-control" ID="txtAddPhoneNum" onkeypress="return disableEnter(event);" onfocus="javascript:setPhoneMask();" /></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><select class="form-control" ID="txtAddMobilePhone"><option value="Y">Y</option><option value="N" selected>N</option></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><select class="form-control" ID="txtAddSendText"><option value="Y">Y</option><option value="N" selected>N</option></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><button type="button" class="btn btn-primary btn-block" onclick="addPhone()" style="padding:0">Save</button></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '</tr></tbody></table></div>';
            $("#phoneRows").append(innerDivPhoneEmail);

                        for (var i = 0; i < countryJson.length; i++) {
                $("#addphonecountrycode").append("<option value='" + countryJson[i].code + "'>" + countryJson[i].cityName + "</option>");
            }
                        $("#addphonecountrycode").prepend("<option value='" + 1 + "' selected>United States (+1)</option>");

        }
        break;
    case "addEmail":
        var innerDivPhoneEmail = '';
        var row = document.getElementById('newEmail');
                    if (row == null) {
                document.getElementById('emailRow').style.display = 'none';
            document.getElementById('altEmailRow').style.display = 'none';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<div class="col-md-12" id="newEmailTable"><label>ADD NEW EMAIL ADDRESS</label><table class="table upcoming-table table-striped" style="border: 1px solid #ccc;"><thead style="background-color: #252525; color: white;">';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<th>NickName</th><th>Email Address</th><th><button class="btn btn-danger btn-block" type="button" id="btnCancelEmail" onclick="return cancelAddEmail();">Cancel</button></th></thead><tbody id="tbdyEmail">';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<tr style="border-top: none;" id="newEmail">'
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><input type="text" class="form-control" ID="txtAddEmailNickname" onkeypress="return disableEnter(event);" /></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><input type="text" class="form-control" ID="txtAddEmail" onkeypress="return disableEnter(event);" /></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '<td><button type="button" class="btn btn-primary btn-block" onclick="addEmail()">Save</button></td>';
                        innerDivPhoneEmail = innerDivPhoneEmail + '</tr></tbody></table></div>';
            $("#emailRows").append(innerDivPhoneEmail);
        }
        break;
}
}

//BSA 12-23-2016
        function cancelAddPhone() {
            if ($("#txtPhoneNum").val() == "addPhone") {
                document.getElementById("txtPhoneNum").selectedIndex = saveAddPhoneSelectedIndex;
            //              document.getElementById("txtPhoneNum").selectedIndex = 1;
            }

            if ($("#txtAltPhoneNum").val() == "addPhone") {
                document.getElementById("txtAltPhoneNum").selectedIndex = saveAddAltPhoneSelectedIndex;
            }

            document.getElementById('phoneNumberRow').style.display = 'block';
            document.getElementById('altPhoneNumberRow').style.display = 'block';
            var elem = document.getElementById('newPhoneTable');
            elem.parentNode.removeChild(elem);
        }

        //BSA 12-23-2016
        function cancelAddEmail() {

            if ($("#txtRevEmailAddress").val() == "addEmail") {
                //                document.getElementById("txtRevEmailAddress").selectedIndex = "0";
                document.getElementById("txtRevEmailAddress").selectedIndex = saveEmailSelectedIndex;
            }

            if ($("#txtRevCCEmailAddress").val() == "addEmail") {
                document.getElementById("txtRevCCEmailAddress").selectedIndex = saveCCEmailSelectedIndex;
            //                document.getElementById("txtRevCCEmailAddress").selectedIndex = "0";
            }

            document.getElementById('emailRow').style.display = 'block';
            document.getElementById('altEmailRow').style.display = 'block';
            var elem = document.getElementById('newEmailTable');
            elem.parentNode.removeChild(elem);
        }
        //BSA 12-23-2016
        function addPhone() {
            var isRequiredCount = 0;
            if ($('#txtAddPhoneNickname').val() == "") {
                isRequiredCount++;
            $('#txtAddPhoneNickname').css("border", "1px solid red");
            } else {
                var NickName = $('#txtAddPhoneNickname').val();
        }

        var cntryCode = document.getElementById('addphonecountrycode').value;
            if (cntryCode == '0' || cntryCode == "") {
                isRequiredCount++;
            document.getElementById('addphonecountrycode').style.border = "1px Solid Red";
            } else {
                document.getElementById('addphonecountrycode').style.border = "";
            var CountryCode = "+" + cntryCode;
        }

            if ($('#txtAddPhoneNum').val() == "") {
                isRequiredCount++;
            $('#txtAddPhoneNum').css("border", "1px solid red");
            } else {
                $("#txtAddPhoneNum").mask("(999) 999-9999");
            var PhoneNum = $('#txtAddPhoneNum').val();
        }

        var MobilePhone = $('#txtAddMobilePhone').val();
        var SendText = $('#txtAddSendText').val();

            if (isRequiredCount > 0) {
                return false;
            } else {
                $('#dvLoading').show();
            $.ajax(
                    {
                type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/EliteService.asmx/AddPhoneNum",
                        data: "{phoneNum: '" + PhoneNum + "',nickname:'" + NickName + "',mobilePhone:'" + MobilePhone + "',countryCode:'" + CountryCode + "',sendText:'" + SendText + "'}",
            success: succeeded_previous_phone,
            error: failed_previous_phone
        });
}
}

//BSA 12-23-2016
        function succeeded_previous_phone(result) {
            var myJsonString = JSON.parse(result.d);
            var returnStatus = myJsonString.ReturnStatus;
            if (returnStatus.Code == "1") {
                /*var num = {
                    NickName: $('#txtAddPhoneNickname').val(),
                    CountryCode: "+" + document.getElementById('addphonecountrycode').value,
                    PhoneNum: $('#txtAddPhoneNum').val(),
                    MobilePhone: $('#txtAddMobilePhone').val(),
                    SendText: $('#txtAddSendText').val()
                }*/
                phoneContacts = myJsonString.PhoneContacts;


            if ($("#txtPhoneNum").val() == "addPhone") {
                    var x = document.getElementById("txtPhoneNum");
            var option = document.createElement("option");
            option.text = $('#txtAddPhoneNickname').val() + ": " + $('#txtAddPhoneNum').val();
            option.value = $('#txtAddPhoneNum').val();
            option.selected = true;
            x.add(option, x[$('#txtPhoneNum  option').size() - 1]);
            $('#phonecountrycode').val($('#addphonecountrycode').val())
            updateCustomerNameAndNote($('#txtAddPhoneNum').val(), 'PhoneNumber');
            updateCustomerNameAndNote($('#addphonecountrycode').val(), 'CountryCode');

            var x = document.getElementById("txtAltPhoneNum");
            var option = document.createElement("option");
            option.text = $('#txtAddPhoneNickname').val() + ": " + $('#txtAddPhoneNum').val();
            option.value = $('#txtAddPhoneNum').val();
            option.selected = false;
            x.add(option, x[$('#txtAltPhoneNum  option').size() - 1]);
                    //$("#txtPhoneNum").add("<option value='" + $('#txtAddPhoneNum').val() + "' selected>" + $('#txtAddPhoneNickname').val() + ": " + $('#txtAddPhoneNum').val() + "</option>",5);
                    //                    $("#txtPhoneNum").prepend("<option value='" + $('#txtAddPhoneNum').val() + "' selected>" + $('#txtAddPhoneNickname').val() + ": " + $('#txtAddPhoneNum').val() + "</option>");
    }

                if ($("#txtAltPhoneNum").val() == "addPhone") {
                    var x = document.getElementById("txtAltPhoneNum");
        var option = document.createElement("option");
        option.text = $('#txtAddPhoneNickname').val() + ": " + $('#txtAddPhoneNum').val();
        option.value = $('#txtAddPhoneNum').val();
        option.selected = true;
        x.add(option, x[$('#txtAltPhoneNum  option').size() - 1]);
        $('#altphonecountrycode').val($('#addphonecountrycode').val())
        updateCustomerNameAndNote($('#txtAddPhoneNum').val(), 'AltPhoneNumber');
        updateCustomerNameAndNote($('#addphonecountrycode').val(), 'AltCountryCode');

        var x = document.getElementById("txtPhoneNum");
        var option = document.createElement("option");
        option.text = $('#txtAddPhoneNickname').val() + ": " + $('#txtAddPhoneNum').val();
        option.value = $('#txtAddPhoneNum').val();
        option.selected = false;
        x.add(option, x[$('#txtPhoneNum  option').size() - 1]);
                    //                    $("#txtAltPhoneNum").prepend("<option value='" + $('#txtAddPhoneNickname').val() + "' selected>" + $('#txtAddPhoneNickname').val() + ": " + $('#txtAddPhoneNum').val() + "</option>");
}

document.getElementById('phoneNumberRow').style.display = 'block';
document.getElementById('altPhoneNumberRow').style.display = 'block';
var elem = document.getElementById('newPhoneTable');
elem.parentNode.removeChild(elem);
$('#dvLoading').hide();
}
            else {
        bootbox.alert("<h4>" + returnStatus.Message + "</h4>");
    $('#dvLoading').hide();
}
return false;
}

//BSA 12-23-2016
        function failed_previous_phone() {

    }

    //BSA 12-23-2016
    function addEmail() {
            var isRequiredCount = 0;
            if ($('#txtAddEmailNickname').val() == "") {
        isRequiredCount++;
    $('#txtAddEmailNickname').css("border", "1px solid red");
            } else {
                var NickName = $('#txtAddEmailNickname').val();
}
            if ($('#txtAddEmail').val() == "") {
        isRequiredCount++;
    $('#txtAddEmail').css("border", "1px solid red");
            } else {
                var Email = $('#txtAddEmail').val();
}
            if (isRequiredCount > 0) {
                return false;
            } else {
                var passValues = '[]';
    $('#dvLoading').show();
    $.ajax(
                    {
        type: "POST",
    contentType: "application/json; charset=utf-8",
    url: "/EliteService.asmx/AddEmail",
                        data: "{nickName: '" + NickName + "',email:'" + Email + "'}",
    success: succeeded_previous_email,
    error: failed_previous_email
});
}
}

//BSA 12-23-2016
        function succeeded_previous_email(result) {
            var myJsonString = JSON.parse(result.d);
    var returnStatus = myJsonString.ReturnStatus;
            if (returnStatus.Code == "1") {
        /*var num = {
            NickName: $('#txtEmailNickname').val(),
            EmailAddress: $('#txtEmail').val()
        }*/
        emailContacts = myJsonString.EmailContacts;

    if ($("#txtRevEmailAddress").val() == "addEmail") {
                    var x = document.getElementById("txtRevEmailAddress");
    var option = document.createElement("option");
    option.text = $('#txtAddEmailNickname').val() + ": " + $('#txtAddEmail').val();
    option.value = $('#txtAddEmail').val();
    option.selected = true;
    x.add(option, x[$('#txtRevEmailAddress  option').size() - 1]);
    updateCustomerNameAndNote($('#txtAddEmail').val(), 'email');
    var x = document.getElementById("txtRevCCEmailAddress");
    var option = document.createElement("option");
    option.text = $('#txtAddEmailNickname').val() + ": " + $('#txtAddEmail').val();
    option.value = $('#txtAddEmail').val();
    option.selected = false;
    x.add(option, x[$('#txtRevCCEmailAddress  option').size() - 1]);
                    //$("#txtRevEmailAddress").prepend("<option value='" + $('#txtAddEmail').val() + "' selected>" + $('#txtAddEmailNickname').val() + ": " + $('#txtAddEmail').val() + "</option>");
                }

if ($("#txtRevCCEmailAddress").val() == "addEmail") {
    var x = document.getElementById("txtRevCCEmailAddress");
    var option = document.createElement("option");
    option.text = $('#txtAddEmailNickname').val() + ": " + $('#txtAddEmail').val();
    option.value = $('#txtAddEmail').val();
    option.selected = true;
    x.add(option, x[$('#txtRevCCEmailAddress  option').size() - 1]);
    updateCustomerNameAndNote($('#txtAddEmail').val(), 'ccEmail');

    var x = document.getElementById("txtRevEmailAddress");
    var option = document.createElement("option");
    option.text = $('#txtAddEmailNickname').val() + ": " + $('#txtAddEmail').val();
    option.value = $('#txtAddEmail').val();
    option.selected = false;
    x.add(option, x[$('#txtRevEmailAddress  option').size() - 1]);
    //                    $("#txtRevCCEmailAddress").prepend("<option value='" + $('#txtAddEmail').val() + "' selected>" + $('#txtAddEmailNickname').val() + ": " + $('#txtAddEmail').val() + "</option>");
}

document.getElementById('emailRow').style.display = 'block';
document.getElementById('altEmailRow').style.display = 'block';
var elem = document.getElementById('newEmailTable');
elem.parentNode.removeChild(elem);
$('#dvLoading').hide();
            }
            else {
    bootbox.alert("<h4>" + returnStatus.Message + "</h4>");
    $('#dvLoading').hide();
}
return false;
        }

//BSA 12-23-2016
function failed_previous_email() {

}

//get confirmation from click on next button in review section
var totalAllPrice = '';      //for change total price value when change on tip
function getConfirmation() {
    //for tip

    var ddlArray = new Array();
    var ddl = document.getElementById('tipDrpdwnValue');
    for (x = 0; x < ddl.options.length; x++) {
        ddlArray[x] = ddl.options[x].value;
    }

    var isAlreadyExists = false;
    for (y = 0; y < ddlArray.length; y++) {

        if (customerInfo.DefaultTipPct.toString() == ddlArray[y]) {
            isAlreadyExists = true;
            break;
        }
    }

    if (isAlreadyExists == false) {
        $("#tipDrpdwnValue").append($("<option></option>").val(customerInfo.DefaultTipPct).html(customerInfo.DefaultTipPct + '%'));
    }


    $('#dvLoading').show();
    if (selectedCarTypeCode != "") {
        var checkisPersonal = customerInfo.CCList;
        if (checkisPersonal.length != 0) {

            for (var i = 0; i < checkisPersonal.length; i++) {
                if (cardNum == checkisPersonal[i].CardNum) {
                    if (checkisPersonal[i].isPersonal == 'Y') {
                        for (var j = 0; j < carList.length; j++) {

                            if (selectedCarTypeCode == carList[j].CarTypeCode) {
                                var totalPrice = parseFloat(selectedPrice);
                                if (isNaN(totalPrice)) {
                                    totalPrice = 0;
                                }
                                totalAllPrice = totalPrice;

                                $("#baseFareValue").text('$' + totalPrice.toFixed(2));
                                $("#baseFareValue").append('<img src="Images/info-icon.png" width="20" height="20" onclick="return openFareInfo(' + j + ')">');

                                //check istipAllow or not from carlist for personal
                                if (carList[j].TipAllowed == 'Y') {
                                    $('#visibleTip').show();
                                    $("#tipDrpdwnValue").val(customerInfo.DefaultTipPct);

                                    if (!isNaN(selectedPrice)) {
                                        var price = parseFloat(selectedPrice);
                                        var tp1 = parseFloat(customerInfo.DefaultTipPct / 100);
                                        var tp2 = parseFloat(tp1 * price);
                                        totalPrice = parseFloat(tp2 + price);
                                    }

                                } else {
                                    $('#visibleTip').hide();
                                }

                                $("#lblAccoutValue").text(customerInfo.AccountNum);

                                //check ispromocode allow or not for personal
                                if (carList[j].PromoAllowed == 'Y') {
                                    $('#visiblePromoode').show();
                                } else {
                                    $('#visiblePromoode').hide();
                                }

                                if (totalPrice == parseFloat(selectedPrice)) {
                                    $("#totalPayableCharge").text('$' + selectedPrice.toFixed(2));
                                    totalPayCharge = selectedPrice;
                                } else {
                                    $("#totalPayableCharge").text('$' + totalPrice.toFixed(2));
                                    totalPayCharge = totalPrice.toFixed(2);
                                }
                                $('#dvLoading').hide();
                                break;
                                return false;
                            }

                        }

                    } else {

                        for (var m = 0; m < carList.length; m++) {
                            if (selectedCarTypeCode == carList[m].CarTypeCode) {
                                var totalPrice1 = parseFloat(selectedPrice);
                                if (isNaN(totalPrice1)) {
                                    totalPrice1 = 0;
                                }
                                totalAllPrice = totalPrice1;
                                $("#baseFareValue").text('$' + totalPrice1.toFixed(2));
                                $("#baseFareValue").append('<img src="Images/info-icon.png" width="20" height="20" onclick="return openFareInfo(' + m + ')">');
                                //check istipAllow or not from carlist for personal
                                if (carList[m].TipAllowed == 'Y') {
                                    $('#visibleTip').show();
                                    $("#tipDrpdwnValue").val(customerInfo.DefaultTipPct);

                                    if (!isNaN(carList[m].Price)) {
                                        var price1 = parseFloat(carList[m].Price);
                                        var tp3 = parseFloat(customerInfo.DefaultTipPct / 100);
                                        var tp4 = parseFloat(tp3 * price1);
                                        totalPrice1 = parseFloat(tp4 + price1);
                                    }
                                } else {
                                    $('#visibleTip').hide();
                                }

                                $("#lblAccoutValue").text(checkisPersonal[i].CardNum);
                                $("#lblAccoutValue").text().replace(/\d{12}(\d{4})/, "xxxx xxxx xxxx $1");
                                //check ispromocode allow or not for personal
                                if (carList[m].PromoAllowed == 'Y') {
                                    $('#visiblePromoode').show();
                                } else {
                                    $('#visiblePromoode').hide();
                                }

                                if (totalPrice == parseFloat(carList[m].Price)) {
                                    $("#totalPayableCharge").text('$' + carList[m].Price);
                                    totalPayCharge = carList[m].Price;
                                } else {
                                    $("#totalPayableCharge").text('$' + totalPrice1.toFixed(2));
                                    totalPayCharge = totalPrice1.toFixed(2);
                                }
                                $('#dvLoading').hide();
                                break;
                                return false;
                            }

                        }
                    }
                }
                else {
                    for (var j = 0; j < carList.length; j++) {

                        if (selectedCarTypeCode == carList[j].CarTypeCode) {
                            var totalPrice = parseFloat(selectedPrice);
                            if (isNaN(totalPrice)) {
                                totalPrice = 0;
                            }
                            totalAllPrice = totalPrice;
                            $("#baseFareValue").text('$' + totalPrice.toFixed(2));
                            $("#baseFareValue").append('<img src="Images/info-icon.png" width="20" height="20" onclick="return openFareInfo(' + j + ')">');
                            //check istipAllow or not from carlist for personal
                            if (carList[j].TipAllowed == 'Y') {
                                $('#visibleTip').show();
                                $("#tipDrpdwnValue").val(customerInfo.DefaultTipPct);

                                if (!isNaN(selectedPrice)) {
                                    var price = parseFloat(selectedPrice);
                                    var tp1 = parseFloat(customerInfo.DefaultTipPct / 100);
                                    var tp2 = parseFloat(tp1 * price);
                                    totalPrice = parseFloat(tp2 + price);
                                }

                            } else {
                                $('#visibleTip').hide();
                            }

                            $("#lblAccoutValue").text(customerInfo.AccountNum);

                            //check ispromocode allow or not for personal
                            if (carList[j].PromoAllowed == 'Y') {
                                $('#visiblePromoode').show();
                            } else {
                                $('#visiblePromoode').hide();
                            }

                            if (totalPrice == parseFloat(selectedPrice)) {
                                $("#totalPayableCharge").text('$' + selectedPrice.toFixed(2));
                                totalPayCharge = selectedPrice;
                            } else {
                                $("#totalPayableCharge").text('$' + totalPrice.toFixed(2));
                                totalPayCharge = totalPrice.toFixed(2);
                            }
                            $('#dvLoading').hide();
                            break;
                            return false;
                        }

                    }


                }

            }
        }
        else {
            for (var n = 0; n < carList.length; n++) {
                if (selectedCarTypeCode == carList[n].CarTypeCode) {
                    var totalPrice = parseFloat(selectedPrice);

                    if (isNaN(totalPrice)) {
                        totalPrice = 0;
                    }
                    totalAllPrice = totalPrice;
                    $("#baseFareValue").text('$' + totalPrice.toFixed(2));
                    $("#baseFareValue").append('<img src="Images/info-icon.png" width="20" height="20" onclick="return openFareInfo(' + n + ')">');
                    //check istipAllow or not from carlist for personal
                    if (carList[n].TipAllowed == 'Y') {
                        $('#visibleTip').show();
                        $("#tipDrpdwnValue").val(customerInfo.DefaultTipPct);

                        if (!isNaN(carList[n].Price)) {
                            var price = parseFloat(carList[n].Price);
                            var tp1 = parseFloat(customerInfo.DefaultTipPct / 100);
                            var tp2 = parseFloat(tp1 * price);
                            totalPrice = parseFloat(tp2 + price);
                        }

                    } else {
                        $('#visibleTip').hide();
                    }

                    $("#lblAccoutValue").text(customerInfo.AccountNum);

                    //check ispromocode allow or not for personal
                    if (carList[n].PromoAllowed == 'Y') {
                        $('#visiblePromoode').show();
                    } else {
                        $('#visiblePromoode').hide();
                    }

                    if (totalPrice == parseFloat(carList[n].Price)) {
                        $("#totalPayableCharge").text('$' + carList[n].Price);
                        totalPayCharge = carList[n].Price;
                    } else {
                        $("#totalPayableCharge").text('$' + totalPrice.toFixed(2));
                        totalPayCharge = totalPrice.toFixed(2);
                    }
                    $('#dvLoading').hide();
                    break;
                    return false;
                }
            }
            $('#dvLoading').hide();
            return false;
        }
    }
}

//fill textbox on corporate credit card dropdown value
var corflagSaveFuture = false;
function GetCorTextBoxValue() {
    var cardId = document.getElementById('ContentPlaceHolder1_drpdwnCorporateCC').value;
    selectedCC = cardId;
    if (cardId == "0") {
        corflagSaveFuture = false;
        $("#hideCorCreditCard").css("display", "none");
        $("[id$=txtCorCreditCard]").val("");
        $("[id$=txtCorPassword]").val("");
        $("#drcorpexpireMM").val(0);
        $("#drcorpexpireYY").val(0);
        $("#txtCorPostalCode").val('');
    }
    if (cardId == "-1") {
        corflagSaveFuture = true;
        $("#hideCorCreditCard").css("display", "block");
        $("[id$=txtCorCreditCard]").val("");
        $("[id$=txtCorPassword]").val("");
        $("#drcorpexpireMM").val(0);
        $("#drcorpexpireYY").val(0);
        $("#txtCorPostalCode").val('');
        $('#ContentPlaceHolder1_drpdwnCorporateCC').css("border", "");
    }
    if (cardId != "0" && cardId != "-1") {
        $("#hideCorCreditCard").css("display", "none");
        corflagSaveFuture = false;
        for (var i = 0; i < customerCCInfo1.length; i++) {
            if (cardId == customerCCInfo1[i].ID) {
                var dateString = customerCCInfo1[i].ExpirationDate;
                var currentTime = new Date(parseInt(dateString.substr(6)));
                var month = currentTime.getMonth() + 1;
                var year = currentTime.getFullYear().toString();

                $("[id$=txtCorCreditCard]").val(customerCCInfo1[i].CardNum);
                cardNum = customerCCInfo1[i].CardNum;
                $("[id$=txtCorPassword]").val(customerCCInfo1[i].SecurityCode);
                $("#drcorpexpireMM").val(month);
                $("#drcorpexpireYY").val(year);
                $("#txtCorPostalCode").val(customerCCInfo1[i].PostalCode);

                $("[id$=txtCorCreditCard]").css("border", "1px solid #ccc");
                $("[id$=txtCorPassword]").css("border", "1px solid #ccc");
                $("#drcorpexpireMM").css("border", "1px solid #ccc");
                $("#drcorpexpireYY").css("border", "1px solid #ccc");
                $("#txtCorPostalCode").css("border", "1px solid #ccc");
            }
        }
    }
}

//fill textbox on personal credit card dropdown value
var flagSaveFuture = false;
function GetPerTextBoxValue() {
    var cardId = document.getElementById('ContentPlaceHolder1_drpdwnPersonalCC').value;
    selectedCC = cardId;
    if (cardId == "0") {
        flagSaveFuture = false;
        $("#hidePerCreditCard").css("display", "none");
        $("[id$=txtPersInputCardNumber]").val("");
        $("[id$=txtPersInputSecurityCode]").val("");
        $("#drpexpireMM").val(0);
        $("#drpexpireYY").val(0);
        $("#txtPostalCode").val('');

    }
    if (cardId == "-1") {
        flagSaveFuture = true;
        $("#hidePerCreditCard").css("display", "block");
        $("[id$=txtPersInputCardNumber]").val("");
        $("[id$=txtPersInputSecurityCode]").val("");
        $("#drpexpireMM").val(0);
        $("#drpexpireYY").val(0);
        $("#txtPostalCode").val('');
        $('#ContentPlaceHolder1_drpdwnPersonalCC').css("border", "");
    }
    if (cardId != "0" && cardId != "-1") {
        $("#hidePerCreditCard").css("display", "none");
        flagSaveFuture = false;
        for (var i = 0; i < customerCCInfo1.length; i++) {
            if (cardId == customerCCInfo1[i].ID) {
                var dateString = customerCCInfo1[i].ExpirationDate;
                var currentTime = new Date(parseInt(dateString.substr(6)));
                var month = currentTime.getMonth() + 1;
                var year = currentTime.getFullYear();

                $("[id$=txtPersInputCardNumber]").val(customerCCInfo1[i].CardNum);
                cardNum = customerCCInfo1[i].CardNum;
                $("[id$=txtPersInputSecurityCode]").val(customerCCInfo1[i].SecurityCode);

                $("#drpexpireMM").val(month);
                $("#drpexpireYY").val(year);
                $("#txtPostalCode").val(customerCCInfo1[i].PostalCode);

                $("[id$=txtPersInputCardNumber]").css("border", "1px solid #ccc");
                $("[id$=txtPersInputSecurityCode]").css("border", "1px solid #ccc");
                $("#drpexpireMM").css("border", "1px solid #ccc");
                $("#drpexpireYY").css("border", "1px solid #ccc");
                $("#txtPostalCode").css("border", "1px solid #ccc");
            }

        }
    }
}

var selectedRadioButton;        //after pageload payment radio button is selected
var selectedCC;
var requireValidation = [];     //validate dynamic account number field.
function SelectSingleRadiobutton(rdbtnid) {
    var ridereason;
    if (rdbtnid == "inlineRadio1Personal") {
        selectedRadioButton = "inlineRadio1Personal";
        $('#inlineRadio2Corporate').prop('checked', false);
        //                $('#inlineRadio2Corporate').attr('checked', false);
        $("#divWhatCorporateAccount").hide();
        $("#liPersonal").addClass("active");
        $("#liPersonal").show();
        $("#home").addClass("tab-pane active");
        $("#home").show();
        $("#liCorporateAccount").removeClass("active");
        $("#liCorporateAccount").hide();
        $("#profile").removeClass("tab-pane active");
        $("#profile").hide();
        $("#liCorporateComponyCredit").removeClass("active");
        $("#liCorporateComponyCredit").hide();
        $("#profile2").removeClass("tab-pane active");
        $("#profile2").hide();
        $("#liCorporate").removeClass("active");
        $("#liCorporate").hide();
    }
    if (rdbtnid == "inlineRadio2Corporate") {
        $('#inlineRadio1Personal').prop('checked', false);
        $('#Radio2CorporateAccount').prop('checked', false);
        $('#Radio2CorporateCredit').prop('checked', false);
        //                $('#inlineRadio1Personal').attr('checked', false);
        //                $('#Radio2CorporateAccount').attr('checked', false);
        //                $('#Radio2CorporateCredit').attr('checked', false);
        $("#divWhatCorporateAccount").hide();
        $("#liPersonal").removeClass("active");
        $("#liPersonal").hide();
        $("#home").removeClass("tab-pane active");
        $("#home").hide();
        $("#liCorporate").removeClass("active");
        $("#liCorporate").hide();
        $("#liCorporateAccount").removeClass("active");
        $("#liCorporateAccount").hide();
        $("#profile").removeClass("tab-pane active");
        $("#profile").hide();
        $("#liCorporateComponyCredit").removeClass("active");
        $("#liCorporateComponyCredit").hide();
        $("#profile2").removeClass("tab-pane active");
        $("#profile2").hide();
        selectedRadioButton = "inlineRadio2Corporate";
        localStorage.setItem("AccNum", customInfoAccountNum);
        /*                if (paymentType == "1") {
                            localStorage.setItem("PMType", paymentType);
                            if (accountRequest == "" || accountRequest == undefined) {
                                $('#dvLoading').show();
                                getReviewDetail();
                            }
                            else {
                                $("#divAccountNumber").html('');
                                $("#divWhatCorporateAccount").show();
                                $("#liPersonal").removeClass("active");
                                $("#liPersonal").hide();
                                $("#home").removeClass("tab-pane active");
                                $("#home").hide();
                                $("#liCorporate").removeClass("active");
                                $("#liCorporate").hide();
                                $("#liCorporateAccount").addClass("active");
                                $("#liCorporateAccount").show();
                                $("#profile").addClass("tab-pane active");
                                $("#profile").show();
                                $("#divWhatCorporateAccount").hide();
                                $("#liCorporateComponyCredit").removeClass("active");
                                $("#liCorporateComponyCredit").hide();
                                $("#profile2").removeClass("tab-pane active");
                                $("#profile2").hide();
                                $("#lblCorCCDetail").hide();

                                //generate dynamic corporate account number table.
                                //Vcode value 1,2,3,4 is for textbox and value 5 is for dropdowm.
                                //validation is only vcode value 2,3,4,5.
                                var innerDiv = '';
                                innerDiv += '<div class="form-group"><label for="">Account Number</label><input type="text" class="form-control" id="txtInputAccountNumber" placeholder="' + customInfoAccountNum + '" onkeypress="return disableEnter(event);" disabled="disabled" /></div><br/>';
                                for (var i = 0; i < accountRequest.length; i++) {
                                    var mskDetail = accountRequest[i].Mask;
                                    mskDetail = mskDetail.replace(/!/g, "A");
                                    innerDiv += '<div class="form-group">';
                                    innerDiv += '<label id="' + accountRequest[i].ReqNum + '">' + accountRequest[i].Label + ' (' + mskDetail + ')</label>';
                                    var maskDetail = "'" + accountRequest[i].Mask + "'";
                                    if (accountRequest[i].DefValue == null) {
                                        accountRequest[i].DefValue = "";
                                    }

                                    if (accountRequest[i].VCode == "1") {
        //                                var lblId = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#','NUM');
                                        var lblId = 'txtReq' + String(i);
                                        innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId + '" value="' + accountRequest[i].DefValue + '"  placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" onfocus="javascript:setMask(this,' + maskDetail + ');"/><br/>';//
                                    }
                                    if (accountRequest[i].VCode == "2") {
        //                                var lblId1 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                                        var lblId1 = 'txtReq' + String(i);
                                        requireValidation.push(lblId1);
                                        innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId1 + '" value="' + accountRequest[i].DefValue + '"  placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" onfocus="javascript:setMask(this,' + maskDetail + ');" required/><br/>';
                                    }
                                    if (accountRequest[i].VCode == "3") {
        //                                var lblId2 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                                        var lblId2 = 'txtReq' + String(i);
                                        requireValidation.push(lblId2);
                                        innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId2 + '" value="' + accountRequest[i].DefValue + '"  placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" onfocus="javascript:setMask(this,' + maskDetail + ');" required/><br/>';
                                    }
                                    if (accountRequest[i].VCode == "4") {
        //                                var lblId3 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                                        var lblId3 = 'txtReq' + String(i);
                                        requireValidation.push(lblId3);
                                        innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId3 + '" value="' + accountRequest[i].DefValue + '"  placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" required/><br/>';
                                    }
                                    if (accountRequest[i].VCode == "5") {
        //                                var drpid = 'drp' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                                        var drpid = 'drpReq' + String(i);
                                        requireValidation.push(drpid);
                                        ridereason = accountRequest[i].DefValue;
                                        var dropDown = '<select id="' + drpid + '" class="form-control" style="border: 1px solid #ccc;">';
                                        var verifyList = accountRequest[i].VerifyList;
                                        dropDown += '<option value="0">SELECT ' + accountRequest[i].Label + '</option>';
                                        for (var j = 0; j < verifyList.length; j++) {
                                            dropDown += '<option value="' + verifyList[j].Display + '">' + verifyList[j].Display + '</option>';
                                        }
                                        dropDown += '</select>';
                                        innerDiv += dropDown;
                                    }
                                    innerDiv += '</div><br/><br/>';
                                }
                                innerDiv += '<button type="button" class="btn btn-primary" id="btnNextCorpAcc" onclick="return validateField();">Next</button>';
                                $("#divAccountNumber").append(innerDiv);
                                if (ridereason != "") {
                                    $("#drpRIDEREASON").val(ridereason);
                                }
                                return false;
                            }

                        }
                        else {
                        */
        localStorage.setItem("PMType", paymentType);
        //                    if (accountRequest == "" || accountRequest == undefined) {
        //                        $('#dvLoading').show();
        //                        getReviewDetail();
        //
        //                    } else {


        $("#divAccountNumber").html('');
        $("#liCorporateAccount").addClass("active");
        $("#liCorporateAccount").show();
        $("#profile").addClass("tab-pane active");
        $("#profile").show();
        $("#divWhatCorporateAccount").hide();
        $("#lblCorCCDetail").hide();

        //generate dynamic corporate account number table.
        //Vcode value 1,2,3,4 is for textbox and value 5 is for dropdowm.
        //validation is only vcode value 2,3,4,5.
        var innerDiv = '';

        //                        innerDiv += '<div class="form-group">';
        innerDiv += '<form>'
        //                        innerDiv += '<div class="form-group">';
        //                        innerDiv += '<label for="">Account Number</label><input type="text" class="form-control" id="txtInputAccountNumber" placeholder="' + customInfoAccountNum + '" onkeypress="return disableEnter(event);" disabled="disabled"/><br/><br />';
        if (accountRequest != "" && accountRequest != undefined) {
            for (var i = 0; i < accountRequest.length; i++) {
                var mskDetail = accountRequest[i].Mask;
                mskDetail = mskDetail.replace(/!/g, "A");
                //                                innerDiv += '<div class="form-group">';
                //                                innerDiv += '<label id="' + accountRequest[i].ReqNum + '">' + accountRequest[i].Label + ' (' + mskDetail + ')</label><label><label>Save</label></label>';
                var maskDetail = "'" + accountRequest[i].Mask + "'";
                var defVal;
                if (accountRequest[i].DefValue == null) {
                    accountRequest[i].DefValue = '';
                    defVal = 'value=""';

                } else {
                    defVal = 'value="' + accountRequest[i].DefValue + '"'
                }
                if (accountRequest[i].VCode == "1") {
                    //                                var lblId = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');

                    var lblId = 'txtReq' + String(i);
                    innerDiv += '<label for="' + lblId + '" id="' + accountRequest[i].ReqNum + '">' + accountRequest[i].Label + ' (' + mskDetail + ')</label> <label class="reqswitch"><label class="control-label">Save</label><input type="checkbox" class="form-control" id="chk' + accountRequest[i].ReqNum + '" onclick="checkSave(this)"/><div class="slider round"></div></label>';
                    innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId + '"' + defVal + ' placeholder="' + accountRequest[i].Label + '" onfocus="javascript:setMask(this,' + maskDetail + ');" onkeypress="return disableEnter(event);" /><br/>';//
                }
                if (accountRequest[i].VCode == "2") {
                    //                                var lblId1 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                    var lblId1 = 'txtReq' + String(i);
                    requireValidation.push(lblId1);
                    innerDiv += '<label for="' + lblId1 + '">' + accountRequest[i].Label + ' (' + mskDetail + ')</label> <label class="control-label reqswitch"><label for="chk' + accountRequest[i].ReqNum + '">Save</label><input type="checkbox" class="form-control" id="chk' + accountRequest[i].ReqNum + '" onclick="checkSave(this)"/><div class="slider round"></div></label>';
                    innerDiv += '<input type="text" style="text-transform: uppercase;" class="form-control" id="' + lblId1 + '"' + defVal + ' placeholder="' + accountRequest[i].Label + '" onfocus="javascript:setMask(this,' + maskDetail + ');" onkeypress="return disableEnter(event);" required/><br/>';
                    //                                    innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId1 + '"' + defVal + ' onkeypress="return disableEnter(event);" required/><br/>';
                }
                if (accountRequest[i].VCode == "3") {
                    //                                var lblId2 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                    var lblId2 = 'txtReq' + String(i);
                    requireValidation.push(lblId2);
                    innerDiv += '<label for="' + lblId2 + '" id="' + accountRequest[i].ReqNum + '">' + accountRequest[i].Label + ' (' + mskDetail + ')</label> <label class="control-label reqswitch"><label class="control-label">Save</label><input type="checkbox" class="form-control" id="chk' + accountRequest[i].ReqNum + '" onclick="checkSave(this)"/><div class="slider round"></div></label>';
                    innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId2 + '"' + defVal + ' placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" onfocus="javascript:setMask(this,' + maskDetail + ');" required/><br/>';
                }
                if (accountRequest[i].VCode == "4") {
                    //                                var lblId3 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                    var lblId3 = 'txtReq' + String(i);
                    requireValidation.push(lblId3);
                    innerDiv += '<label for="' + lblId3 + '" id="' + accountRequest[i].ReqNum + '">' + accountRequest[i].Label + ' (' + mskDetail + ')</label> <label class="control-label reqswitch"><label class="control-label">Save</label><input type="checkbox" class="form-control" id="chk' + accountRequest[i].ReqNum + '" onclick="checkSave(this)"/><div class="slider round"></div></label>';
                    innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId3 + '"' + defVal + ' placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" required/><br/>';
                }
                if (accountRequest[i].VCode == "5") {
                    //                                var drpid = 'drp' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                    var drpid = 'drpReq' + String(i);
                    requireValidation.push(drpid);
                    ridereason = accountRequest[i].DefValue;
                    innerDiv += '<label for="' + drpid + '" id="' + accountRequest[i].ReqNum + '">' + accountRequest[i].Label + ' (' + mskDetail + ')</label> <label class="control-label reqswitch"><label class="control-label">Save</label><input type="checkbox" class="form-control" id="chk' + accountRequest[i].ReqNum + '" onclick="checkSave(this)"/><div class="slider round"></div></label>';
                    var dropDown = '<select id="' + drpid + '" class="form-control" style="border: 1px solid #ccc;">';
                    var verifyList = accountRequest[i].VerifyList;
                    dropDown += '<option value="0">SELECT ' + accountRequest[i].Label + '</option>';
                    for (var j = 0; j < verifyList.length; j++) {
                        dropDown += '<option value="' + verifyList[j].Display + '">' + verifyList[j].Display + '</option>';
                    }
                    dropDown += '</select>';
                    innerDiv += dropDown;
                }
                //                                innerDiv += '</div></br></br>';
                //$("[id$=txtInputAccountNumber]").val(customInfoAccountNumber);
            }
        }
        innerDiv += '<button type="button" class="form-control btn btn-primary" id="btnNextCorpAcc" onclick="return validateField();">Next</button></form>';
        $("#divAccountNumber").append(innerDiv);
        //$("#txtReq0").mask('************', { autoclear: false });
        //$("#txtReq1").mask('99*99', { autoclear: false });
        //$("#txtReq2").mask('(999) 999-9999', { autoclear: false });
        //$("#txtReq3").mask('999999', { autoclear: false });
        if (ridereason != "") {
            $("#drpRIDEREASON").val(ridereason);
        }
        return false;
        //                  }
        /*                }
        */

    }

    if (rdbtnid == "Radio2CorporateCredit") {
        $('#Radio2CorporateAccount').prop('checked', false);
        //                $('#Radio2CorporateAccount').attr('checked', false);
        if (corAccDisable == true) {
            $("#divWhatCorporateAccount").hide();
            corAccDisable = false;
        }
        $('#inlineRadio2Corporate').prop('checked', true);
        //                $('#inlineRadio2Corporate').attr('checked', true);
        $("#liCorporateComponyCredit").addClass("active");
        $("#liCorporateComponyCredit").show();
        $("#liCorporateAccount").removeClass("active");
        $("#liCorporateAccount").hide();
        $("#liCorporate").removeClass("active");
        $("#liCorporate").hide();
        $("#profile2").addClass("tab-pane active");
        $("#profile2").show();
        $("#profile").removeClass("tab-pane active");
        $("#profile").hide();
    }
    /*if (rdbtnid == "Radio2CorporateAccount") {
        $('#Radio2CorporateCredit').prop('checked', false);
        $('#inlineRadio2Corporate').prop('checked', true);
//                $('#Radio2CorporateCredit').attr('checked', false);
//                $('#inlineRadio2Corporate').attr('checked', true);
        $("#liCorporateAccount").addClass("active");
        $("#liCorporateAccount").show();
        $("#liCorporateComponyCredit").removeClass("active");
        $("#liCorporateComponyCredit").hide();
        $("#liCorporate").removeClass("active");
        $("#liCorporate").hide();
        $("#profile2").removeClass("tab-pane active");
        $("#profile2").hide();
        $("#profile").addClass("tab-pane active");
        $("#profile").show();
        $("#divAccountNumber").html('');
        //generate dynamic corporate account number table.
        //Vcode value 1,2,3,4 is for textbox and value 5 is for dropdowm.
        //validation is only vcode value 2,3,4,5.
        var innerDiv = '';
        innerDiv += '<div class="form-group"><label for="">Account Number</label><input type="text" class="form-control" id="txtInputAccountNumber" placeholder="' + customInfoAccountNum + '" onkeypress="return disableEnter(event);" disabled="disabled" /></div><br/>';
        for (var i = 0; i < accountRequest.length; i++) {
            var mskDetail = accountRequest[i].Mask;
            mskDetail = mskDetail.replace(/!/g, "A");
            innerDiv += '<div class="form-group">';
            innerDiv += '<label id="' + accountRequest[i].ReqNum + '">' + accountRequest[i].Label + ' (' + mskDetail + ')</label>';
            var maskDetail = "'" + accountRequest[i].Mask + "'";
            if (accountRequest[i].DefValue == null) {
                accountRequest[i].DefValue = "";
            }
            if (accountRequest[i].VCode == "1") {
//                        var lblId = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                var lblId = 'txtReq' + String(i);
                innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId + '" value="' + accountRequest[i].DefValue + '" placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" onfocus="javascript:setMask(this,' + maskDetail + ');"/><br/>';//
            }
            if (accountRequest[i].VCode == "2") {
//                        var lblId1 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                var lblId1 = 'txtReq' + String(i);
                requireValidation.push(lblId1);
                innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId1 + '" value="' + accountRequest[i].DefValue + '" placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" onfocus="javascript:setMask(this,' + maskDetail + ');" required/><br/>';
            }
            if (accountRequest[i].VCode == "3") {
//                        var lblId2 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                var lblId2 = 'txtReq' + String(i);
                requireValidation.push(lblId2);
                innerDiv += '<input type="text" class="form-control" id="' + lblId2 + '" value="' + accountRequest[i].DefValue + '" placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" onfocus="javascript:setMask(this,' + maskDetail + ');" required/><br/>';
            }
            if (accountRequest[i].VCode == "4") {
//                        var lblId3 = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                var lblId3 = 'txtReq' + String(i);
                requireValidation.push(lblId3);
                innerDiv += '<input type="text" style="text-transform: uppercase" class="form-control" id="' + lblId3 + '" value="' + accountRequest[i].DefValue + '" placeholder="' + accountRequest[i].Label + '" onkeypress="return disableEnter(event);" required/><br/>';
            }
            if (accountRequest[i].VCode == "5") {
//                        var drpid = 'drp' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
                var lblId = 'drpReq' + String(i);
                requireValidation.push(drpid);
                ridereason = accountRequest[i].DefValue;
                var dropDown = '<select id="' + drpid + '" class="form-control" style="border: 1px solid #ccc;">';
                var verifyList = accountRequest[i].VerifyList;
                dropDown += '<option value="0">SELECT ' + accountRequest[i].Label + '</option>';
                for (var j = 0; j < verifyList.length; j++) {
                    dropDown += '<option value="' + verifyList[j].Display + '">' + verifyList[j].Display + '</option>';
                }
                dropDown += '</select>';
                innerDiv += dropDown;
            }
            innerDiv += '</div><br/><br/>';
        }
        innerDiv += '<button type="button" class="btn btn-primary" id="btnNextCorpAcc" onclick="return validateField();">Next</button>';
        $("#divAccountNumber").append(innerDiv);
        if (ridereason != "") {
            $("#drpRIDEREASON").val(ridereason);
        }
        return false;
    }*/

}

//BSA 11-17-2016
function checkSave(checkbox) {
    if (accountRequest != "" && accountRequest != undefined) {
        for (var i = 0; i < accountRequest.length; i++) {
            if (checkbox.id == "chk" + accountRequest[i].ReqNum) {
                if (checkbox.checked) {
                    accountRequest[i].Save = "Y"
                } else {
                    accountRequest[i].Save = "N"
                }
            }
        }
    }
}

function getMask(obj, maskingValue) {
    $("#" + obj.id).attr("maxLength", maskingValue.length);
    var newMask = maskingValue.replace(/#/g, "9").replace(/!/g, "*");
    $("#" + obj.id).mask(newMask);
    return;
}
//account reguest field masking.
function setMask(obj, maskingValue) {
    var dataval = $('#' + obj.id).attr('value');
    if (dataval == null || dataval == "") {
        $('#' + obj.id).val('  ');
    }
    $("#" + obj.id).attr("maxLength", maskingValue.length);
    var newMask = maskingValue.replace(/#/g, "9").replace(/!/g, "*");
    // $("#" + obj.id).mask(newMask, { autoclear: false });
    $("#" + obj.id).mask(newMask, { autoclear: false });
}

//BSA 12-23-2016
function setPhoneMask() {
    var cntryCode = document.getElementById('addphonecountrycode').value
    if (cntryCode == "1") {
        $("#txtAddPhoneNum").mask("(999) 999-9999");
        $("#txtAddPhoneNum").attr("placeholder", "(718) 555-5555");
    } else {
        $("#txtAddPhoneNum").mask("99999999999999");
        $("#txtAddPhoneNum").attr("placeholder", "55555555555555");
    }
}

//account request field validate
function validateField() {
    alert('here..');
    var isRequiredcount = 0;
    // for (var i = 0; i < requireValidation.length; i++) {
    //     var str = requireValidation[i];
    //     if (str.match(/drp/g)) {
    //         if ($('#' + str).val() == '0') {
    //             isRequiredcount = isRequiredcount + 1;
    //             $('#' + str).css("border", "1px solid red");
    //         }
    //         else {
    //             $('#' + str).css("border", "");
    //         }
    //     } else {
    //         if ($('#' + str).val() == '') {
    //             isRequiredcount = isRequiredcount + 1;
    //             $('#' + str).css("border", "1px solid red");
    //         }
    //         else {
    //             $('#' + str).css("border", "");
    //         }
    //     }
    // }
    // if (isRequiredcount > 0)
    //     return false;
    // else {
    $('#dvLoading').show();
    validateAccountRequest();
    $('.open-bodyPayment').removeClass('hidden');
    $('.Review').removeClass('hidden');
    $("#divReviewAndConfirmationSelection").show();
    $('#collapseTwo').removeClass("inSection");

    $('#collapseTwo').addClass('collapse');
    $('.Review').slideDown();
    initMap();
    //$("#collapseTwo .panel-body").hide();
    return true;
    // }
}

//validate account request after click on account number next button
function validateAccountRequest() {

    var passValues = '[';
    var controlValue = '';
    for (var i = 0; i < accountRequest.length; i++) {
        if (accountRequest[i].VCode == "5") {
            //                    var lblId1 = 'drp' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
            var lblId1 = 'drpReq' + String(i);
            controlValue = $("#" + lblId1).val();
            controlValue = controlValue.replace(/-/g, "");
        } else {
            //                    var lblId = 'txt' + accountRequest[i].Label.replace(/\s/g, '').replace('#', 'NUM');
            var lblId = 'txtReq' + String(i);
            controlValue = $("#" + lblId).val();
            controlValue = controlValue.replace(/-/g, "");
        }
        passValues += '{"ReqNum":"' + accountRequest[i].ReqNum + '","Save":"' + accountRequest[i].Save + '","ValueEntered":"' + controlValue + '"},';
    }
    passValues = passValues.replace(/,$/g, ''); //remove last comma from string
    passValues += ']';
    $('#dvLoading').show();
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/EliteService.asmx/ValidateAccountReq",
            data: "{ AccountReq: '" + passValues + "'}",
            success: succeededVAR_previous,
            error: failedVAR_previous
        });
}

var corAccDisable = false;
function succeededVAR_previous(result) {
    var myJsonString = JSON.parse(result.d);
    var returnStatus = myJsonString.ReturnStatus;
    if (returnStatus.Code == "1") {
        if (paymentType == 2) {
            corAccDisable = true;
            SelectSingleRadiobutton("Radio2CorporateCredit");

            $('#dvLoading').hide();
            return false;
        } else {
            $('#dvLoading').show();
            getReviewDetail();
        }
    }
    else {
        bootbox.alert("<h4>" + returnStatus.Message + "</h4>");
        $('#dvLoading').hide();
    }
    return false;
}

function failedVAR_previous() {

}

//get vehical info when click on personal
function getVehicalInfoPers() {
    if (document.getElementById('ContentPlaceHolder1_drpdwnPersonalCC').value == "0") {
        $('ContentPlaceHolder1_drpdwnPersonalCC').css("border", "1px solid red");
        return false;
    } else {
        $('ContentPlaceHolder1_drpdwnPersonalCC').css("border", "");
    }

    if ($('#txtPersInputCardNumber').val() == "") {
        $('#txtPersInputCardNumber').css("border", "1px solid red");
        return false;
    } else {
        $('#txtPersInputCardNumber').css("border", "");
    }

    if ($('#txtPersInputSecurityCode').val() == "") {
        $('#txtPersInputSecurityCode').css("border", "1px solid red");
        //SSA 07-14-2015 Commented Security Code required.
        //                return false;
    } else {
        $('#txtPersInputSecurityCode').css("border", "");
    }

    if ($('#drpexpireMM').val() == "0") {
        $('#drpexpireMM').css("border", "1px solid red");
        return false;
    } else {
        $('#drpexpireMM').css("border", "");
    }

    if ($('#drpexpireYY').val() == "0") {
        $('#drpexpireYY').css("border", "1px solid red");
        return false;
    } else {
        $('#drpexpireYY').css("border", "");
    }

    if ($('#txtPostalCode').val() == "") {
        $('#txtPostalCode').css("border", "1px solid red");
        //SSA 07-14-2015 Commented Security Code required.
        //                return false;
    } else {
        $('#txtPostalCode').css("border", "");
    }
    var expDate = $("#drpexpireMM").val() + '/' + $("#drpexpireYY").val();
    $('#dvLoading').show();
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/EliteService.asmx/GetVehicalListFromPersCC",
            data: "{ expirationDate: '" + expDate + "',securityCode:'" + $('#txtPersInputSecurityCode').val() + "',cardNum:'" + $('#txtPersInputCardNumber').val() + "',postalCode:'" + $('#txtPostalCode').val() + "',flag:'" + flagSaveFuture + "' }",
            success: succeeded_previous1,
            error: failed_previous1
        });
    return false;
}

function succeeded_previous1(result) {
    var myJsonString = JSON.parse(result.d);
    if (myJsonString != null) {
        if (myJsonString.Code == "1") {
            getReviewDetail();
        }
        else {
            var retStat = myJsonString.Message;
            bootbox.alert("<h4>" + retStat + "</h4>");
            $('#dvLoading').hide();
        }
    }
}

function failed_previous1() {

}

//get vehical info when click on corporate
function getVehicalInfoCorp() {
    if (document.getElementById('ContentPlaceHolder1_drpdwnCorporateCC').value == "0") {
        $('ContentPlaceHolder1_drpdwnCorporateCC').css("border", "1px solid red");
        return false;
    } else {
        $('ContentPlaceHolder1_drpdwnCorporateCC').css("border", "");
    }

    if ($('#txtCorCreditCard').val() == "") {
        $('#txtCorCreditCard').css("border", "1px solid red");
        return false;
    } else {
        $('#txtCorCreditCard').css("border", "");
    }

    if ($('#txtCorPassword').val() == "") {
        $('#txtCorPassword').css("border", "1px solid red");
        //SSA 07-14-2015 Commented Security Code required.
        //                return false;
    } else {
        $('#txtCorPassword').css("border", "");
    }

    if ($('#drcorpexpireMM').val() == "0") {
        $('#drcorpexpireMM').css("border", "1px solid red");
        return false;
    } else {
        $('#drcorpexpireMM').css("border", "");
    }

    if ($('#drcorpexpireYY').val() == "0") {
        $('#drcorpexpireYY').css("border", "1px solid red");
        return false;
    } else {
        $('#drcorpexpireYY').css("border", "");
    }

    if ($('#txtCorPostalCode').val() == "") {
        $('#txtCorPostalCode').css("border", "1px solid red");
        //SSA 07-14-2015 Commented Security Code required.
        //SSA 04-19-2016 Postal Code is required now
        //SSA 09-20-2016 Commented Postal Code requirement - causing issue with profiles created from SmCab
        //return false;
    } else {
        $('#txtCorPostalCode').css("border", "");
    }

    var corexpDate = $("#drcorpexpireMM").val() + '/' + $("#drcorpexpireYY").val();
    $('#dvLoading').show();
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/EliteService.asmx/GetVehicalListFromCorpCC",
            data: "{ expirationDate: '" + corexpDate + "',securityCode:'" + $('#txtCorPassword').val() + "',cardNum:'" + $('#txtCorCreditCard').val() + "',postalCode:'" + $('#txtCorPostalCode').val() + "',flag:'" + corflagSaveFuture + "'  }",
            success: succeeded_previous2,
            error: failed_previous2
        });
    return false;
}

function succeeded_previous2(result) {
    var myJsonString = JSON.parse(result.d);
    if (myJsonString != null) {
        if (myJsonString.Code == "1") {
            getReviewDetail();
        }
        else {
            var retStat = myJsonString.Message;
            bootbox.alert("<h4>" + retStat + "</h4>");
            $('#dvLoading').hide();
        }
    }
}

function failed_previous2() {

}

//verify promo code on textbox onblur event.and change the total price if received.
var totalPayCharge = '';//use in get connfirmation function
var carName;
var carPrice = '';
function VerifyPromoCode() {

    if ($("#txtPromoCode").val() == "") {
        return false;
    } else {
        $('#dvLoading').show();
        $.ajax(
            {
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: "/EliteService.asmx/VerifyPromoCode",
                data: "{promoCode:'" + $('#txtPromoCode').val() + "',carName:'" + carName + "',price:'" + totalPayCharge + "'}",
                success: succeeded_previous3,
                error: failed_previous3
            });
        return false;
    }
}

function succeeded_previous3(result) {
    var myJsonString = JSON.parse(result.d);
    var returnStatus = myJsonString.ReturnStatus;
    if (myJsonString != null) {
        if (returnStatus.Code == "1") {
            bootbox.alert("<h4>" + returnStatus.Message + "</h4>");
            for (var j = 0; j < carList.length; j++) {
                if (selectedCarTypeCode == carList[j].CarTypeCode) {
                    if (carList[j].TipAllowed == 'Y') {
                        if (!isNaN(carList[j].Price)) {
                            var adjustPrice = parseFloat(myJsonString.AdjustedPrice);
                            carPrice = adjustPrice;
                            $("#totalPayableCharge").text('$' + adjustPrice.toFixed(2));
                        }

                    }
                    else {
                        if (!isNaN(carList[j].Price)) {
                            var adjPrice = parseFloat(myJsonString.AdjustedPrice);
                            carPrice = adjPrice;
                            $("#totalPayableCharge").text('$' + adjPrice.toFixed(2));
                        }
                    }
                }
                $('#txtPromoCode').val('');
            }
        } else {
            bootbox.alert("<h4>" + returnStatus.Message + "</h4>");
            $('#txtPromoCode').val('');
        }
        $('#dvLoading').hide();
    }
}

function failed_previous3() {

}

//update total price when click on tip.
function updatePayableCharge(objValue) {
    $('#dvLoading').show();
    var tipPack;
    if (objValue == "TIP") {
        tipPack = 0;
    } else {
        tipPack = parseInt(objValue);
    }

    if (carPrice != '') {
        if (!isNaN(carPrice)) {
            var price = parseFloat(carPrice);
            var tp1 = parseFloat(tipPack / 100);
            var tp2 = parseFloat(tp1 * price);
            var totalPrice1 = parseFloat(tp2 + price);

            $("#totalPayableCharge").text('$ ' + totalPrice1.toFixed(2));
        }
    } else {
        if (!isNaN(totalAllPrice)) {
            var price = parseFloat(totalAllPrice);
            var tp1 = parseFloat(tipPack / 100);
            var tp2 = parseFloat(tp1 * price);
            var totalPrice1 = parseFloat(tp2 + price);

            $("#totalPayableCharge").text('$ ' + totalPrice1.toFixed(2));
        }
    }
    $('#dvLoading').hide();
}

//redirect to confirmation type.
function GetConfirmationType() {
    $('#dvLoading').show();
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/EliteService.asmx/GetReserVationNumber",
            success: succeeded_previousRVN,
            error: failed_previousRVN
        });
}

function succeeded_previousRVN(result) {
    var myJsonString = JSON.parse(result.d);
    var retStatus = myJsonString.ReturnStatus;
    if (retStatus.Code == "0") {
        bootbox.alert("<h4>" + retStatus.Message + "</h4>");
        $('#dvLoading').hide();
        return false;
    } else {
        window.location.href = "ConfirmType.aspx?buktovap=true";
    }
    $('#dvLoading').hide();
    return false;
}

function failed_previousRVN() {

}

//set masking on credit card detail.
function setCreditMask(id) {
    if (id == "txtCorCreditCard") {
        $("#txtCorCreditCard").mask("9999999999999999");
    }
    if (id == "txtPersInputCardNumber") {
        $("#txtPersInputCardNumber").mask("9999999999999999");
    }
    if (id == "txtPhNumber") {
        $("#txtPhNumber").mask("(999) 999-9999");
    }
}

function cancelBooking() {
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/EliteService.asmx/CancelBookACar",
            success: succeeded_previous,
            error: failed_previous
        });
}

function succeeded_previous(result) {
    if (result.d == "true") {
        window.location = "Confirmation.html";
    }
}

function failed_previous(parameters) {

}

function CancelTrip() {
    bootbox.confirm("<h4>Do you want to Cancel this trip?</h4>", function (result1) {
        if (result1 == true) {
            cancelBooking();
        }
    });
}

        jQuery(document).ready(function ($) {
            window.history.replaceState(null, 'Elite Limousine', 'Confirmation.html');
        });
        $(window).on("load", function () {
            $('#tripType').removeClass('hidden');
        /* === JFK Terminal === */
        $(".jfk-terminals area").on("click", function () {
                if (!$("#AirportForm").hasClass("hidden")) {
            $("#AirportForm").addClass('hidden');
        }
        $(this).parent().siblings('.pickup-points').addClass('active');
        $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
        $(this).parents('.limonet-area').removeClass("disabled");
        // $(".address-field.pickup-add").val('JFK').trigger('keyup');
        CreditCardVerified();
        // here its new line 26-11-2018
        $(".pickup-btns").addClass('active');
        $(".pickup-point").removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");
        // end 26-11-2018

        return false;
    });
            $(".superText").on("click", function () {
                if (!$("#AirportForm").hasClass("hidden")) {
            $("#AirportForm").addClass('hidden');
        }
        $(this).parent().siblings('.pickup-points').addClass('active');
        $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
        $(this).parents('.limonet-area').removeClass("disabled");
        // $(".address-field.pickup-add").val('JFK').trigger('keyup');

        // here its new line 26-11-2018
        $(".pickup-btns").addClass('active');

        console.log("pickup point: " + $('.pickup-point'));
        $('.pickup-points').addClass("active");
        $('.pickup-point').addClass("selected");
        CreditCardVerified();
        //$(".pickup-points .goback").removeClass('disabled');
        // $(".pickup-points .goback").removeClass('profile2');
        //$('.pickup-point').removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");


        // end 26-11-2018
        //$(".address-field.pickup-add").val('JFK Airport, New York, USA');
        return false;
    });
    /* === Pickup Points === */
            $(".pickup-point").on("click", function () {
            // alert('pickup select');
            $(".pickup-btns").addClass('active');
        $(".pickup-points .goback").removeClass('disabled');
        $(".pickup-points .goback").removeClass('profile2');
        $(this).removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");
        CreditCardVerified();
    });


    /* === Pickup Points Go Back === */
            $(".pickup-points .goback").on("click", function () {
            $(this).parent().siblings(".pickup-point").removeClass("selected disabled");
        $(this).parents('.pickup-points').removeClass("active");
        $(this).parents('.limonet-panel').find(".limonet-area").removeClass("disabled");
        //$(".pickup-points .goback").show();
        $(".pickup-points .goback").removeClass('profile2');
        $(".bill_credit_card .goback").hide();
        $(".address-field.pickup-add").val('').trigger('keyup');
        //$('.pickup-btns').addClass('active');
        return false;
    });
            $(".bill_credit_card .goback").on("click", function () {
            $(this).siblings(".pickup-point").removeClass("selected disabled");
        $('.bill_credit_card').removeClass("selected");
        $(this).parents('.bill_credit_card').removeClass("active");
        $(".limonet-area").removeClass("disabled");
        $(".bill_credit_card .goback").hide();
        $('#profile2').addClass('profile2');
        $('.textCredit').removeClass('hide');
        $(".address-field.pickup-add").val('').trigger('keyup');
        $(".CraditCardCentered").removeClass('disableCredit');

        $('.pickup-btns').addClass('active');
        return false;
    });
            //$(".airlines").on("click", function () {
            //   alert('aas');
            //    $(".pickup-btns").addClass('active');
            //   // $(this).removeClass("disabled").addClass("selected");
            //    $(this).removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");
            //});

            /* === LGA Terminal === */
            $(".lga-airline area").on("click", function () {
                if (!$("#AirportForm").hasClass("hidden")) {
                    $("#AirportForm").addClass('hidden');
                }
                $(".pickup-btns").addClass('active');
                $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
                $(this).parents('.limonet-area').removeClass("disabled").addClass('stop');
                $(this).parents(".limonet-area").find(".airlines").addClass('active');

                // here its new line 26-11-2018
                $('.airlines').removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");
                $(".bill_credit_card .goback").hide();
                CreditCardVerified();
                // end 26-11-2018
                // $(".address-field.pickup-add").val('LGA').trigger('keyup');

                return false;
            });
        $(".DirectText").on("click", function () {
                if (!$("#AirportForm").hasClass("hidden")) {
            $("#AirportForm").addClass('hidden');
        }
        $(".pickup-btns").addClass('active');
        $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
        $(this).parents('.limonet-area').removeClass("disabled").addClass('stop');
        $(this).parents(".limonet-area").find(".airlines").addClass('active');

        // here its new line 26-11-2018
        // $(".pickup-points .goback").show();
        $("airlines .goback").removeClass('profile2');
        $('.airlines').removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");

        // end 26-11-2018
        // $(".address-field.pickup-add").val('LGA').trigger('keyup');
        CreditCardVerified();

        return false;
    });


            $("#creditNext").on("click", function () {

            $(".pickup-btns").addClass('active');

        $(".CraditCardCentered").addClass('disableCredit');
        // here its new line 26-11-2018
        $('.bill_credit_card').removeClass("disabled").addClass("selected").siblings().removeClass("selected").addClass("disabled");
        // end 26-11-2018
        CreditCardVerified();
        return false;
    });
            $(".bill_credit_card").on("click", function () {
                if (!$("#AirportForm").hasClass("hidden")) {
            $("#AirportForm").addClass('hidden');
        }
                if ($('#profile2').hasClass('profile2')) {
            $('#profile2').removeClass('profile2');
        $('.textCredit').addClass('hide');

    }


    $(".goback").show();

    $(this).parents('.limonet-panel').find(".limonet-area").addClass("disabled");
    $(this).parents('.limonet-area').removeClass("disabled").addClass('stop');
    $(this).parents(".limonet-area").find(".airlines").addClass('active');

    // here its new line 26-11-2018
    $(this).removeClass("disabled").siblings().removeClass("selected").addClass("disabled");
    // end 26-11-2018
    // $(".address-field.pickup-add").val('LGA').trigger('keyup');
    $(".address-field.pickup-add").val('LGA Airport, New York, USA');
    return false;
});

            $(".Newark-airline area").on("click", function () {
                debugger;
                if (!$("#AirportForm").hasClass("hidden")) {
            $("#AirportForm").addClass('hidden');
        }
        $(".pickup-btns").addClass('active');
        // $(".address-field.pickup-add").val('LGA').trigger('keyup');
        $(".address-field.pickup-add").val('Newark Liberty International Airport, Newark, NJ, USA');
        return false;
    });


    /* === Airlines Go Back === */
            $(".airlines .goback").on("click", function () {
            $(".limonet-area").removeClass("disabled");
        $(".limonet-area").find(".airlines").removeClass('active');
        $(".address-field.pickup-add").val('').trigger('keyup');

        $(".pickup-btns").addClass('active');
        return false;
    });

    /* === Date Picker Initialize == */


    /* === Address Field == */
            $("body").on("keyup", ".address-field.pickup-add", function () {
            let val = $(this).val();
                if (val == 'jfk' || val == 'lga' || val == 'ewr' || val == 'JFK' || val == 'LGA' || val == 'EWR') {
            $(".more-fields").removeClass('hidden');
        }
                else {
            $(".more-fields").addClass('hidden');
        }

                if (val.length > 0) {
            $(".pickup-btns").addClass('active');
        }
                else {
            $(".pickup-btns").removeClass('active');
        }
    });


    /* === Special Request Radios == */
            $("#roundtrip").on("change", function () {
                if ($(this).prop("checked") == true) {
            $(".roundtrip").removeClass("hidden");
        $(".hourly").addClass("hidden");
    }
});
            $("#hourly").on("change", function () {
                if ($(this).prop("checked") == true) {
            $(".hourly").removeClass("hidden");
        $(".roundtrip").addClass("hidden");
    }
});
            $("#oneway").on("change", function () {
                if ($(this).prop("checked") == true) {
            $(".hourly").addClass("hidden");
        $(".roundtrip").addClass("hidden");
    }
});

/* === More Options == */
            $(".more > a").on("click", function () {
            $(this).toggleClass('active');
        $(".special-box").slideToggle();
        var topMargin = $(this).offset().top - $(".limonet-ride").offset().top;
                $(".special-box").css({"top": topMargin });
                $("html,body").animate({
            "scrollTop": 500
    }, 1000);
    return false;
});
            $("#carTypes").on("click", function () {
            $(this).toggleClass('active');
        $(".special-box").slideToggle();
        var topMargin = $(this).offset().top - $(".limonet-ride").offset().top;
                $(".special-box").css({"top": topMargin });
                $("html,body").animate({
            "scrollTop": 500
    }, 1000);
    return false;
});

            $("#closeCarTypes").on("click", function () {
            // alert('closeCarTypes');
            $(".special-box").slideUp();
        $(".more > a").removeClass('active');
        return false;
    });


    /* === Pickup Next == */
            $(".pickup-btns .next").on("click", function () {
            $(".special-box").slideUp();
        $(".more > a").removeClass('active');
        $(".limonet-panel.dropoff").removeClass('hidden');
        $("#collapseTwo").removeClass('collapse');
        $(this).parents('.limonet-panel-body').slideUp();

        $(this).parents('.limonet-panel').addClass('collapsed');
        return false;
    });

    /* === Pickup Next == */
            $(".open-body").on("click", function () {
            $(".limonet-panel.dropoff").addClass('hidden');
        $(".Review").addClass('hidden');
        $('#tripType').removeClass('hidden');
        $(this).parents('.limonet-panel').find('.limonet-panel-body').slideDown();
        $(this).parents('.limonet-panel').removeClass('collapsed');
                if (!$('#collapseTwo').hasClass('collapse')) {
            $('#collapseTwo').addClass('collapse');

        //isMap = true;

        //$(".divUpperPU").removeClass('hide');
        //$(".divUpperEN").removeClass('hide');
        //$(".divUpperDO").removeClass('hide');
        }
                else {
            $('#collapseTwo').removeClass('collapse');
        isMap = false;
        $(".divUpperPU").addClass('hide');
        $(".divUpperEN").addClass('hide');
        $(".divUpperDO").addClass('hide');
    }

    return false;
});
            $(".open-bodyPayment").on("click", function () {

            $("#divReviewAndConfirmationSelection").show();
        $('#collapseTwo').removeClass("inSection");
                //if ($(".goback").hasClass('profile2')) {
                //    $(".goback").removeClass('profile2');
                //}
                //else {
                //    $(".goback").addClass('profile2');
                //}
                if (!$('#collapseTwo').hasClass('collapse')) {
            $('#collapseTwo').addClass('collapse');
        $('.Review').removeClass('hidden');
        isMap = true;

        $(".divUpperPU").removeClass('hide');
        $(".divUpperEN").removeClass('hide');
        $(".divUpperDO").removeClass('hide');

    }
                else {
            $('#collapseTwo').removeClass('collapse');
        $('.Review').addClass('hidden');
        isMap = false;
        $(".divUpperPU").addClass('hide');
        $(".divUpperEN").addClass('hide');
        $(".divUpperDO").addClass('hide');
    }

    return false;
});//open-bodyReview

            $(".open-bodyReview").on("click", function () {

                if (!$("#collapseThree").hasClass("inSection")) {
            $("#collapseThree").addClass('inSection');
        }
                else {
            $("#collapseThree").removeClass('inSection');
        $("#collapseThree").removeClass('in');
    }
});//open-bodyReview


            $(".limonet-area area").on("mouseenter", function () {
                var thisarea = $(this).attr('class');
        console.log(thisarea);
        $(this).parents('.limonet-area').find('.area-hovers img').hide();
        $(this).parents('.limonet-area').find(".area-hovers #" + thisarea).show();
    });

            $(".limonet-area").on("mouseout", function () {
            $(this).find('.area-hovers img').hide();
        $(this).find('.area-hovers img:last-child').show();
    });

});


        $("#txtCreditNumber").attr("autocomplete", "off");
        $("#password").attr("autocomplete", "off");
        $("#txtPassword").attr("autocomplete", "off");
        $("#txtinputPassword3").attr("autocomplete", "off");
        $("#txtinputConfirmPassword").attr("autocomplete", "off");
        function ShowAddressInfo() {

            if (isMap) {
            $(".divUpperPU").removeClass('hide');
        $(".divUpperEN").removeClass('hide');
        $(".divUpperDO").removeClass('hide');
      
    }
            else {
            $(".divUpperPU").addClass('hide');
        $(".divUpperEN").addClass('hide');
        $(".divUpperDO").addClass('hide');
    }
                setTimeout(function () {
            ShowPickupPopup(); ShowDropoffPopup(); ShowEnroutePopup();
    }, 1000);
    //ShowPickupPopup();

}
        function ShowPickupPopup() {
            var moveLeft = 40;
        var moveDown = 10;



        var popupdiv = $(".divUpperPU");
            //$('#map_canvas img').each(function () {
            //console.log($(this).attr('src'))
            //});
            var ctrlimg = $("img[src$='pin_on_location.png']");
        //console.log(ctrlimg);
        var pos = $(ctrlimg).offset();
        //console.log(pos);
        console.log(pos.left);
        console.log(pos.top);

        var left = Math.round(pos.left + moveLeft) + "px";
        var top = Math.round(pos.top - moveDown) + "px";

            $(popupdiv).css({
            left: left,
        top: top
    });

    $(popupdiv).show();
}
        function ShowEnroutePopup() {
            var moveLeft = 240;
        var moveDown = 10;

        var popupdiv = $(".divUpperEN");
            //$('#map_canvas img').each(function () {
            //console.log($(this).attr('src'))
            //});
            var ctrlimg = $("img[src$='pin_on_location.png']");
        //console.log(ctrlimg);
        var pos = $(ctrlimg).offset();
        //console.log(pos);
        console.log(pos.left);
        console.log(pos.top);

        var left = Math.round(pos.left - moveLeft) + "px";
        var top = Math.round(pos.top - moveDown) + "px";

            $(popupdiv).css({
            left: left,
        top: top
    });

    $(popupdiv).show();
}
        function ShowDropoffPopup() {
            //var moveLeft = 40;
            var moveLeft = 260;
        var moveDown = 10;

        var popupdiv = $(".divUpperDO");
            //$('#map_canvas img').each(function () {
            //console.log($(this).attr('src'))
            //});
            var ctrlimg = $("img[src$='pin_drop_off_location.png']");
        //console.log(ctrlimg);
        var pos = $(ctrlimg).offset();
        //console.log(pos);
        console.log(pos.left);
        console.log(pos.top);

        //var left = Math.round(pos.left + moveLeft) + "px";
        var left = Math.round(pos.left - moveLeft) + "px";
        var top = Math.round(pos.top - moveDown) + "px";

            $(popupdiv).css({
            left: left,
        top: top
    });

    $(popupdiv).show();
}
        $(".divUpperPU, .divUpperEN, .divUpperDO").on("click", function () {
            $(".divUpperHeader").hide();
        $(".divSlideUpDown").hide();
        $(".clsSlideShow").show();
        return false;
    });
        $(".clsSlideShow").on("click", function () {
            $(".divUpperHeader").show();
        $(".divSlideUpDown").show();
        $(".clsSlideShow").hide();
        return false;
    });