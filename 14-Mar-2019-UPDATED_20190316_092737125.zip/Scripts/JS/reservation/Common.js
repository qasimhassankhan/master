﻿var customerCCInfo;
var customInfoAccountNumber;
var customerType;//used in credit card to check customer type

function disableEnter(e) {
    var code = (e.keyCode ? e.keyCode : e.which);
    if (code == 13) { //Enter keycode
        return false;
    }
}

var userIdGlobal;
//fill customer name after login 
function GetCustomerName(results) {
    //var myJsonString = JSON.parse(results);
    if (results != null) {
        customerCCInfo = results.CCList;
        //check customertype //1=Retail; 2=Corporate
        if (results.CustomerType == "1") {
            $('#liPromocode').css("display", "block");
        }
        customInfoAccountNumber = results.AccountNum;
        var fullName = results.FirstName + " " + results.LastName;
        $('#upperName').text(fullName);

        userIdGlobal = results.UserID;
        $("#disabledNameInput").val(fullName);
        $("#disabledPhoneNumberInput").val(results.PhoneNum);
        //var fullName = myJsonString.FirstName + " " + myJsonString.LastName;
        $("#customerName").text(fullName);
    }
}

function GetSignIn(parameters) {
    var userName = '';
    var passWord = '';
    if (parameters == 'master') {
        userName = $("#username").val();
        passWord = $("#password").val();

        if ($("#username").val() == '') {
            $("#username").css("border", "1px solid red");
            return false;
        } else {
            $("#username").css("border", "");
        }

        if ($("#password").val() == '') {
            $("#password").css("border", "1px solid red");
            return false;
        } else {
            $("#password").css("border", "");
        }
    }

    $('#dvLoading').show();
    $('#dvLoading').css('display', 'block');
    $.ajax(
        {
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: "/EliteService.asmx/Login",
            data: "{ emailAddress: '" + userName + "',passWord:'" + passWord + "',rememberMe:'" + $('#hdnCheckboxValue').val() + "' }",
            success: succeeded_previous,
            error: failed_previous
        });

    return false;
}

function succeeded_previous(result) {
    if (result.d != "") {
        var myJsonString = JSON.parse(result.d);
        if (myJsonString != null) {
            var code = myJsonString.Code;
            if (myJsonString.Code == "1") {
                //window.location = "MyProfile.aspx";
                window.location.href = "Book-a-car.aspx";
            }
            else {
                bootbox.alert("<h4>" + myJsonString.Message + "</h4>");
                //var tooltip = document.getElementById("tooltip2");
                //tooltip.innerHTML = myJsonString.Message;
                //tooltip.style.display = "block";
                //setTimeout(function () {
                //    tooltip.style.display = "none";
                //}, 2000);

            }
            $('#dvLoading').css('display', 'none');
            $('#dvLoading').hide();
            return false;
        }

    }
}

function failed_previous(result) {
    var err = result.status + ' ' + result.statusText;
    return false;
}





//get promo code list in promocode.aspx page.




function GetError(result) {
    alert(result);
}


//$("input[type=text]").live("keypress", function (e) {
//    var code = (e.keyCode ? e.keyCode : e.which);
//    if (code == 13) { //Enter keycode
//        return false;
//    }
//});

