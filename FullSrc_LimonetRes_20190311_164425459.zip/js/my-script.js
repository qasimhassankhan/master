<script type="text/javascript">
	
// Load this script when page loads
$(document).ready(function(){

 // Set up a listener so that when anything with a class of 'tab' 
 // is clicked, this function is run.
 $('.tab').click(function (event) {
 	event.preventDefault();
  // Remove the 'active' class from the active tab.
  $('#tabs_container > .tabs > li.active')
	  .removeClass('active')
	  
  // Add the 'active' class to the clicked tab.
  $(this).parent().addClass('active')

  // Remove the 'tab_contents_active' class from the visible tab contents.
  $('#tabs_container > .tab_contents_container > div.tab_contents_active')
	  .removeClass('tab_contents_active');

  // Add the 'tab_contents_active' class to the associated tab contents.
  $(this.rel).addClass('tab_contents_active');

 });
});
</script>
<script type="text/javascript">
	
// Load this script when page loads
$(document).ready(function(){

 // Set up a listener so that when anything with a class of 'tab' 
 // is clicked, this function is run.
 $('.tab2').click(function (e) {
 	event.preventDefault();
  // Remove the 'active' class from the active tab.
  $('#tabs_container2 > .tabs2 > li.active2')
	  .removeClass('active2')
	  
  // Add the 'active' class to the clicked tab.
  $(this).parent().addClass('active2')

  // Remove the 'tab_contents_active' class from the visible tab contents.
  $('#tabs_container2 > .tab_contents_container2 > div.tab_contents_active2')
	  .removeClass('tab_contents_active2');

  // Add the 'tab_contents_active' class to the associated tab contents.
  $(this.rel).addClass('tab_contents_active2');

 });
});
</script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-datepicker.js"></script>
	 <script type="text/javascript" src="js/bootstrap-timepicker.js"></script>
	
<script type="text/javascript">
		           $('.dp2').datepicker('update');
	</script>
	<script type="text/javascript">
		$('.datepicker').datepicker()
		if (top.location != location) {
    top.location.href = document.location.href ;
  }
		$(function(){
			window.prettyPrint && prettyPrint();
			$('#dp1').datepicker({
				format: 'mm-dd-yyyy'
			});
			$('#dp2').datepicker();
			$('#dp3').datepicker();
			$('#dp3').datepicker();
			$('#dp4').datepicker();
			$('#dp5').datepicker();
			$('#dp6').datepicker();
			$('#dpYears').datepicker();
			$('#dpMonths').datepicker();
			
			
			var startDate = new Date(2012,1,20);
			var endDate = new Date(2012,1,25);
			$('#dp4').datepicker()
				.on('changeDate', function(ev){
					if (ev.date.valueOf() > endDate.valueOf()){
						$('#alert').show().find('strong').text('The start date can not be greater then the end date');
					} else {
						$('#alert').hide();
						startDate = new Date(ev.date);
						$('#startDate').text($('#dp4').data('date'));
					}
					$('#dp4').datepicker('hide');
				});
			$('#dp5').datepicker()
				.on('changeDate', function(ev){
					if (ev.date.valueOf() < startDate.valueOf()){
						$('#alert').show().find('strong').text('The end date can not be less then the start date');
					} else {
						$('#alert').hide();
						endDate = new Date(ev.date);
						$('#endDate').text($('#dp5').data('date'));
					}
					$('#dp5').datepicker('hide');
				});

        // disabling dates
        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

        var checkin = $('#dpd1').datepicker({
          onRender: function(date) {
            return date.valueOf() < now.valueOf() ? 'disabled' : '';
          }
        }).on('changeDate', function(ev) {
          if (ev.date.valueOf() > checkout.date.valueOf()) {
            var newDate = new Date(ev.date)
            newDate.setDate(newDate.getDate() + 1);
            checkout.setValue(newDate);
          }
          checkin.hide();
          $('#dpd2')[0].focus();
        }).data('datepicker');
        var checkout = $('#dpd2').datepicker({
          onRender: function(date) {
            return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
          }
        }).on('changeDate', function(ev) {
          checkout.hide();
        }).data('datepicker');
		});

	</script>
	<script type="text/javascript">
		var nowTemp = new Date();
var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);
 
var checkin = $('#dpd1').datepicker({
  onRender: function(date) {
    return date.valueOf() < now.valueOf() ? 'disabled' : '';
  }
}).on('changeDate', function(ev) {
  if (ev.date.valueOf() > checkout.date.valueOf()) {
    var newDate = new Date(ev.date)
    newDate.setDate(newDate.getDate() + 1);
    checkout.setValue(newDate);
  }
  checkin.hide();
  $('#dpd2')[0].focus();
}).data('datepicker');
var checkout = $('#dpd2').datepicker({
  onRender: function(date) {
    return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
  }
}).on('changeDate', function(ev) {
  checkout.hide();
}).data('datepicker');
	</script>
 <script type="text/javascript">
            $('#timepicker3').timepicker({
                minuteStep: 5,
                showInputs: true,
                disableFocus: true
            });
             $('#timepicker4').timepicker({
                minuteStep: 5,
                showInputs: true,
                disableFocus: true
            });
               $('#timepicker5').timepicker({
                minuteStep: 5,
                showInputs: true,
                disableFocus: true
            });
$(document).ready(function () {
    $('#switch1').change(function () {
      $('#furthestPoint').fadeToggle();
    });
});
// $(".nav-button a").onClick(function(){
// 	$(".blue-nav").css("display", "inline-block");
// });
$(document).ready(function() {
	$("#blue-nav").hide();
    $('#nav-button').click(function() {
         $('#blue-nav').slideToggle("slow");
         $('#nav-button').css("background-image", "#418cfe");
    });
});
// Load this script when page loads
$(document).ready(function () {

    // Set up a listener so that when anything with a class of 'tab' 
    // is clicked, this function is run.
    $('.special-tab').click(function (event) {
        event.preventDefault();
        // Remove the 'active' class from the active tab.
        $('#special_request_container > .special_request_tabs > li.special-active')
            .removeClass('special-active');

        // Add the 'active' class to the clicked tab.
        $(this).parent().addClass('special-active');

        // Remove the 'tab_contents_active' class from the visible tab contents.
        $('#special_request_container > .special_content_container > div.special_contents_active')
            .removeClass('special_contents_active');

        // Add the 'tab_contents_active' class to the associated tab contents.
        $(this.rel).addClass('special_contents_active');

    });
});
$('#example').tooltip(options)
        </script>